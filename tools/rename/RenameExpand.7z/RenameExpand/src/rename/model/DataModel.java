package rename.model;

public class DataModel {
	
	public String projectName = "";	
	public String packageName = "";
	public String typeName = "";	
	public String methodName = "";
	public String refactorType = "";
	public String originalName = "";
	public String subsequentName = "";

}
