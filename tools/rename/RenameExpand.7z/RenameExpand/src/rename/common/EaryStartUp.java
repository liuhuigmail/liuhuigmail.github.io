package rename.common;

import org.eclipse.ui.IStartup;

public class EaryStartUp implements IStartup {

	@Override
	public void earlyStartup() {
		// TODO Auto-generated method stub

	}

}
