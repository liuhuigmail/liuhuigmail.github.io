package edu.ucsc.cse.grase.origin.util;

import java.io.File;

public class StringUtil {

	/**
	 * Compute relative path
	 * 
	 * @param absolutePath
	 * @return
	 */
	public static String toRelativePath(String absolutePath,
			File checkedOutLocation) {
		String relativePath = new File(absolutePath).getAbsolutePath();

		// Remove workspace part
		if (relativePath.startsWith(checkedOutLocation.getAbsolutePath())) {
			relativePath = absolutePath.substring(checkedOutLocation
					.getAbsolutePath().length());
		}

		// Remove the leading slash
		if (relativePath.startsWith(File.separator)) {
			relativePath = relativePath.substring(File.separator.length());
		}

		return relativePath;
	}

	/**
	 * Two way trim
	 * 
	 * @param line
	 * @return
	 */
	public static String twoWayTrim(String line) {
		StringBuffer lineBuffer = new StringBuffer(line.trim());
		String reversedTrimString = lineBuffer.reverse().toString().trim();
		String trimedLine = new StringBuffer(reversedTrimString).reverse()
				.toString();
		return trimedLine;
	}

	public static boolean isAllDigits(String string) {
		if (string == null)
			return false;

		for (int i = 0; i < string.length(); i++) {
			char ch = string.charAt(i);
			if (!Character.isDigit(ch))
				return false;
		}

		return true;
	}
}
