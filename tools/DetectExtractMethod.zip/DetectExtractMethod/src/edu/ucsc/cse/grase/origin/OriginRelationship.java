package edu.ucsc.cse.grase.origin;

import edu.ucsc.cse.grase.origin.entity.Method;
import edu.ucsc.cse.grase.origin.kimmy.LCS;
import edu.ucsc.cse.grase.origin.kimmy.Tokenize;

public class OriginRelationship implements Comparable {
	Method deleteddMethod;

	Method addedMethod;

	double similarity;

	boolean automaticOriginRelaion;

	public int compareTo(Object obj) {
		if (!(obj instanceof OriginRelationship)) {
			return 0;
		}

		OriginRelationship originRelationship = (OriginRelationship) obj;
		if (similarity > originRelationship.similarity)
			return 1;

		if (similarity < originRelationship.similarity)
			return -1;

		return 0;
	}

	public String toString() {
		return "Origin Relationship\t" + similarity + "\t"
				+ automaticOriginRelaion + "\n -" + deleteddMethod + "\n +"
				+ addedMethod;
	}
	
	public Method getDeletedMethod() { 
		return deleteddMethod;
		
	}

	public Method getAddedMethod() { 
		return addedMethod;
	}
}
