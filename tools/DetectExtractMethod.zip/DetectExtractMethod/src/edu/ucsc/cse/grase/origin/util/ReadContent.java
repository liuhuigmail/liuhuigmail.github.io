package edu.ucsc.cse.grase.origin.util;

import java.io.File;
import java.io.RandomAccessFile;

import org.eclipse.cdt.core.parser.CodeReader;

public class ReadContent {
	public static String getContent(String fileName, int startPos, int endPos) {

		//System.out.println(fileName + ":" + startPos + ":" + endPos);

		try {
			CodeReader codeReader = new CodeReader(fileName);
			String allContent = new String(codeReader.buffer);
			String conent = allContent.substring(startPos, endPos);
			
			//System.out.println(conent);
			
			return conent;

			/*
			 * FIXME: randmom access is not working well 
			 * byte data[] = new
			 * byte[endPos - startPos + 1]; RandomAccessFile accessFile = new
			 * RandomAccessFile(fileName, "r"); System.out.println("Length: " +
			 * accessFile.length()); accessFile.(data, startPos, (endPos -
			 * startPos + 1)); accessFile.close(); return new String(data);
			 */
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}
