package edu.ucsc.cse.grase.origin.kimmy;
	public class LCSElement<T> {

	int left_pos;

	int right_pos;

	T element;

	public LCSElement(T e, int l, int r) {
		element = e;
		left_pos = l;
		right_pos = r;

	}

	public String toString() {
		return element + "(" + left_pos + "," + right_pos + ")";
	}
}
