package edu.ucsc.cse.grase.origin.entity;

/**
 * Simplified parameter, just type and argument name
 * 
 * @author hunkim
 * 
 */
public class Parameter {
	String type;

	String name;

	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}

	public String toString() {
		String ret = "";
		if (type != null) {
			ret = type;
		}

		if (name != null) {
			ret += " " + name;
		}

		return ret;
	}

}
