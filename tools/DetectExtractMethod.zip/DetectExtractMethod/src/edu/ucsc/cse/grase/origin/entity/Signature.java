package edu.ucsc.cse.grase.origin.entity;

import java.util.ArrayList;
import java.util.List;

public class Signature {
	Parameter returnType;

	List parameters = new ArrayList();

	public void setReturnType(String type) {
		returnType = new Parameter();
		returnType.setType(type);
	}

	public String getReturnType (){
		return returnType.getType();
	}
	
	public String [] getParameterTypes () {
		String [] params = new String[parameters.size()];
		for (int i = 0; i < parameters.size(); i++) {
			Parameter p = (Parameter)parameters.get(i);
			params[i] = p.getType();
		}
		return params;
	}
	public void addParameter(String type, String name) {
		Parameter parameter = new Parameter();
		parameter.setType(type);
		parameter.setName(name);
		parameters.add(parameter);
	}

	public List getAllParameters() {
		List allParamater = new ArrayList();
		allParamater.add(returnType);
		allParamater.addAll(parameters);

		return allParamater;
	}

	public String toString() {
		String ret = returnType.toString() + "(";
		for (int i = 0; i < parameters.size(); i++) {
			if (i != 0) {
				ret += ",";
			}
			ret += parameters.get(i);
		}

		return ret + ")";
	}
}
