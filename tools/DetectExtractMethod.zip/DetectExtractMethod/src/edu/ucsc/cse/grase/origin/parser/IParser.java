package edu.ucsc.cse.grase.origin.parser;

import java.io.File;
import java.util.List;

/**
 * Return list of methods
 * @author hunkim
 *
 */
public interface IParser {
	public List parser(File location);
}
