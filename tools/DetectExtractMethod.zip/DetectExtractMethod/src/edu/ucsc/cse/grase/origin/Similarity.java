package edu.ucsc.cse.grase.origin;

import edu.ucsc.cse.grase.origin.factors.Body;
import edu.ucsc.cse.grase.origin.factors.Factor;
import edu.ucsc.cse.grase.origin.factors.FunctionName;

public class Similarity {
	static Factor factors[] = { new Body(), new FunctionName()};
	// new Location(),
//			new Signature() };

	public static double getSimilarity(OriginRelationship originRelationship) {
		double totalWeight = 0;
		double totalSimilarity = 0;

		for (int i = 0; i < factors.length; i++) {
			totalWeight += factors[i].getWeight();
			
			double sim = factors[i].getSimilarity(
					originRelationship.deleteddMethod,
					originRelationship.addedMethod);
//			System.out.println(i+"\t"+sim);
			totalSimilarity += sim;
		}

		return totalSimilarity / totalWeight;
	}
}
