package edu.washington.cs.rules;

public class JavaClass {
	String packageName;
	String className; 
	public JavaClass(String s) { 
		int sep = s.lastIndexOf(".");
		this.packageName = s.substring(0,sep);
		this.className = s.substring(sep+1);
	}
	public String toString () { 
		return this.packageName+":"+this.className;
	}
	public String getPackageName() { 
		return packageName;
	}
	public String getClassName() { 
		return className;
	}
}
