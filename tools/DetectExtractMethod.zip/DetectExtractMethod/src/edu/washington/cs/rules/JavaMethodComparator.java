package edu.washington.cs.rules;

import java.util.Comparator;

public class JavaMethodComparator implements Comparator<JavaMethod>{
	public int compare(JavaMethod o1, JavaMethod o2) {
		String o1Package = o1.getPackageName(); 
		String o2Package = o2.getPackageName();
		int packageCompare = o1Package.compareTo(o2Package);
		if (packageCompare!=0) return packageCompare; 
		String o1Class = o1.getClassName(); 
		String o2Class = o2.getClassName(); 
		int classCompare = o1Class.compareTo(o2Class); 
		if (classCompare!=0) return classCompare;
		String o1Procedure = o1.getProcedureName();
		String o2Procedure = o2.getProcedureName();
		int procedureCompare = o1Procedure.compareTo(o2Procedure);
		if (procedureCompare!=0) return procedureCompare;
		return (o1.toString().compareTo(o2.toString()));
	}

}
