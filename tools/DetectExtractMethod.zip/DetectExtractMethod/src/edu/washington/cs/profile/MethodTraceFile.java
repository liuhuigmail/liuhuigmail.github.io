package edu.washington.cs.profile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class MethodTraceFile {

	private static PrintStream print_stream = null;
	public static String TRACE_FILE ="methods.trace"; 

	public static String TRACE_SUFFIX =".trace";
	static {
		if (print_stream == null) {
			File f = new File(TRACE_FILE);
			try {
				if (!f.exists()) {
					f.createNewFile();
				}			
				FileOutputStream outstream = new FileOutputStream(f);
				print_stream = new PrintStream(outstream);
			} catch (java.io.FileNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	public static void println(String s) {
		print_stream.println(s);
	}
//	private static void createStream () {
//		if (print_stream == null) {
//			File f = new File(TRACE_FILE);
//			try {
//				if (!f.exists()) {
//					f.createNewFile();
//				}
//				FileOutputStream outstream = new FileOutputStream(f);
//				print_stream = new PrintStream(outstream);
//			} catch (java.io.FileNotFoundException e1) {
//				e1.printStackTrace();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//	}

}
