package edu.washington.cs.profile;

public interface CustomComparator{
	// Basically all matchable items and their values must reimplement
	// compareTo, and equals, hashCode function. 
	public int compareTo(Object a, Object b);
	public boolean equals(Object a, Object b); 
	public int hashCode(Object a); 
}
