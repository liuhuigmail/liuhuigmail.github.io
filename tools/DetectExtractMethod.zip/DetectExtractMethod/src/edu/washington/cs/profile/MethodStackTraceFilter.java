package edu.washington.cs.profile;

import java.io.File;

import javax.swing.filechooser.FileFilter;

public class MethodStackTraceFilter extends FileFilter{
	public static final String suffix = ".stacktrace";
	
	public boolean accept(File f) {
		// TODO Auto-generated method stub
		if (f.isDirectory())
			return true;
		return (f.getAbsolutePath().indexOf(suffix) >= 0) ;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return suffix;
	}

}