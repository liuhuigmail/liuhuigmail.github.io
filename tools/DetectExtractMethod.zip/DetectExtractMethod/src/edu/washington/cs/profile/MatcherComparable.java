package edu.washington.cs.profile;



public abstract class MatcherComparable implements Comparable{
	
 	public static CustomComparator comparator = null; 
	
	public static void setComparator(CustomComparator c){
		comparator = c;
	}
	public abstract CustomComparator getDefaultComparator ();
	public boolean equals (Object obj) {
		if (comparator==null) {
			System.err.println("Comparator is not set.");
		} 
		return comparator.equals(this, obj);
	}
	public int compareTo (Object obj){
		if (comparator==null) {
			System.err.println("Comparator is not set.");
		}
		MatcherComparable m = (MatcherComparable) obj;
		return comparator.compareTo(this, obj);
	}
	public int hashCode(){
		if (comparator==null) { 
			System.err.println("Comparator is not set.");
		}
		return comparator.hashCode(this);
	}
	public abstract String toString ();
	
}