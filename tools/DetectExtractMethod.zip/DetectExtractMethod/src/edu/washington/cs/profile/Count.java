package edu.washington.cs.profile;

public class Count extends MatcherComparable{
	
	private Integer data;
	
	public Count () { 
		comparator = new DefaultCountComparator();
	}
	public Count(String s){	
		this.data = new Integer(s);
	}
	public Count(int cnt){ 
		this.data = new Integer(cnt);  
	}
	public void incrementCount() { 
		data = new Integer(data.intValue()+1);
	}
	public int getCount() { 
		return this.data.intValue();
	}
	public String toString() { 
		return data.toString();
	}
	public CustomComparator getDefaultComparator() { 
		return comparator;
	}
	
	public class DefaultCountComparator implements CustomComparator{

		/* (non-Javadoc)
		 * @see edu.washington.cs.profile.CustomComparator#compareTo(java.lang.Object, java.lang.Object)
		 */
		public int compareTo(Object a, Object b) {
			// TODO Auto-generated method stub
			Count ia = (Count) a;
			Count ib = (Count) b;
			return ia.data.compareTo(ib.data);
		}

		/* (non-Javadoc)
		 * @see edu.washington.cs.profile.CustomComparator#equals(java.lang.Object, java.lang.Object)
		 */
		public boolean equals(Object a, Object b) {
			// TODO Auto-generated method stub
			Count ia = (Count) a;
			Count ib = (Count) b;
			return ia.data.equals(ib.data);
		
		}

		/* (non-Javadoc)
		 * @see edu.washington.cs.profile.CustomComparator#hashCode(java.lang.Object)
		 */
		public int hashCode(Object a) {
			// TODO Auto-generated method stub
			Count ia = (Count)a;
			return ia.data.hashCode();
		} 
	}

}
