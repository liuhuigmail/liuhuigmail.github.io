package edu.washington.cs.util;

import java.util.Set;

public interface Matchable<T> {
	public Set<T> getMatcableItems ();
}