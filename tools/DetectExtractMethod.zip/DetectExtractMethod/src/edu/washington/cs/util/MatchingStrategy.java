package edu.washington.cs.util;

import java.io.PrintStream;
import java.util.Set;

import edu.washington.cs.profile.MatcherComparable;


public interface MatchingStrategy<T extends Comparable, V extends MatcherComparable> {
	// T: is the type of MatchableItem
	
	// V: is the value of MatchableItem
	
	// remove already matched ones from matching strategy set 
	public MatchingStrategy removeMatchedOnes(Set<T> toBeRemoved);
	
	// retain only matchableItems
	public MatchingStrategy retainMatchableOnes (Set<T> toBeRetained);
	
	// return the set of matchable items for a value V  
	public Set<T> match(V value);
	
	// return the value of each matcable item 
	
	public V getValue(T t1);
	
	// return a set of <T> s
	
	public Set<T> getSet();
	
	// return the total size of matching strategy. 
	public int size();
	
	// persist the current strategy  
	public void printStrategy(PrintStream printStream);
	
	public void printReverseStrategy (PrintStream printStream);
	
}
