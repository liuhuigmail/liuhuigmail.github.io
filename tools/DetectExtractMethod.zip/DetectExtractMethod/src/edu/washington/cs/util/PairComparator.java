package edu.washington.cs.util;

import java.util.Comparator;

import edu.washington.cs.rules.JavaMethod;
import edu.washington.cs.rules.JavaMethodComparator;

public class PairComparator implements Comparator<Pair>{

	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(T, T)
	 */
	public int compare(Pair p1, Pair p2 ) {
		
		Pair<JavaMethod> o1 = (Pair<JavaMethod>)p1;
		Pair<JavaMethod> o2 = (Pair<JavaMethod>)p2;
		// TODO Auto-generated method stub
		if (o1.getLeft()==null || o2.getLeft()==null) return -1;
		
		return new JavaMethodComparator().compare(o1.getLeft(), o2.getLeft());
	}
	
}	
