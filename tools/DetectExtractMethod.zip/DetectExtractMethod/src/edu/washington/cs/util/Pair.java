package edu.washington.cs.util;

import edu.washington.cs.comparison.LCS;
import edu.washington.cs.comparison.Tokenize;
import edu.washington.cs.extractors.SeedMatchGenerator;
import edu.washington.cs.rules.JavaMethod;

public class Pair<T extends Comparable>implements Comparable{

	T t1;

	T t2;

	private static final String xmlTag ="pair";
	
	public Pair(T tt1, T tt2) {
		this.t1 =tt1;
		this.t2 =tt2;
	}

	public int compareTo(Object o) {

		if (o instanceof Pair) {
			Pair po = (Pair) o;
			String thisString = this.toString();
			String poString = po.toString();
			return thisString.compareTo(poString);
		}
		return -1;
		
	}
	
	public boolean equals(Object obj) {
		if (obj instanceof Pair) {
			Pair po  = (Pair)obj;
			return po.toString().equals(this.toString());
		}
		return false;
	}	
	public int hashCode() {
		return toString().hashCode();
	}

	public String toString(){ 
		String s1 ="empty", s2 ="empty"; 
		if (t1!=null) s1= t1.toString();
		if (t2!=null) s2= t2.toString();
		String s="";
//		if (t1 != null && t2 != null) {
//			double simSeqToken = new SeedMatchGenerator().similaritySeqToken(
//					(JavaMethod) this.getLeft(), (JavaMethod) this.getRight());
//			s = " SQ" + (int) (simSeqToken * 100) + "%";
//		}
		return s+"{"+s1+"\t"+s2+"}";
	}
	public T getLeft() { 
		return t1;
	}
	public T getRight() {
		return t2;
	}
	public static String getXMLTag () { 
		return xmlTag;
	}
	public static Pair makeJavaMethodPair (String s){
		try {
			String left = s.substring(s.indexOf('{') + 1, s.indexOf('\t'));
			JavaMethod t1 =null;
			if (!left.equals("empty")) t1 =new JavaMethod(left);;
			
			String right = s.substring(s.indexOf('\t') + 1, s.indexOf('}'));
			JavaMethod t2 = null;
			if (!right.equals("empty")) t2= new JavaMethod(right);
			return new Pair(t1, t2);
		
		}catch (StringIndexOutOfBoundsException e){
			e.printStackTrace();
			//System.out.println(s);
		}
		return null;
	}	
	
	public double numSharedTokenScore() {
		if (!(t1 instanceof JavaMethod)) return 0; 
		if (!(t2 instanceof JavaMethod)) return 0;
		JavaMethod o = (JavaMethod) t1;
		JavaMethod n = (JavaMethod) t2;
		String oldN = o.toString(); 
		String newN = n.toString();
		
		String oldNameTokens[] = Tokenize.tokenizeOrderingLetter(oldN);
		String newNameTokens[] = Tokenize.tokenizeOrderingLetter(newN);
		double score1 =(double) LCS.getNumSharedTokens(oldNameTokens, newNameTokens);
		double max1 = (double) Math.max(oldNameTokens.length
				, newNameTokens.length
				);
		
		double result1 = score1/max1;
		return result1;
	}
}