package edu.washington.cs.util;

import java.util.Set;
import java.util.TreeSet;

public class SetUtil<T extends Comparable> {

	// return difference between two sets as a new object set
	public Set<T> diff(Set<T> a1, Set<T> b1) {
		Set<T> result = new TreeSet<T>();
		result.addAll(a1);
		result.removeAll(b1);
		return result;
	}

	// return interesect between two sets as a new object set
	public Set<T> intersect(Set<T> a1, Set<T> b1) {
		Set<T> result = new TreeSet<T>();
		result.addAll(a1);
		result.retainAll(b1);
		return result;
	}
	

}
