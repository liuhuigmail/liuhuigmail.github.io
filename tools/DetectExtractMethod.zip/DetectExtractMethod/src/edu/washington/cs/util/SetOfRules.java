package edu.washington.cs.util;

import java.util.HashSet;

import edu.washington.cs.rules.Rule;

public class SetOfRules {
	HashSet<Rule> rules = new HashSet<Rule>();
	
	public void add(Rule r) {
		rules.add(r);
	}
	public void sortByScore(){
		
	}
	public String toString () { 
		return rules.toString();
	}
	
}
