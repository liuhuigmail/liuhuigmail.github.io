package edu.washington.cs.others;

import org.w3c.dom.Element;

public class WDMove extends WDRefactoringEvent{
	private static String xmlTag = "move";
	public static String getXMLTag () {
		return xmlTag;
	}

	public WDMove(Element m){
		super(m);
		if (m.getAttribute("symtype").equals("Method")) { 
			this.type = "WDMove Method";
		}else if (m.getAttribute("symtype").equals("Class")){ 
			this.type = "WDMove Class";
		}else if (m.getAttribute("symtype").equals("Interface")){ 
			this.type = "WDMove Interface";
		}else if (m.getAttribute("symtype").equals("Field")) {
			this.type = "WDMove Field";
		}else { 
			System.out.println("NOT EXHAUSTIVE"+m);
		}
	}
	
}
