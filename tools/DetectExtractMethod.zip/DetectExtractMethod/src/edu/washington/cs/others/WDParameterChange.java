package edu.washington.cs.others;

import org.w3c.dom.Element;

public class WDParameterChange extends WDRefactoringEvent{
	
	private static String xmlTag = "parameterchange";
	public static String getXMLTag () { 
		return xmlTag;
	}
	public WDParameterChange(Element m){ 
		super(m); 
		if (m.getAttribute("pchangetype").equals("ADDPARAMETER")){ 
			this.type = "Add Parameter"; 
			
		}else if (m.getAttribute("pchangetype").equals("REMOVEPARAMETER")){ 
			this.type = "Remove Parameter";
		}else { 
			System.out.println("NOT EXHAUSTIVE");
		}
	}
}
