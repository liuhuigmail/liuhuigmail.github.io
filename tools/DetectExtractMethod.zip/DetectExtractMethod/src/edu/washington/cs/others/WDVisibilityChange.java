package edu.washington.cs.others;

import org.w3c.dom.Element;


public class WDVisibilityChange extends WDRefactoringEvent {
	
	private static String xmlTag = "visibilitychange";
	public WDVisibilityChange(Element m){ 
		super(m);
		if (m.getAttribute("vchangetype").equals(HIDEMETHOD)) { 
			this.type = "Hide Method";
		}else if (m.getAttribute("vchangetype").equals(UNHIDEMETHOD)){
			this.type = "Unhide Method";
		}else { 
			System.out.println("NOT EXHAUSTIVE"+m);
		}
	}
	public static String getXMLTag () { 
		return xmlTag;
	}
	public String HIDEMETHOD = "HIDEMETHOD";
	public String UNHIDEMETHOD = "UNHIDEMETHOD";
}
