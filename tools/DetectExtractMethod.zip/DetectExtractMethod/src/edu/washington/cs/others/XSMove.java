package edu.washington.cs.others;
public class XSMove extends XSChange{
	public static String MOVE = "move";

	public XSMove(String s ){ 
		super(s);
	}
	public boolean isValid(String s) {
		return s.equals(MOVE);
	}
	public void tally(XSStat stat) {
		stat.moveCount++;
		if (this.category.kind.equals(XSCategory.CLASS)) {
			stat.move_class++;
		} else if (this.category.kind.equals(XSCategory.INTERFACE)) {
			stat.move_interface++;
		} else if (this.category.kind.equals(XSCategory.METHOD)) {
			stat.move_method++;
		} else if (this.category.kind.equals(XSCategory.FIELD)) {
			stat.move_field++;
		} else { 
			System.out.println("NOT CLASS, NOT INTERFACE, NOT METHOD NOT FIELD");
		}
	}
}
