package edu.washington.cs.others;

import org.w3c.dom.Element;

public class WDRename extends WDRefactoringEvent{
	
	private static String xmlTag = "rename";
	public static String getXMLTag () { 
		return xmlTag;
	}
	public WDRename(Element m){ 
		super(m);
		if (m.getAttribute("symtype").equals("Method")) { 
			this.type = "WDRename Method";	
		}else if (m.getAttribute("symtype").equals("Class")){ 
			this.type = "WDRename Class";
		}else if (m.getAttribute("symtype").equals("Interface")){ 
			this.type = "WDRename Interface";
		}else { 
			System.out.println("NOT EXHAUSTIVE"+m);
		}
	}
}
