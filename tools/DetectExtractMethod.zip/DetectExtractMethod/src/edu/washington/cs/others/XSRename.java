package edu.washington.cs.others;

public class XSRename extends XSChange{
	public static String RENAME = "rename";
	public XSRename(String s ){ 
		super(s);
	}
	public boolean isValid(String s) {
		return s.equals(RENAME);
	}
	@Override
	public void tally(XSStat stat) {
		stat.renameCount++;
		if (this.category.kind.equals(XSCategory.PACKAGE)) {
			stat.rename_package++;
		}else if (this.category.kind.equals(XSCategory.CLASS)) {
			stat.rename_class++;
		}else if (this.category.kind.equals(XSCategory.INTERFACE)) {
			stat.rename_interface++;
		}else if (this.category.kind.equals(XSCategory.CONSTRUCTOR)) {		
			stat.rename_constructor++;
		}else if (this.category.kind.equals(XSCategory.METHOD) ) {
			stat.rename_method++;
		}else if (this.category.kind.equals(XSCategory.FIELD) ) {
			stat.rename_field++;
		}else { 
			System.out.println("NOT RENAME PACKAGE, CLASS, INTERFACE, CONSTRUCTOR, METHOD, FIELD ");
		}
	}
}
