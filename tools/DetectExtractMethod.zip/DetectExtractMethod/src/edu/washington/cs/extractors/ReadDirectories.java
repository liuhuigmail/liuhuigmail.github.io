package edu.washington.cs.extractors;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class ReadDirectories {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (args.length!=1) System.exit(0);
		File[] fs= getDirectories(args[0]);
		for (int i=0; i< fs.length; i++){ 
			System.out.println(fs[i].getAbsolutePath());
		}
		
	}
	public static File[] getDirectories (String dir_list){

		ArrayList<File> list = new ArrayList();
		
		File f = new File (dir_list);
		try {
			if (!f.exists()) {
				System.out.println("Directory list file does not exist");
				System.exit(0);
			}
			FileReader freader = new FileReader(f);
			BufferedReader reader = new BufferedReader(freader);
			for (String s = reader.readLine(); s != null; s = reader.readLine()) {
				File dir = new File (s); 
				if (!dir.exists()) {
					System.out.println("Error in reading directory list"+ dir.getName());
				}
				else { 
					list.add(dir);
				}
			}
		} catch (FileNotFoundException e) {

		} catch (IOException e) {

		}
		File [] files = new File[list.size()];
		for (int i=0; i<files.length; i++){ 
			files[i] = list.get(i);
		}
		return files;
	}
	

}
