package edu.washington.cs.extractors;

import java.io.File;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

import edu.washington.cs.rules.JavaMethod;
import edu.washington.cs.util.SetUtil;

public class ProgramSnapshot {
	private final String srcPath; 
	private final String version;
	private final String project;
	private final ArrayList<JavaMethod> methods;
	public ProgramSnapshot (String project, File srcDirectory) {
		this.project = project;
		this.srcPath = srcDirectory.getAbsolutePath();
		String versionX = srcPath
				.substring(srcPath.lastIndexOf("-") + 1);
		this.version = versionX.substring(versionX.lastIndexOf("\\") + 1);
		// get oldEntities
		Set<JavaMethod> initMethods = new ExtractMethods(new File(
				this.srcPath), this.version, this.project, true).getMatcableItems();
		this.methods = new ArrayList<JavaMethod> ();
		this.methods.addAll(initMethods);
	}
	public ArrayList<JavaMethod> getMethods() {
		return methods;
	}
	public String getProject() {
		return project;
	}
	public String getVersion() {
		return version;
	}
	public String getSrcPath() {
		return srcPath;
	}

	public ProgramSnapshot (String project, int transaction_id, ArrayList<JavaMethod> methods, String srcPath) { 
		this.project = project;
		this.version = new Integer(transaction_id).toString();
		this.methods = methods;
		this.srcPath = srcPath;	
	}
	public ProgramSnapshot (String project, String transaction_id, ArrayList<JavaMethod> methods, String srcPath) { 
		this.project = project;
		this.version = transaction_id;
		this.methods = methods;
		this.srcPath = srcPath;	
	}
	public static void main (String args[]) { 
		ExtractMethods em =new ExtractMethods(new File("e:\\jfreechart_archive\\jfreechart-0.9.17"),"0.9.17","jfreechart",true);
		System.out.println(em.getMatcableItems().size());
//		batchPreparation("jfreechart_list","jfreechart");
//		batchPreparation("jhotdraw_list","jhotdraw");
//		batchPreparation("jedit_list","jedit");
	}
	public static void batchPreparation (String dirList, String project) { 
		File[] dirs = ReadDirectories.getDirectories(dirList);
//		for (int i = 0; i < dirs.length - 1; i++) {
//			File srcDir = dirs[i];
//			new ProgramSnapshot(project, srcDir);
//		}
	}
	public ArrayList<JavaMethod> minus (ProgramSnapshot subtract) { 
		ArrayList<JavaMethod> domain = new ArrayList<JavaMethod>();
		TreeSet<JavaMethod> leftSet = new TreeSet<JavaMethod>();
		leftSet.addAll(this.getMethods());
		TreeSet<JavaMethod> rightSet = new TreeSet<JavaMethod>();
		rightSet.addAll(subtract.getMethods());
		SetUtil<JavaMethod> exactMatcher = new SetUtil<JavaMethod>();
		
		domain.addAll(exactMatcher.diff(leftSet, rightSet));
//		System.out.println("Intersection:"+(exactMatcher.intersect(leftSet,rightSet).size()));
		return domain; 
	}
	public Set<JavaMethod> common (ProgramSnapshot subtract) { 
		TreeSet<JavaMethod> leftSet = new TreeSet<JavaMethod>();
		leftSet.addAll(this.getMethods());
		TreeSet<JavaMethod> rightSet = new TreeSet<JavaMethod>();
		rightSet.addAll(subtract.getMethods());
		SetUtil<JavaMethod> exactMatcher = new SetUtil<JavaMethod>();
		return (exactMatcher.intersect(leftSet, rightSet));
	}
}
