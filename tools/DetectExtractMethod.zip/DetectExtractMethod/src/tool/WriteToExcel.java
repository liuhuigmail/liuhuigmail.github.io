



	package tool;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;

	
import org.xml.sax.SAXException;
	public class WriteToExcel {
		public static final String minmloc = "5";
		
		/*public ArrayList<Integer> readExcel(String strpath,ArrayList<MethodOfWrite> writeMethod) throws IOException, OpenXML4JException, SAXException
		{
		ArrayList<Integer> rows=new ArrayList<Integer>();
		ArrayList<MethodOfWrite> VisitedMethod=new ArrayList<MethodOfWrite>();
		
			Workbook wb = null; 
		    InputStream inp = new FileInputStream(strpath);
			wb = WorkbookFactory.create(inp);        
		    Sheet sheet =  wb.getSheetAt(0);  
	         
				  
				
				for(MethodOfWrite writemethod:writeMethod){
				b:
				for (int i = 0; i < sheet.getLastRowNum(); i++) { 
					boolean yy=false;
					Row row = sheet.getRow(i);  
				    Cell cell0 = row.getCell(0);  
				    Cell cell1=row.getCell(1);
				    Cell cell2=row.getCell(2);
				    Cell cell6=row.getCell(6);
				    Cell cell3=row.getCell(3);
				    
				    String Scell0;
				    String Scell1;
				    String Scell2;
				    String Scell6;
				    String Scell3;
				    
				    cell0.setCellType(Cell.CELL_TYPE_STRING);  
	                Scell0 = cell0.getStringCellValue().trim();  
				    
				           
	                   cell1.setCellType(Cell.CELL_TYPE_STRING);  
	                  Scell1 = cell1.getStringCellValue().trim();  
	                             
	                   cell2.setCellType(Cell.CELL_TYPE_STRING);  
	                  Scell2 = cell2.getStringCellValue().trim();  
	                                
	                   cell6.setCellType(Cell.CELL_TYPE_STRING);  
	                  Scell6 = cell6.getStringCellValue().trim();  
	                             
	                   cell3.setCellType(Cell.CELL_TYPE_STRING);  
	                  Scell3 = cell3.getStringCellValue().trim();  
	                    
	                  
	          // System.out.println(Scell1); System.out.println(Scell2); System.out.println(Scell6);
	           //System.out.println(writemethod.packagename);
	          //System.out.println( writemethod.compiname);
	          //System.out.println(writemethod.methodname);
	          //System.out.println(writemethod.paranum);
	          boolean yy1=writemethod.packagename.equals(Scell0);
	        		  boolean yy2=writemethod.compiname.equals(Scell1);
	        		  boolean yy3=writemethod.methodname.equals(Scell2);
	        		  boolean yy4=Scell6.equals(String.valueOf(writemethod.paranum)); 
	        		  int mlocvalue=Integer.parseInt(Scell3);
				   // System.out.println(yy1);
				   // System.out.println(yy2);
				   // System.out.println(yy3);
				   // System.out.println(yy4);
				    if((writemethod.packagename!=null&&writemethod.methodname!=null&&writemethod.compiname!=null)){
				    	
				   if(yy1==true&&yy2==true&&yy3==true&&yy4==true&&mlocvalue>=Integer.parseInt(minmloc)){
					   rows.add(i);
					   VisitedMethod.add(writemethod);
					   yy=true;
				   }
				    
				}
				if(yy)
					break b;
				}
				}	
				writeMethod.removeAll(VisitedMethod);
				
				return rows;
			}  
	public void aTest(ArrayList<MethodOfWrite> writeMethod) throws IOException, OpenXML4JException, SAXException 
	{
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss:SS");   
	    TimeZone t = sdf.getTimeZone();   
	    t.setRawOffset(0);   
	    sdf.setTimeZone(t);   
	    Long startTime = System.currentTimeMillis();   
		String[] str={"F:\\test1.xls","F:\\test2.xls"};
		
		for(String ss:str){
		
			ArrayList<Integer> ar=readExcel(ss,writeMethod);
			
				
		writetoexcel(ar,ss);}
		//readExcel(str);
		 Long endTime = System.currentTimeMillis();   
		    System.out.println("��ʱ��" + sdf.format(new Date(endTime - startTime)));   
		}
	public void writetoexcel(ArrayList<Integer> arows,String strpath) throws InvalidFormatException, IOException
	{
		
		
		
		Workbook wb = null; 
	    
		InputStream inp = new FileInputStream(strpath);
		wb = WorkbookFactory.create(inp);   
		 Sheet sheet =  wb.getSheetAt(0);  
		 FileOutputStream output = new FileOutputStream(strpath);
		 for(Integer aint:arows)
		 {
			 Row arow=sheet.getRow(aint);
			 arow.createCell(7).setCellValue("Y");
		 }
		
		 output.flush();
		   wb.write(output);
		   output.close();
		
		
		
		
	}
*/


	}


