package tool;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.MethodDeclaration;

import difflib.Chunk;
import difflib.Delta;
import difflib.DiffUtils;
import difflib.Patch;
import edu.washington.cs.rules.JavaMethod;

public class Detector {
	
	public static final double DIFFVALUE_CONSTANT = 0.5;
	
	
	//�����°汾��ȫ���ĳ�ȡ����
	public ArrayList<IMethod> getExtractMethods(String oldProjectName, String newProjectName, 
			ArrayList<IMethod> addIMethods, Map<JavaMethod, JavaMethod> matchmethods) throws JavaModelException{
		ArrayList<IMethod> extractMethods = new ArrayList<IMethod>();
		try{
		if(addIMethods != null && addIMethods.size() != 0){
			for(IMethod addIMethod : addIMethods){
				IMethod extractMethod = getExtractMethod(oldProjectName, newProjectName, addIMethod, matchmethods);
				if(extractMethod != null){
					extractMethods.add(extractMethod);
					//System.out.println(getMaxDiffValue(oldProjectName, newProjectName, addIMethod, matchMethods));
					//System.out.println(extractMethod.getDeclaringType().getTypeQualifiedName());
					//System.out.println(extractMethod);
				}
			}
		}}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return extractMethods;
	}
	
	
	//����addIMethod�����ǳ�ȡ�ķ���������IMethod�����򷵻ؿ�
	public IMethod getExtractMethod(String oldProjectName, String newProjectName, 
			IMethod addIMethod, Map<JavaMethod, JavaMethod> matchmethods) throws JavaModelException{
		IMethod extractMethod = null;
		if(isExtractMethod(getMaxDiffValue(oldProjectName, newProjectName, addIMethod, matchmethods))){
			extractMethod = addIMethod;
		}
		return extractMethod;
	}
	
	
	//�ж��Ƿ��ȡ�ķ���
	public boolean isExtractMethod(double maxDiffValue){
		if(maxDiffValue >= DIFFVALUE_CONSTANT){
			return true;
		}
		return false;
	}
	
	
	//����addIMethod�������ֵ
	public double getMaxDiffValue(String oldProjectName, String newProjectName, 
			IMethod addIMethod, Map<JavaMethod, JavaMethod> matchmethods) throws JavaModelException{
		double diffValue = 0.0;
		ArrayList<IMethod> invocationMethods = Util.getInvocationMethods(newProjectName, addIMethod);
		if(invocationMethods != null && invocationMethods.size() != 0){
			for(IMethod invocationMethod : invocationMethods){
				JavaMethod qualifiedMethodName = Util.getQualifiedMethodName(invocationMethod);
				JavaMethod oldQualifiedMethodName = Util.searchMatchMethod(qualifiedMethodName, matchmethods);
				if(oldQualifiedMethodName == null) continue;
				IMethod oldIMethod = Util.getIMethod(oldProjectName, oldQualifiedMethodName);
				diffValue = getMax(diffValue, getDiffValue(oldIMethod, invocationMethod, addIMethod));
				}}
		
				
		return diffValue;
		}
	public Map<JavaMethod,JavaMethod> getDuiyingMap(String oldProjectName, String newProjectName, 
			IMethod addIMethod, Map<JavaMethod, JavaMethod> matchmethods) throws JavaModelException{
		
		Map<JavaMethod,JavaMethod> JavaMethodDuiying=new IdentityHashMap<JavaMethod,JavaMethod>();
		double diffValue = 0.0;
		ArrayList<IMethod> invocationMethods = Util.getInvocationMethods(newProjectName, addIMethod);
		if(invocationMethods != null && invocationMethods.size() != 0){
			for(IMethod invocationMethod : invocationMethods){
				JavaMethod qualifiedMethodName = Util.getQualifiedMethodName(invocationMethod);
				JavaMethod oldQualifiedMethodName = Util.searchMatchMethod(qualifiedMethodName, matchmethods);
				if(oldQualifiedMethodName == null) continue;
				IMethod oldIMethod = Util.getIMethod(oldProjectName, oldQualifiedMethodName);
				diffValue = getMax(diffValue, getDiffValue(oldIMethod, invocationMethod, addIMethod));
				if(diffValue>= DIFFVALUE_CONSTANT){
					//JavaMethod oldwrite=new JavaMethod();
					//oldwrite=Classifier.getmethodofwrite(oldIMethod);
					//JavaMethod extractwrite=new JavaMethod();
					//extractwrite=Classifier.getmethodofwrite(addIMethod);
					//Duiying.put(oldwrite, extractwrite);
					JavaMethodDuiying.put(Util.getQualifiedMethodName(addIMethod),oldQualifiedMethodName);
					}}}
		
				
		return  JavaMethodDuiying;
		}

	/*public ArrayList<MethodOfWrite> getwritemethods(String oldProjectName, String newProjectName, 
			IMethod addIMethod, HashMap<QualifiedMethodName, QualifiedMethodName> matchMethods){
		double diffValue = 0.0;
		ArrayList<MethodOfWrite> writemethods=new ArrayList<MethodOfWrite>();
		
		ArrayList<IMethod> invocationMethods = Util.getInvocationMethods(newProjectName, addIMethod);
		if(invocationMethods != null && invocationMethods.size() != 0){
			for(IMethod invocationMethod : invocationMethods){
				QualifiedMethodName qualifiedMethodName = Util.getQualifiedMethodName(invocationMethod);
				QualifiedMethodName oldQualifiedMethodName = Util.searchMatchMethod(qualifiedMethodName, matchMethods);
				if(oldQualifiedMethodName == null) continue;
				if(Util.getIMethod(oldProjectName, oldQualifiedMethodName).exists()){
				IMethod oldIMethod = Util.getIMethod(oldProjectName, oldQualifiedMethodName);
				diffValue = getMax(diffValue, getDiffValue(oldIMethod, invocationMethod, addIMethod));
			if(diffValue>= DIFFVALUE_CONSTANT){
				MethodOfWrite awrite=new MethodOfWrite();
				String com=null;
				ICompilationUnit compilation=null;
				if(oldIMethod.getCompilationUnit()!=null){
					compilation=oldIMethod.getCompilationUnit();
				if(compilation!=null){
				com=compilation.getElementName();
				if(com!=null){
				awrite.packagename=oldQualifiedMethodName.getPackageName();
				awrite.compiname=com;
				awrite.methodname=oldQualifiedMethodName.getMethodName();
				awrite.paranum=oldIMethod.getNumberOfParameters();
				writemethods.add(awrite);}}}}
			}
		}}
		return writemethods;
	}
	*/
	//���ز��ֵ
	public double getDiffValue(IMethod oldIMethod, IMethod newIMethod, IMethod addIMethod){
		ArrayList<String> oldIMethodSources = new ArrayList<String>();
		ArrayList<String> newIMethodSources = new ArrayList<String>();
		ArrayList<String> addIMethodSources = new ArrayList<String>();
		
		MethodDeclaration oldMethodDec = Util.getMethodDeclarationFromIMethod(oldIMethod);
		MethodDeclaration newMethodDec = Util.getMethodDeclarationFromIMethod(newIMethod);
		MethodDeclaration addMethodDec = Util.getMethodDeclarationFromIMethod(addIMethod);
		if(oldIMethod==null|| newIMethod==null ||addIMethod==null) return 0.0;
		if(oldMethodDec == null || newMethodDec == null || addMethodDec == null){
			return 0.0;
		} else {
			if(oldMethodDec.getBody() == null || newMethodDec.getBody() == null || addMethodDec.getBody() == null
					|| oldMethodDec.getBody().toString() == null || newMethodDec.getBody().toString() == null
					|| addMethodDec.getBody().toString() == null || oldMethodDec.getBody().toString().trim().isEmpty()
					|| newMethodDec.getBody().toString().trim().isEmpty() || addMethodDec.getBody().toString().trim().isEmpty()){
				return 0.0;
			}
			oldIMethodSources = Util.getFileToLines(oldMethodDec.getBody().toString());	
			newIMethodSources = Util.getFileToLines(newMethodDec.getBody().toString());	
			addIMethodSources = Util.getFileToLines(addMethodDec.getBody().toString());
			if(oldIMethodSources == null || newIMethodSources == null || addIMethodSources == null
					|| oldIMethodSources.size() == 0 || newIMethodSources.size() == 0 || addIMethodSources.size() == 0){
				return 0.0;
			}
		}
		
		return getDiffValue(oldIMethodSources, newIMethodSources, addIMethodSources);
	}
	
	
	//���ز��ֵ
	public double getDiffValue(ArrayList<String> oldIMethodSources, ArrayList<String> newIMethodSources, ArrayList<String> addIMethodSources){
		double finalDiffValue = 0.0;
		if(oldIMethodSources.isEmpty()||newIMethodSources.isEmpty()||addIMethodSources.isEmpty()) return 0.0;
		List<String> methodDeltas = new ArrayList<String>();
		//methodDeltas.add("{");
		Patch firstPatch = DiffUtils.diff(oldIMethodSources, newIMethodSources);      
		
		for (Delta firstDelta: firstPatch.getDeltas()) {
			
			Chunk chunk = firstDelta.getOriginal();
			//firstDelta.getType().equals(Delta.TYPE.DELETE)
			
			if(chunk.size() != 0) 
		methodDeltas.addAll((Collection<? extends String>) firstDelta.getOriginal().getLines());
		//System.out.println(firstDelta.getOriginal().getLines());
			
		}
		//System.out.println("over");
		//methodDeltas.add("}");
	
		if(methodDeltas.size()!=0){
		double diffValue = 0.0;
		Patch secondPatch = DiffUtils.diff(addIMethodSources,methodDeltas);
		for (Delta secondDelta: secondPatch.getDeltas()) {
			//System.out.println(secondDelta);
			//System.out.println(secondDelta.getOriginal().size());
			
			diffValue += secondDelta.getOriginal().size();
		}
		
		finalDiffValue = getMax(finalDiffValue,( addIMethodSources.size()-diffValue)/addIMethodSources.size());
	
		}
		return finalDiffValue;
	}
	
	public static double testgetDiffValue(ArrayList<String> oldIMethodSources, ArrayList<String> newIMethodSources){
		double finalDiffValue = 0.0;
		
		List<String> methodDeltas = new ArrayList<String>();
		//methodDeltas.add("{");
		Patch firstPatch = DiffUtils.diff(oldIMethodSources, newIMethodSources);      
		
		for (Delta firstDelta: firstPatch.getDeltas()) {
			Chunk chunk = firstDelta.getOriginal();
			//firstDelta.getType().equals(Delta.TYPE.DELETE)
			System.out.println(firstDelta);
			if(firstDelta.getType().equals(Delta.TYPE.DELETE))  System.out.println("delete"+"\t"+firstDelta.getOriginal().size()+"\t"+firstDelta.getRevised().size());
			if(firstDelta.getType().equals(Delta.TYPE.INSERT))  System.out.println("add"+"\t"+firstDelta.getOriginal().size()+"\t"+firstDelta.getRevised().size());
			
			if(firstDelta.getType().equals(Delta.TYPE.CHANGE))  System.out.println("change"+"\t"+firstDelta.getOriginal().size()+"\t"+firstDelta.getRevised().size());
			if(chunk.size() != 0) methodDeltas.addAll((Collection<? extends String>) firstDelta.getOriginal().getLines());
		//System.out.println(firstDelta.getOriginal().getLines());
		
		}
		//System.out.println("over");
		//methodDeltas.add("}");
		double diffValue = 0.0;
		/*Patch secondPatch = DiffUtils.diff(addIMethodSources, methodDeltas);
		for (Delta secondDelta: secondPatch.getDeltas()) {
			System.out.println(secondDelta);
			System.out.println(secondDelta.getOriginal().size());
			diffValue += secondDelta.getOriginal().size();
		}
		
		finalDiffValue = getMax(finalDiffValue, (addIMethodSources.size()-diffValue)/addIMethodSources.size());
	*/
		
		return finalDiffValue;
	}
	
	//�������ֵ
	public double getMax(double x, double y){
		return x > y ? x : y;
	}
	
}
