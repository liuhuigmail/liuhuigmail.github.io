package tool;

import java.sql.SQLException;
import java.util.ArrayList;

import org.eclipse.core.resources.IProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.MethodDeclaration;

import edu.washington.cs.rules.JavaMethod;

public class CalculateMloc {
	
	public static void calculatemloc() throws JavaModelException, SQLException
	{
		String table="mloc";
		int n=0;
		IProject[] project = Util.getIProjects();
		for(int i=0;i<project.length;i++)
		{
			String ProjectName = project[i].getName().toString();
			ArrayList<IPackageFragment> packagearray=new ArrayList<IPackageFragment>();
			packagearray=Util.getIPackages(ProjectName);
			for(int j=0;j<packagearray.size();j++)
			{
				ArrayList<IType> typearray=new ArrayList<IType>();
				typearray=Util.getClasses(packagearray.get(j));
				for(int k=0;k<typearray.size();k++)
				{
					IMethod[] methodarray=typearray.get(k).getMethods();
					for(int p=0;p<methodarray.length;p++)
					{
						String version=ProjectName.substring(ProjectName.indexOf("-")+1);
						String versionid="'"+version+"'";
					JavaMethod javamethod=	Util.getQualifiedMethodName(methodarray[p]);
					ArrayList<String> para=new ArrayList<String>();
					String par ="'";
					
					String packagename="'"+javamethod.getPackageName()+"'";
					
					String comname="'"+javamethod.getClassName()+"'";
					String methodname="'"+javamethod.getProcedureName()+"'";
			        para=javamethod.getParameters();
			        for(int q=0;q<para.size();q++)
			        	par=par+para.get(q)+",";
			        par=par+"'";
					
			
					MySqlConnection cd=new MySqlConnection();
			         
			        cd.ConnectMysql();
					
					
					
			       
			        
			     
			    
						int mloc;
						MethodDeclaration MethodDec = Util.getMethodDeclarationFromIMethod(methodarray[p]);	
					    
						if(MethodDec==null || MethodDec.getBody()==null) mloc=0;
						else{
						 mloc=getLines(MethodDec.getBody().toString())-2;}
						String insql="insert into "+ table+"(package,source,method,par,VersionID,MLOC) values("+packagename+","+comname+","+methodname+","+par+","+versionid+","+mloc+")";
						n++;   
						cd.InsertSql(insql);
						     
					         cd.CutConnection(cd.conn);
					}
				}
			}
			
		}
		
	}
	//���ַ���ת��Ϊ�Իس�Ϊ�ָ������ַ�������
		public static int getLines(String content){
			ArrayList<String> lines = new ArrayList<String>();
			
			if(content == null || content.trim().isEmpty()) {
				//lines.add("");
				return lines.size();
			}
			String[] line = content.split("\n");
			for(String str : line){
				str = str.trim();
				
				
				if(!str .equals(""))
					lines.add(str);
			}
			return lines.size(); 
		}
	

}
