package tool;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;





import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.xml.sax.SAXException;

import difflib.Chunk;
import difflib.Delta;
import difflib.DiffUtils;
import difflib.Patch;
import edu.washington.cs.induction.OnePipeLineScript;
import edu.washington.cs.others.ComparisonAnalysisViewer;
import edu.washington.cs.others.ThreeWayComparison;
import edu.washington.cs.rules.JavaMethod;

public class Main {
	
	public static void detectMethodExtract() throws IOException, SAXException, JavaModelException, SQLException {
	
		
		SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String TimeString = time.format(new java.util.Date());
			System.out.println(TimeString);
			try{
            int p=1;
           
           
			IProject[] project = Util.getIProjects();
           String filepath1;
           String filepath2;
			File dir = new File("E:\\freecolsrc\\"); // ָ��ɨ���ļ���·��
			File files[] = dir.listFiles(); // �г�ָ��·�������е��ļ�����file������
			int n1=0;  //extractmethod�ܸ���
			for (int m = 0; m < files.length-1; m++) {
			filepath1=files[m].getAbsolutePath();
			filepath2=files[m+1].getAbsolutePath();
			 File desFile = new File("f:\\wekalist.txt");
		   FileWriter desWriter = new FileWriter(desFile);
		   desWriter.write(filepath1+"\r\n");
		   desWriter.write(filepath2);
		   desWriter.close();
		  
        String dirlist="f:\\wekalist.txt";
		String projectname="freecol";
		String oldversion=null;
		String newversion=null;
		
		OnePipeLineScript.pipeLineScript(true, true, projectname, 0.7, 0.34, dirlist, false, ThreeWayComparison.XING);
		oldversion=filepath1.substring(filepath1.indexOf("-")+1);
		newversion=filepath2.substring(filepath2.indexOf("-")+1);
	//	System.out.println("�ɰ汾��"+oldversion);
		//System.out.println("�°汾"+newversion);
		String oldversionid="'"+oldversion+"'";
		String newversionid="'"+newversion+"'";
		ComparisonAnalysisViewer.compare(dirlist, projectname, 0.7, 0.34,oldversion, ComparisonAnalysisViewer.NOTHING);
	 String matchfilename="F:\\LikelyChangeRule\\LCR-Data-CameraReadySubmit\\matching\\freecol\\"+oldversion+"-"+newversion+"0.7_0.34matching.xml";
		
	
		
		//�õ���������
		
		String oldProjectName = project[m].getName().toString();
		String newProjectName = project[m+1].getName().toString();
		//System.out.println("�ɹ���"+oldProjectName);
		//System.out.println("�¹���"+newProjectName);
		//ArrayList<MethodOfWrite> wrMethods=new ArrayList<MethodOfWrite>();
		//�õ�����ƥ��ķ���
		ProcessMethodsLevel process=new ProcessMethodsLevel();
	Map <JavaMethod,JavaMethod> matchmethods=new LinkedHashMap<JavaMethod,JavaMethod>();
		
		
		
		matchmethods=process.getMatchMethodsByTool(dirlist, projectname, matchfilename);
				
		//�õ��°汾�������ӵķ���	
		ArrayList<JavaMethod> Addmethods=new ArrayList<JavaMethod>();
		Addmethods=process.getaddmethods(dirlist, projectname,matchmethods);
		System.out.println("�°汾�������ӵķ�������	" + Addmethods.size());
		
		ArrayList<IMethod> addmethod=new ArrayList<IMethod>();
		addmethod=Util.getIMethods(newProjectName, Addmethods);
		System.out.println(addmethod.size());
	
		//�����ò���  ���ﱣ�������ӵķ���
		Detector detector = new Detector();
		
		//�õ���ȡ�ķ���
		ArrayList<IMethod> extractMethods = detector.getExtractMethods(oldProjectName, newProjectName, addmethod, matchmethods);
	
		
		
		 
		int n2=extractMethods.size();
		n1=n1+n2;
		int n3=n1-n2;
		System.out.println("��ȡ�ķ�������	" + extractMethods.size());
		
		Map<JavaMethod,JavaMethod> JavaMethodDuiying=new IdentityHashMap<JavaMethod,JavaMethod>();
		for(IMethod addIMethod: extractMethods)
		JavaMethodDuiying.putAll(detector.getDuiyingMap(oldProjectName, newProjectName, addIMethod, matchmethods));
		String table="duiyingtable";
		String recordreftable="recordref";
		String matchtable="matchtable";
		
		//System.out.println(JavaMethodDuiying.size());
	
	Map<JavaMethod,Integer> Extracttypemap=new LinkedHashMap<JavaMethod,Integer>();
		Classifier classifier = new Classifier();
		//ͳ�Ʒ����ȡ�ķ���,д���ļ�
		classifier.statisticsExtractMethods(oldProjectName, newProjectName, extractMethods, matchmethods);
		//��������ĳ�ȡ������д���ļ�
		Extracttypemap=	classifier.analysesExtractMethods(oldProjectName, newProjectName, extractMethods, matchmethods);
		
		//System.out.println(Extracttypemap.size());
		if(Extracttypemap!=null){

		Iterator<Entry<JavaMethod, Integer>> mapIter1 = Extracttypemap.entrySet().iterator();
		
		
		while(mapIter1.hasNext()){
			
			
			
			Entry<JavaMethod, Integer> entry = mapIter1.next();
			ArrayList<String> para=new ArrayList<String>();
			String par ="'";
			
			String packagename="'"+entry.getKey().getPackageName()+"'";
			
			String comname="'"+entry.getKey().getClassName()+"'";
			String methodname="'"+entry.getKey().getProcedureName()+"'";
	        para=entry.getKey().getParameters();
	        for(int k=0;k<para.size();k++)
	        	par=par+para.get(k)+",";
	        par=par+"'";
	        int flag=1;
		int extracttype=entry.getValue();
		String matchID=0+"";
		
			String insql="insert into "+ table+"(ID,package,source,method,par,ExtractType,VersionID,Flag,MatchID) values("+p+","+packagename+","+comname+","+methodname+","+par+","+extracttype+","+newversionid+","+flag+","+matchID+")";
		//	String sql="update "+newversiontable+" set ExtractType="+extracttype+" where package="+packagename+" and source="+comname+" and method="+methodname+" and par="+paranum;
	//	System.out.println(insql);
			MySqlConnection cd=new MySqlConnection();
	         
	        cd.ConnectMysql();
			
			
			
	       
	        
	        cd.InsertSql(insql);
	       p++;
	         cd.CutConnection(cd.conn);
	    
			//System.out.println(entry.getKey().packagename+"\t"+entry.getKey().compiname+"\t"+entry.getKey().methodname+"\t"+entry.getKey().paranum+"\t"+entry.getValue());
		}	
		
		Iterator<Entry<JavaMethod, JavaMethod>> mapIter = JavaMethodDuiying.entrySet().iterator();
		while(mapIter.hasNext()){
			Entry<JavaMethod, JavaMethod> entry = mapIter.next();
			ArrayList<String> newpara=new ArrayList<String>();
			String newpar ="'";
			String newpackagename="'"+entry.getKey().getPackageName()+"'";
			String newcomname="'"+entry.getKey().getClassName()+"'";
			String newmethodname="'"+entry.getKey().getProcedureName()+"'";
			 newpara=entry.getKey().getParameters();
			  for(int k=0;k<newpara.size();k++)
		        	newpar=newpar+newpara.get(k)+",";
		        newpar=newpar+"'";
			String sql="Select * FROM "+ table+" where package="+newpackagename+" and source="+newcomname+" and method="+newmethodname+" and par="+newpar+"  and VersionID="+newversionid;
			String newversionID=null;
			
				MySqlConnection cd=new MySqlConnection();
	         
	         cd.ConnectMysql();
	       
	      
	      newversionID=cd.SelectSql(sql);
	        
	       
			ArrayList<String> para=new ArrayList<String>();
		String par="'";
			String packagename="'"+entry.getValue().getPackageName()+"'";
			String comname="'"+entry.getValue().getClassName()+"'";
			String methodname="'"+entry.getValue().getProcedureName()+"'";
			 para=entry.getValue().getParameters();
			 for(int k=0;k<para.size();k++)
		        	par=par+para.get(k)+",";
		        par=par+"'";
		        int flag=0;
		        int extracttype=0;
			
			
			String insql="insert into "+ table+"(ID,package,source,method,par,ExtractType,VersionID,Flag,MatchID) values("+p+","+packagename+","+comname+","+methodname+","+par+","+extracttype+","+oldversionid+","+flag+","+newversionID+")";
			
	      cd.InsertSql(insql);
	        
	        cd.CutConnection(cd.conn);
		p++;
		}
		
		}
			
	int n4=0;
		
		for(int q=0;q<n3;q++){
			int refnum;
			String sql="Select * FROM "+ matchtable+" where ID="+q+" and Version="+oldversionid;
				String oldjavamethod;
				MySqlConnection cd=new MySqlConnection();
				   
		         cd.ConnectMysql();
		         oldjavamethod=cd.SelectSql2(sql);
		         if(oldjavamethod==null) refnum=0;
		         else{
		         String packagename = null;
		         String sourcename = null;
		         String methodname = null;
		         String par = null;
		         
		         
		         ArrayList<String> para=new ArrayList<String>();
		       String[] oldstring=  oldjavamethod.split("\\*");
		       if(oldstring.length==4){
		       packagename=oldstring[0];
		       sourcename=oldstring[1];
		       methodname=oldstring[2];
		       par=oldstring[3];}
		       if(oldstring.length==3)
		       {
		    	   packagename=oldstring[0];
			       sourcename=oldstring[1];
			       methodname=oldstring[2];
		       }
		       if(par!=null){
		       String[] oldpa=par.split(",");
		       for(int g=0;g<oldpa.length;g++)
		    	   para.add(oldpa[g]);}
		    JavaMethod oldversionmethod=new JavaMethod(packagename,sourcename,methodname,para,null);
		    JavaMethod newversionmethod=Util.searchMatchMethod2(oldversionmethod, matchmethods);
		   if(newversionmethod==null) refnum=0;
		   else {
		    IMethod method=Util.getIMethod(newProjectName, newversionmethod);
		    if(method==null){
				
				 refnum=0;
					 
				 }
		    else
		    {
		    	
		    	
		    	ArrayList<IMethod> invocationMethods = new ArrayList<IMethod>();
		    	 invocationMethods=Util.getInvocationMethods(newProjectName,method);
					refnum=invocationMethods.size();
					 
		    }	
		    }
		   if(newversionmethod!=null){
			   ArrayList<String> para1=new ArrayList<String>();
			    String par1="'";
				String packagename1="'"+newversionmethod.getPackageName()+"'";
				String comname1="'"+newversionmethod.getClassName()+"'";
				String methodname1="'"+newversionmethod.getProcedureName()+"'";
				 para1=newversionmethod.getParameters();
				 if(para1.size()!=0){
				 for(int k=0;k<(para1.size()-1);k++)
			        	par1=par1+para1.get(k)+",";
				 par1=par1+para1.get(para1.size()-1);}
			        par1=par1+"'";
			        
			        
			        String insql="insert into "+ matchtable+"(ID,Version,package,source,method,par) values("+q+","+newversionid+","+packagename1+","+comname1+","+methodname1+","+par1+")";
				

						 cd.InsertSql(insql);
			   
		   }
		}
		   String insql2="insert into "+recordreftable+" (ID,Version,Num) values("+q+","+newversionid+","+refnum+")";
			 cd.InsertSql(insql2);
			 cd.CutConnection(cd.conn);
		    	n4++;
		    }
		
		    	
		 
		    for(int l=n4;l<n1;l++	)
		{
		    	
		    	
		    	IMethod method=	extractMethods.get(l-n4);
		    	JavaMethod  javamethodextract= Util.getQualifiedMethodName(method);

		    	ArrayList<String> para=new ArrayList<String>();
		        String par="'";
		    	String packagename="'"+javamethodextract.getPackageName()+"'";
		    	String comname="'"+javamethodextract.getClassName()+"'";
		    	String methodname="'"+javamethodextract.getProcedureName()+"'";
		    	 para=javamethodextract.getParameters();
		    	 if(para.size()!=0){
		    	 for(int k=0;k<(para.size()-1);k++)
		            	par=par+para.get(k)+",";
		    	 par=par+para.get(para.size()-1);}
		            par=par+"'";
		            
		            
		            String insql="insert into "+ matchtable+"(ID,Version,package,source,method,par) values("+l+","+newversionid+","+packagename+","+comname+","+methodname+","+par+")";
		    	

		    		MySqlConnection cd=new MySqlConnection();
		       
		             cd.ConnectMysql();
		    			int refnum;
		    			ArrayList<IMethod> invocationMethods = new ArrayList<IMethod>();
		    			
		    			 invocationMethods=Util.getInvocationMethods(newProjectName,method);
		    		refnum=invocationMethods.size();
		    			 String insql2="insert into "+recordreftable+" (ID,Version,Num) values("+l+","+newversionid+","+refnum+")";
		    			 cd.InsertSql(insql2);
		    			 cd.InsertSql(insql);
		    			 cd.CutConnection(cd.conn);
		    		}
		
			
			
		}}catch(Exception e)
		{
			e.printStackTrace();
		}
	
			}	
	public static void DiaoyongRecord() throws IOException, JavaModelException, SQLException
	{
		SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String TimeString = time.format(new java.util.Date());
		System.out.println(TimeString);
		
        int p=113;
       String table="recorddiaoyongtable";
       
		IProject[] project = Util.getIProjects();
       String filepath1;
       String filepath2;
		File dir = new File("E:\\vuzesrc1\\"); // ָ��ɨ���ļ���·��
		File files[] = dir.listFiles(); // �г�ָ��·�������е��ļ�����file������
		for (int m = 0; m < files.length-1; m++) {
		filepath1=files[m].getAbsolutePath();
		filepath2=files[m+1].getAbsolutePath();
		 File desFile = new File("f:\\wekalist.txt");
	   FileWriter desWriter = new FileWriter(desFile);
	   desWriter.write(filepath1+"\r\n");
	   desWriter.write(filepath2);
	   desWriter.close();
	  
    String dirlist="f:\\wekalist.txt";
	String projectname="vuze";
	String oldversion=null;
	String newversion=null;
	
	OnePipeLineScript.pipeLineScript(true, true, projectname, 0.7, 0.34, dirlist, false, ThreeWayComparison.XING);
	oldversion=filepath1.substring(filepath1.indexOf("-")+1);
	newversion=filepath2.substring(filepath2.indexOf("-")+1);
	String oldversionid="'"+oldversion+"'";
	String newversionid="'"+newversion+"'";
	ComparisonAnalysisViewer.compare(dirlist, projectname, 0.7, 0.34,oldversion, ComparisonAnalysisViewer.NOTHING);
    String matchfilename="F:\\LikelyChangeRule\\LCR-Data-CameraReadySubmit\\matching\\vuze\\"+oldversion+"-"+newversion+"0.7_0.34matching.xml";
	//�õ���������
	
	String oldProjectName = project[m].getName().toString();
	String newProjectName = project[m+1].getName().toString();
	
	//�õ�����ƥ��ķ���
	ProcessMethodsLevel process=new ProcessMethodsLevel();
    Map <JavaMethod,JavaMethod> matchmethods=new LinkedHashMap<JavaMethod,JavaMethod>();
	matchmethods=process.getMatchMethodsByTool(dirlist, projectname, matchfilename);
	String duiyingtable="duiyingtable";
	ArrayList<Integer> IDlist=new ArrayList<Integer>();
	String SelectExtractMethodIDsql="SELECT * FROM "+duiyingtable+" where VersionID="+newversionid+" and Flag=1";	
	MySqlConnection cd=new MySqlConnection();
    cd.ConnectMysql();	
    IDlist=cd.SelectSqlIDList(SelectExtractMethodIDsql);
    if(IDlist!=null || IDlist.size()!=0)
    {
    	for(int i=0;i<IDlist.size();i++)
    	{
    		String SelectExtractMethod="SELECT * FROM "+duiyingtable+" where ID="+IDlist.get(i);
    	    String strjavamethod=cd.SelectSql2(SelectExtractMethod);
    	    String packagename = null;
            String sourcename = null;
            String methodname = null;
            String par = null;
           ArrayList<String> para=new ArrayList<String>();
      String[] oldstring=  strjavamethod.split("\\*");
      if(oldstring.length==4){
      packagename=oldstring[0];
      sourcename=oldstring[1];
      methodname=oldstring[2];
      par=oldstring[3];}
      if(oldstring.length==3)
      {
   	   packagename=oldstring[0];
	       sourcename=oldstring[1];
	       methodname=oldstring[2];
      }
      if(par!=null){
     para=Util.getparatype2(par.substring(0, par.length()-1));}
   JavaMethod extractjavamethod=new JavaMethod(packagename,sourcename,methodname,para,null);
  if (extractjavamethod!=null){
   IMethod extractmethod=Util.getIMethod(newProjectName, extractjavamethod);
   if(extractmethod!=null){
   ArrayList<IMethod> invocationMethods = new ArrayList<IMethod>();
   invocationMethods=Util.getInvocationMethods(newProjectName,extractmethod);
   if(invocationMethods != null && invocationMethods.size() != 0){
		for(IMethod invocationMethod : invocationMethods){
			int flag=0;
			int matchold=0;
			int extractid=IDlist.get(i);
			JavaMethod qualifiedMethodName = Util.getQualifiedMethodName(invocationMethod);
			ArrayList<String> dypara=new ArrayList<String>();
	        String dypar="'";
	    	String dypackagename="'"+qualifiedMethodName.getPackageName()+"'";
	    	String dycomname="'"+qualifiedMethodName.getClassName()+"'";
	    	String dymethodname="'"+qualifiedMethodName.getProcedureName()+"'";
	    	 dypara=qualifiedMethodName.getParameters();
	    	 if(dypara.size()!=0){
	    	 for(int k=0;k<(dypara.size()-1);k++)
	            	dypar=dypar+dypara.get(k)+",";
	    	 dypar=dypar+dypara.get(dypara.size()-1);}
	            dypar=dypar+"'";
	            JavaMethod oldqualifiedMethodName = Util.searchMatchMethod(qualifiedMethodName, matchmethods);
			if(oldqualifiedMethodName != null){ 
				flag=1;
				ArrayList<String> olddypara=new ArrayList<String>();
		        String olddypar="'";
		    	String olddypackagename="'"+oldqualifiedMethodName.getPackageName()+"'";
		    	String olddycomname="'"+oldqualifiedMethodName.getClassName()+"'";
		    	String olddymethodname="'"+oldqualifiedMethodName.getProcedureName()+"'";
		    	 olddypara=oldqualifiedMethodName.getParameters();
		    	 if(olddypara.size()!=0){
		    	 for(int k=0;k<(olddypara.size()-1);k++)
		            	olddypar=olddypar+olddypara.get(k)+",";
		    	 olddypar=olddypar+olddypara.get(olddypara.size()-1);}
		            olddypar=olddypar+"'";
		            String sql="Select * FROM "+ duiyingtable+" where package="+olddypackagename+" and source="+olddycomname+" and method="+olddymethodname+" and par="+olddypar+"  and VersionID="+oldversionid;
			String olddyID=cd.SelectSql(sql);
			if(olddyID!=null){
				matchold=Integer.parseInt(olddyID);
				
			}
			
			}
			String insertsql="insert into "+ table+"(ID,package,source,method,par,VersionID,Flag,MatcholdID,MatchExtractID) "
					+ "values("+p+","+dypackagename+","+dycomname+","+dymethodname+","+dypar+","+newversionid+","+flag+","+matchold+","+extractid+")";
			
			
			cd.InsertSql(insertsql);
		p++;	
    	}
    }}
    
		
    	}	}}
    cd.CutConnection(cd.conn);}	
		
	
	}

	static int extractmethodzongshu=384;
	static int yinyongcishumax=260;
	
	static int exmethodsumbutlastversion=382;//extractmethod��ȥ���һ���汾�ĸ���
	static int exmethodsumbutlastversiont1=141;
	static int exmethodsumbutlastversiont2=63;
	static int exmethodsumbutlastversiont3=127;
	static int exmethodsumbutlastversiont4=51;
	public static void analysis() throws SQLException
	{
		
		String recordreftable="recordref";
		
		String anatable="anasistable";
		String extracttypetable="extracttypetable";
		
		for(int p=0;p<extractmethodzongshu;p++){
		
		//	String sql="update "+newversiontable+" set ExtractType="+extracttype+" where package="+packagename+" and source="+comname+" and method="+methodname+" and par="+paranum;
	//	System.out.println(insql);
			String extracttype=null;
			String firstref=null;
			String maxref=null;
			int reuse;
			
		String sql="Select * FROM  "+ extracttypetable+" where ID="+p;
		String sql1="SELECT * FROM  "+recordreftable+" where ID="+p+" limit 0,1" ;
		String sql2="Select * from  "+ recordreftable+" where ID="+p+" order by Num desc limit 0,1" ;
		MySqlConnection cd=new MySqlConnection();
	         
	        cd.ConnectMysql();
	       
			
			extracttype=cd.SelectSql4(sql);
	       firstref=cd.SelectSql3(sql1);
	       maxref=cd.SelectSql3(sql2);
	      reuse= Integer.parseInt(maxref)-Integer.parseInt(firstref);
	       String insql="insert into "+ anatable+" (ID,ExtractType,Num1,Num2,Sub) values("+p+","+extracttype+","+firstref+","+maxref+","+reuse+")";
	        cd.InsertSql(insql);
	      
	         cd.CutConnection(cd.conn);
		}
		
		
	}
	//���ú����ô����Ĺ�ϵ
	public static void analysis2() throws SQLException
	{
		
		
	
		String anatable="anasistable";
		
		String reusevsref="reusevsreftable";
		
	
	
		for(int i=1;i<yinyongcishumax;i++){
			MySqlConnection cd=new MySqlConnection();
	        
	        cd.ConnectMysql();
		float sumref=0;
		int sumreuse=0;
		float bili;
		for(int p=0;p<extractmethodzongshu;p++){
			
		String firstref;
		String isreuse;
		String sql="Select * FROM  "+ anatable+" where ID="+p;
		
		
			isreuse=cd.SelectSql8(sql);
			firstref=cd.SelectSql9(sql);
			if(firstref.equals(i+"")){
				
			sumref++;
	    if(!isreuse.equals("0")) sumreuse++;
			}
	     
		}
		if(sumref==0||sumreuse==0) bili=0;
		else{bili=sumreuse/sumref;}
		
		  String insql="insert into "+ reusevsref+" (ref,sumref,sumreuse,baifenbi) values("+i+","+sumref+","+sumreuse+","+bili+")";
	        cd.InsertSql(insql);
	        cd.CutConnection(cd.conn);
	      
	       }  
		
	}
	//type1���ú����ô����Ĺ�ϵ
	public static void analysis2Type1() throws SQLException
	{
		
		
	
		String anatable="anasistable";
		
		String reusevsref="reusevsreftypeonetable";
		
		
	
		
		for(int i=1;i<yinyongcishumax;i++){
			
		float sumref=0;
		int sumreuse=0;
		float bili;
MySqlConnection cd=new MySqlConnection();
        
        cd.ConnectMysql();
		for(int p=0;p<extractmethodzongshu;p++){
			
		String firstref;
		String isreuse;
		String extracttype;
		
		String sql="Select * FROM  "+ anatable+" where ID="+p;
		  extracttype=cd.SelectSql4(sql);
		 
			if(extracttype.equals("1")){
				
					isreuse=cd.SelectSql8(sql);
					firstref=cd.SelectSql9(sql);
			if(firstref.equals(i+"")){
				
			sumref++;
	    if(!isreuse.equals("0")) sumreuse++;
			}
		
		}}
		if(sumref==0||sumreuse==0) bili=0;
		else{bili=sumreuse/sumref;}
		
		  String insql="insert into "+ reusevsref+" (ref,sumref,sumreuse,baifenbi) values("+i+","+sumref+","+sumreuse+","+bili+")";
	        cd.InsertSql(insql);
	        cd.CutConnection(cd.conn);
	      
	       }  
		
	}
	//type2���ú����ô����Ĺ�ϵ
	public static void analysis2Type2() throws SQLException
	{
		
		
	
		String anatable="anasistable";
		
		String reusevsref="reusevsreftypetwotable";
		
	
	
	
		for(int i=1;i<yinyongcishumax;i++){
			MySqlConnection cd=new MySqlConnection();
	        
	        cd.ConnectMysql();
			
		float sumref=0;
		int sumreuse=0;
		float bili;
		for(int p=0;p<extractmethodzongshu;p++){
			
		String firstref;
		String isreuse;
		String extracttype;
		
		String sql="Select * FROM  "+ anatable+" where ID="+p;
		
		   extracttype=cd.SelectSql4(sql);
			
			if(extracttype.equals("2")){
				isreuse=cd.SelectSql8(sql);
				firstref=cd.SelectSql9(sql);
			if(firstref.equals(i+"")){
				
			sumref++;
	    if(!isreuse.equals("0")) sumreuse++;
			}
		
		}}
		if(sumref==0||sumreuse==0) bili=0;
		else{bili=sumreuse/sumref;}
		
		  String insql="insert into "+ reusevsref+" (ref,sumref,sumreuse,baifenbi) values("+i+","+sumref+","+sumreuse+","+bili+")";
	        cd.InsertSql(insql);
	        cd.CutConnection(cd.conn);
	      
	       }  
		
	}
	//type3���ú����ô����Ĺ�ϵ
	public static void analysis2Type3() throws SQLException
	{
		
		
	
		String anatable="anasistable";
		
		String reusevsref="reusevsreftypethreetable";
		
	
		for(int i=1;i<yinyongcishumax;i++){
			MySqlConnection cd=new MySqlConnection();
	        
	        cd.ConnectMysql();
			
		float sumref=0;
		int sumreuse=0;
		float bili;
		for(int p=0;p<extractmethodzongshu;p++){
			
		String firstref;
		String isreuse;
		String extracttype;
		
		String sql="Select * FROM  "+ anatable+" where ID="+p;
		
		   extracttype=cd.SelectSql4(sql);
		
			if(extracttype.equals("3")){
				isreuse=cd.SelectSql8(sql);
				firstref=cd.SelectSql9(sql);
			if(firstref.equals(i+"")){
				
			sumref++;
	    if(!isreuse.equals("0")) sumreuse++;
			}
		
		}}
		if(sumref==0||sumreuse==0) bili=0;
		else{bili=sumreuse/sumref;}
		
		  String insql="insert into "+ reusevsref+" (ref,sumref,sumreuse,baifenbi) values("+i+","+sumref+","+sumreuse+","+bili+")";
	        cd.InsertSql(insql);
	        cd.CutConnection(cd.conn);
	      
	       } 
		
	}
	//type4���ú����ô����Ĺ�ϵ
	public static void analysis2Type4() throws SQLException
	{
		
		
	
		String anatable="anasistable";
		
		String reusevsref="reusevsreftypefourtable";
		
		
	
		for(int i=1;i<yinyongcishumax;i++){
			MySqlConnection cd=new MySqlConnection();
	        
	        cd.ConnectMysql();
			
		float sumref=0;
		int sumreuse=0;
		float bili;
		for(int p=0;p<extractmethodzongshu;p++){
			
		String firstref;
		String isreuse;
		String extracttype;
		
		String sql="Select * FROM  "+ anatable+" where ID="+p;
		
		   extracttype=cd.SelectSql4(sql);
			
			if(extracttype.equals("4")){
				isreuse=cd.SelectSql8(sql);
				firstref=cd.SelectSql9(sql);
			if(firstref.equals(i+"")){
				
			sumref++;
	    if(!isreuse.equals("0")) sumreuse++;
			}
		
		}}
		if(sumref==0||sumreuse==0) bili=0;
		else{bili=sumreuse/sumref;}
		
		  String insql="insert into "+ reusevsref+" (ref,sumref,sumreuse,baifenbi) values("+i+","+sumref+","+sumreuse+","+bili+")";
	        cd.InsertSql(insql);
	        cd.CutConnection(cd.conn);
	      
	       } 
		
	}
/*	public static void analysis3() throws SQLException
	{

		MySqlConnection cd=new MySqlConnection();
	         
	        cd.ConnectMysql();
		String recordreftable="recordref";
		
		String anatable="versionreuse";
	
		ArrayList<String> allversion=new ArrayList<String>();
		String sql="SELECT * FROM  "+recordreftable+"  group by Version" ;
		allversion=cd.SelectSql10(sql);
		
		for(int p=1;p<allversion.size();p++){
			float summethod=0;
			int sumreuse=0;
			float bili;
			String version=allversion.get(p);
			version="'"+version+"'";
			ArrayList<String> newversionextract=new ArrayList<String>();
			String sql1="SELECT * FROM  "+recordreftable+"  where Version="+version ;
		    newversionextract=cd.SelectSql11(sql1);
		    
		for(int i=0;i<newversionextract.size();i++){
			String anewversion=newversionextract.get(i);
			String s[]=anewversion.split(",");
			String newid=s[0];
			String newref=s[1];
			String oldref;
			String oldversion=allversion.get(p-1);
			oldversion="'"+oldversion+"'";
			int anewref=Integer.parseInt(newref);
			int anewid=Integer.parseInt(newid);
			String sql2="SELECT * FROM  "+recordreftable+"  where ID=" +anewid+" and Version="+oldversion;
			oldref=cd.SelectSql3(sql2);
			if(oldref!=null)
			{
				summethod++;
				int aoldref=Integer.parseInt(oldref);
				if((anewref-aoldref)>0)
					sumreuse++;
				
			}
		}
		bili=sumreuse/summethod;
	       String insql="insert into "+ anatable+" (Summethod,Sumreuse,Version,Bili) values("+summethod+","+sumreuse+","+version+","+bili+")";
	        cd.InsertSql(insql);
	      
	        
		}
		
		 cd.CutConnection(cd.conn);
	}*/
	//�������Ű汾�ı仯
	public static void analysis4() throws SQLException
	{

		MySqlConnection cd1=new MySqlConnection();
	         
	        cd1.ConnectMysql();
	      
		String recordreftable="recordref";
		
		String anatable="versionReusetable";
	
		ArrayList<String> allversion=new ArrayList<String>();
		String sql="SELECT * FROM  "+recordreftable+"  group by Version" ;
		allversion=cd1.SelectSql10(sql);
		 cd1.CutConnection(cd1.conn);
		int sumofversion=allversion.size();
	    for(int i=1;i<sumofversion;i++){
	    	MySqlConnection cd=new MySqlConnection();
	         
	        cd.ConnectMysql();
	    	
	  
	    float sumreuse=0;
	    float bili;
	    
		for(int p=0;p<extractmethodzongshu;p++){
			String firstref;
			String oldversion;
			
			
			String sql1="SELECT * FROM  "+recordreftable+" where ID="+p+" limit 0,1" ;
			  firstref=cd.SelectSql3(sql1);
			  oldversion=cd.SelectSql12(sql1);
			  int flag = 0;
			  int intfirstref=Integer.parseInt(firstref);
			  for(int j=0;j<allversion.size();j++)
			  {if(oldversion.equals(allversion.get(j))){
				  flag=j;
			  break;
			  }
				  }
			  for(int k=1;k<=i;k++){
				  String newversion = null;
				  String newref;
			  if((flag+k)<sumofversion){
				  
				 newversion=allversion.get(flag+k); 
				 newversion="'"+newversion+"'";
				  
			  
			String sql2="SELECT * FROM  "+recordreftable+"  where ID=" +p+" and Version="+newversion;
		newref=cd.SelectSql3(sql2);
			
				int anewref=Integer.parseInt(newref);
				if((anewref-intfirstref)>0){
					sumreuse++;
				break;}
			}}}
		if(sumreuse==0||exmethodsumbutlastversion==0) bili=0;
		else
		bili=sumreuse/exmethodsumbutlastversion;
	       String insql="insert into "+ anatable+" (ID,Summethod,Sumref,Bili) values("+i+","+exmethodsumbutlastversion+","+sumreuse+","+bili+")";
	        cd.InsertSql(insql);
	      
	        cd.CutConnection(cd.conn);
	       
	    }
		
	}
	//type1�������Ű汾�ı仯
	public static void analysisType1() throws SQLException
	{

		MySqlConnection cd1=new MySqlConnection();
	         
	        cd1.ConnectMysql();
	     
		String recordreftable="recordref";
		
		String anatable="Type1versionReusetable";
	    String extracttable="extracttypetable";
		ArrayList<String> allversion=new ArrayList<String>();
		String sql="SELECT * FROM  "+recordreftable+"  group by Version" ;
		allversion=cd1.SelectSql10(sql);
		 cd1.CutConnection(cd1.conn);
		int sumofversion=allversion.size();
	    for(int i=1;i<sumofversion;i++){
	    	MySqlConnection cd=new MySqlConnection();
	         
	        cd.ConnectMysql();
	    	
	 
	    float sumreuse=0;
	    float bili;
	    
		for(int p=0;p<extractmethodzongshu;p++){
			String firstref;
			String oldversion;
			String extracttype;
			
			String sql1="SELECT * FROM  "+recordreftable+" where ID="+p+" limit 0,1" ;
			String sqlextracttype="SELECT * FROM  "+extracttable+" where ID="+p ;
			extracttype=cd.SelectSql4(sqlextracttype);
			if(extracttype.equals("1")){
			firstref=cd.SelectSql3(sql1);
			  oldversion=cd.SelectSql12(sql1);
			  int flag = 0;
			  int intfirstref=Integer.parseInt(firstref);
			  for(int j=0;j<allversion.size();j++)
			  {if(oldversion.equals(allversion.get(j))){
				  flag=j;
			  break;
			  }
				  }
			  for(int k=1;k<=i;k++){
				  String newversion = null;
				  String newref;
			  if((flag+k)<sumofversion){
				  
				 newversion=allversion.get(flag+k); 
				 newversion="'"+newversion+"'";
				  
			  
			String sql2="SELECT * FROM  "+recordreftable+"  where ID=" +p+" and Version="+newversion;
		newref=cd.SelectSql3(sql2);
			
				int anewref=Integer.parseInt(newref);
				if((anewref-intfirstref)>0){
					sumreuse++;
				break;}
			}}}}
		if(sumreuse==0||exmethodsumbutlastversiont1==0) bili=0;
		else
		bili=sumreuse/exmethodsumbutlastversiont1;
	       String insql="insert into "+ anatable+" (ID,Summethod,Sumref,Bili) values("+i+","+exmethodsumbutlastversiont1+","+sumreuse+","+bili+")";
	        cd.InsertSql(insql);
	      
	        cd.CutConnection(cd.conn);
	       
	    }
		
	}
	
	//type2�������Ű汾�ı仯
	public static void analysisType2() throws SQLException
	{

		MySqlConnection cd1=new MySqlConnection();
	         
	        cd1.ConnectMysql();
	       
		String recordreftable="recordref";
		
		String anatable="Type2versionReusetable";
	    String extracttable="extracttypetable";
		ArrayList<String> allversion=new ArrayList<String>();
		String sql="SELECT * FROM  "+recordreftable+"  group by Version" ;
		allversion=cd1.SelectSql10(sql);
		 cd1.CutConnection(cd1.conn);
		int sumofversion=allversion.size();
	    for(int i=1;i<sumofversion;i++){
	    	MySqlConnection cd=new MySqlConnection();
	         
	        cd.ConnectMysql();
	    	
	 
	    float sumreuse=0;
	    float bili;
	    
		for(int p=0;p<extractmethodzongshu;p++){
			String firstref;
			String oldversion;
			String extracttype;
			
			String sql1="SELECT * FROM  "+recordreftable+" where ID="+p+" limit 0,1" ;
			String sqlextracttype="SELECT * FROM  "+extracttable+" where ID="+p ;
			extracttype=cd.SelectSql4(sqlextracttype);
			if(extracttype.equals("2")){
			firstref=cd.SelectSql3(sql1);
			  oldversion=cd.SelectSql12(sql1);
			  int flag = 0;
			  int intfirstref=Integer.parseInt(firstref);
			  for(int j=0;j<allversion.size();j++)
			  {if(oldversion.equals(allversion.get(j))){
				  flag=j;
			  break;
			  }
				  }
			  for(int k=1;k<=i;k++){
				  String newversion = null;
				  String newref;
			  if((flag+k)<sumofversion){
				  
				 newversion=allversion.get(flag+k); 
				 newversion="'"+newversion+"'";
				  
			  
			String sql2="SELECT * FROM  "+recordreftable+"  where ID=" +p+" and Version="+newversion;
		newref=cd.SelectSql3(sql2);
			
				int anewref=Integer.parseInt(newref);
				if((anewref-intfirstref)>0){
					sumreuse++;
				break;}
			}}}}
		if(sumreuse==0||exmethodsumbutlastversiont2==0) bili=0;
		else
		bili=sumreuse/exmethodsumbutlastversiont2;
	       String insql="insert into "+ anatable+" (ID,Summethod,Sumref,Bili) values("+i+","+exmethodsumbutlastversiont2+","+sumreuse+","+bili+")";
	        cd.InsertSql(insql);
	      
	        cd.CutConnection(cd.conn);
	       
	    }
		
	}
	
	//type3�������Ű汾�ı仯
	public static void analysisType3() throws SQLException
	{

		MySqlConnection cd1=new MySqlConnection();
	         
	        cd1.ConnectMysql();
	        
		String recordreftable="recordref";
		
		String anatable="Type3versionReusetable";
	    String extracttable="extracttypetable";
		ArrayList<String> allversion=new ArrayList<String>();
		String sql="SELECT * FROM  "+recordreftable+"  group by Version" ;
		allversion=cd1.SelectSql10(sql);
		 cd1.CutConnection(cd1.conn);
		int sumofversion=allversion.size();
	    for(int i=1;i<sumofversion;i++){
	    	MySqlConnection cd=new MySqlConnection();
	         
	        cd.ConnectMysql();
	    	
	 
	    float sumreuse=0;
	    float bili;
	    
		for(int p=0;p<extractmethodzongshu;p++){
			String firstref;
			String oldversion;
			String extracttype;
			
			String sql1="SELECT * FROM  "+recordreftable+" where ID="+p+" limit 0,1" ;
			String sqlextracttype="SELECT * FROM  "+extracttable+" where ID="+p ;
			extracttype=cd.SelectSql4(sqlextracttype);
			if(extracttype.equals("3")){
			firstref=cd.SelectSql3(sql1);
			  oldversion=cd.SelectSql12(sql1);
			  int flag = 0;
			  int intfirstref=Integer.parseInt(firstref);
			  for(int j=0;j<allversion.size();j++)
			  {if(oldversion.equals(allversion.get(j))){
				  flag=j;
			  break;
			  }
				  }
			  for(int k=1;k<=i;k++){
				  String newversion = null;
				  String newref;
			  if((flag+k)<sumofversion){
				  
				 newversion=allversion.get(flag+k); 
				 newversion="'"+newversion+"'";
				  
			  
			String sql2="SELECT * FROM  "+recordreftable+"  where ID=" +p+" and Version="+newversion;
		newref=cd.SelectSql3(sql2);
			
				int anewref=Integer.parseInt(newref);
				if((anewref-intfirstref)>0){
					sumreuse++;
				break;}
			}}}}
		if(sumreuse==0||exmethodsumbutlastversiont3==0) bili=0;
		else
		bili=sumreuse/exmethodsumbutlastversiont3;
	       String insql="insert into "+ anatable+" (ID,Summethod,Sumref,Bili) values("+i+","+exmethodsumbutlastversiont3+","+sumreuse+","+bili+")";
	        cd.InsertSql(insql);
	      
	        cd.CutConnection(cd.conn);
	       
	    }
		
	}
	
	//type4�������Ű汾�ı仯
	public static void analysisType4() throws SQLException
	{

		MySqlConnection cd1=new MySqlConnection();
	         
	        cd1.ConnectMysql();
	       
		String recordreftable="recordref";
		
		String anatable="Type4versionReusetable";
	    String extracttable="extracttypetable";
		ArrayList<String> allversion=new ArrayList<String>();
		String sql="SELECT * FROM  "+recordreftable+"  group by Version" ;
		allversion=cd1.SelectSql10(sql);
		 cd1.CutConnection(cd1.conn);
		int sumofversion=allversion.size();
	    for(int i=1;i<sumofversion;i++){
	    	MySqlConnection cd=new MySqlConnection();
	         
	        cd.ConnectMysql();
	    	
	 
	    float sumreuse=0;
	    float bili;
	    
		for(int p=0;p<extractmethodzongshu;p++){
			String firstref;
			String oldversion;
			String extracttype;
			
			String sql1="SELECT * FROM  "+recordreftable+" where ID="+p+" limit 0,1" ;
			String sqlextracttype="SELECT * FROM  "+extracttable+" where ID="+p ;
			extracttype=cd.SelectSql4(sqlextracttype);
			if(extracttype.equals("4")){
			firstref=cd.SelectSql3(sql1);
			  oldversion=cd.SelectSql12(sql1);
			  int flag = 0;
			  int intfirstref=Integer.parseInt(firstref);
			  for(int j=0;j<allversion.size();j++)
			  {if(oldversion.equals(allversion.get(j))){
				  flag=j;
			  break;
			  }
				  }
			  for(int k=1;k<=i;k++){
				  String newversion = null;
				  String newref;
			  if((flag+k)<sumofversion){
				  
				 newversion=allversion.get(flag+k); 
				 newversion="'"+newversion+"'";
				  
			  
			String sql2="SELECT * FROM  "+recordreftable+"  where ID=" +p+" and Version="+newversion;
		newref=cd.SelectSql3(sql2);
			
				int anewref=Integer.parseInt(newref);
				if((anewref-intfirstref)>0){
					sumreuse++;
				break;}
			}}}}
		if(sumreuse==0||exmethodsumbutlastversiont4==0) bili=0;
		else
		bili=sumreuse/exmethodsumbutlastversiont4;
	       String insql="insert into "+ anatable+" (ID,Summethod,Sumref,Bili) values("+i+","+exmethodsumbutlastversiont4+","+sumreuse+","+bili+")";
	        cd.InsertSql(insql);
	      
	        cd.CutConnection(cd.conn);
	       
	    }
		
	}
	
	//extractmethod��û��move
	public static void analysismove() throws SQLException
	{
		String table="duiyingtable";
		
		
		String anatable="anasismovetable";
		String extracttypetable="extracttypetable";
		
		for(int p=0;p<extractmethodzongshu;p++){
		
		//	String sql="update "+newversiontable+" set ExtractType="+extracttype+" where package="+packagename+" and source="+comname+" and method="+methodname+" and par="+paranum;
	//	System.out.println(insql);
			
			String oldid=null;
			String extractpackage=null;
			String extractsource=null;
			ArrayList<String> oldpackage=null;
			ArrayList<String> oldsource=null;
			int issamepackage=0;
			int issamesource=0;
			String extracttype=null;
		String sql="Select * FROM "+ extracttypetable+" where ID="+p;
		
		
		MySqlConnection cd=new MySqlConnection();
	         
	        cd.ConnectMysql();
	       
	        extracttype=cd.SelectSql4(sql);
			oldid=cd.SelectSql7(sql);
			extractpackage=cd.SelectSql5(sql);
			extractsource=cd.SelectSql6(sql);
			String sql1="SELECT * FROM "+table+" where MatchID="+oldid;
	     oldpackage=cd.SelectSql55(sql1);
	     oldsource=cd.SelectSql66(sql1);
	     if(oldpackage==null||oldpackage.size()==0||extractpackage==null||oldsource==null||oldsource.size()==0||extractsource==null)
	     {
	    	 issamepackage=1;
	    	 issamesource=1;
	     }
	     else{
	    	 for(int i1=0;i1<oldpackage.size();i1++){
	     if((oldpackage.get(i1).trim()).equals(extractpackage.trim()))
	     {issamepackage=1;
	     break;
	     }
	    }
	    	 for(int i2=0;i2<oldsource.size();i2++){
	     if((oldsource.get(i2).trim()).equals(extractsource.trim()))  
	    	 {issamesource=1;
	    	 break;
	    	 }
	    	 }
	     }
	       String insql="insert into "+ anatable+"(ID,SameClass,SamePackage,ExtractType) values("+p+","+issamesource+","+issamepackage+","+extracttype+")";
	        cd.InsertSql(insql);
	      
	         cd.CutConnection(cd.conn);
		}
		
		
	}

	
	public static void Insertmloc() throws SQLException
	{
		String table="duiyingtable";
		String metrictable="mloc";
		String sql1="Select * FROM  "+ table+" where Flag=0"; //suoyoujiubanbende id
		MySqlConnection cd=new MySqlConnection();
        
        cd.ConnectMysql();
     
		ArrayList<Integer> arrayID=cd.SelectSqlIDList(sql1);
		cd.CutConnection(cd.conn);
		for(int i=0;i<arrayID.size();i++){
			MySqlConnection cd1=new MySqlConnection();
	        
	        cd1.ConnectMysql();
		String sql2="Select * FROM  "+ table+" where ID="+arrayID.get(i);  //jiubanbendematch id
		String matchId=cd1.SelectSqlMatchid(sql2);
		String versionid1=cd1.SelectSqlVersion(sql2);
		String packagename1=cd1.SelectSql5(sql2);
		String sourcename1=cd1.SelectSql6(sql2);
		String methodname1=cd1.SelectSqlMethodname(sql2);
		String  par1=cd1.SelectSqlPAR(sql2);
		String sql3="Select * FROM  "+ table+" where ID="+Integer.parseInt(matchId);      //xinbanbende extracttype
	    String extracttype=cd1.SelectSql4(sql3);
	    int intextracttype=Integer.parseInt(extracttype);
		String updatesql2="update "+ table+" set ExtractType=" +intextracttype+" where ID="+arrayID.get(i);
		 cd1.UpdateSql(updatesql2);
		 String sqlversionid="'"+versionid1+"'";
		 String minidsql="SELECT * FROM "+metrictable+" where VersionID="+sqlversionid +" limit 0,1 ";
		 String maxidsql="SELECT * FROM "+metrictable+" where VersionID="+sqlversionid +" order by ID desc limit 0,1 ";
		 int minid=Integer.parseInt(cd1.SelectSql(minidsql));
		 int maxid=Integer.parseInt(cd1.SelectSql(maxidsql));
		 
		 int j=minid;
		 while(j<maxid)
		 {
			String sql4="Select * FROM  "+ metrictable+" where ID="+j;
			
			String versionid2=cd1.SelectSqlVersion(sql4);
			String packagename2=cd1.SelectSql5(sql4);
			String sourcename2=cd1.SelectSql6(sql4);
			String methodname2=cd1.SelectSqlMethodname(sql4);
			String  par2=cd1.SelectSqlPAR(sql4);
			if(versionid2!=null && versionid2.equals(versionid1) )
			{
			  if(packagename1.equals(packagename2) && sourcename1.equals(sourcename2) && methodname1.equals(methodname2)
					  )	
			  {
				 
				  if((par1==null && par2==null)||(par1 !=null && par2!=null && par1.equals(par2))){
				  String updatesql="update "+ metrictable+" set ExtractType=" +intextracttype+" where ID="+j; 
				  String updatesql1="update "+ metrictable+" set IsExtract=" +1+" where ID="+j; 
				  cd1.UpdateSql(updatesql);
				  cd1.UpdateSql(updatesql1);
				  break;}
				  
				  }
			  }
			
			 j++;}
		 
		 cd1.CutConnection(cd1.conn);
		}
		
	}
	public static void AnalazyRelationship() throws SQLException
	{
		String metrictable="mloc";
		int max=1144;
		int MaxConst=400;
		int jiangearray[]={5,10,20,30,40,50};
		for(int j=0;j<jiangearray.length;j++){
		int jiange=jiangearray[j];
		int n=max/jiange;
		int jiange1=0;
		int jiange2=jiange;
		
		MySqlConnection cd=new MySqlConnection();
        cd.ConnectMysql();
     
		for(int i=0;i<=n;i++){
			
		 String	 Allsql="SELECT * FROM "+metrictable+" where MLOC<="+jiange2+" and MLOC>"+jiange1;
		 String IsExtractsql="SELECT * FROM "+metrictable+" where MLOC<="+jiange2+" and MLOC>"+jiange1+" and IsExtract=1";
		int shuchu=jiange1;
		 int sum=cd.SelectSqlSum(Allsql);
		int extractsum=cd.SelectSqlSum(IsExtractsql);
		float extracthe=extractsum;
		float percentage=extracthe/sum;
		
		while(sum<MaxConst && i<=n){
		jiange1=jiange2;
		jiange2=jiange2+jiange;
		 String	 Allsql1="SELECT * FROM "+metrictable+" where MLOC<="+jiange2+" and MLOC>"+jiange1;
		 String IsExtractsql1="SELECT * FROM "+metrictable+" where MLOC<="+jiange2+" and MLOC>"+jiange1+" and IsExtract=1";
		sum=sum+cd.SelectSqlSum(Allsql1);
		extractsum=extractsum+cd.SelectSqlSum(IsExtractsql1);
		extracthe=extractsum;
	   percentage=extracthe/sum; 
		i++;
		
		
				  } 
		
		System.out.println(shuchu+"\t"+jiange2+"\t"+extractsum+"\t"+sum+"\t"+percentage);
		jiange1=jiange2;
		jiange2=jiange2+jiange;
			  }
		cd.CutConnection(cd.conn);
	}	}
		
	public static String getNextSymmetricNumber(String n) {
        if(n==null|| n=="")
            return null;
      
            
        String str2="";
      if(n!= null && !"".equals(n)){
      for(int j=0;j<n.length();j++){
     if(n.charAt(j)>=48 && n.charAt(j)<=57){
       str2+=n.charAt(j);
     }}}
    
        int stringtoInt=Integer.parseInt(str2.trim());
        int i=stringtoInt+1;
        String nextsymmetric=null;
        String reversenextsymmetric=null;
        while(i>stringtoInt)
            {
            nextsymmetric=i+"";
            StringBuffer bufnextsymmetric = new StringBuffer(nextsymmetric);
            bufnextsymmetric.reverse();
          reversenextsymmetric =bufnextsymmetric.toString();
            if(nextsymmetric.equals(reversenextsymmetric))
               break;
            i++;
        }
        System.out.println(nextsymmetric);
return nextsymmetric;

    }	
	//correct the type2 and type4
	public static void NewClassify() throws SQLException
	{
		int newExtractType = 0;
		String table="duiyingtable";
		String recordreftable="recordref";
		String extracttypetable="extracttypetable";

		MySqlConnection cd=new MySqlConnection();
	    cd.ConnectMysql();
		String selectsql="SELECT * FROM "+extracttypetable+" where ExtractType=2 or ExtractType=4;";
		Map<String,String> IDMap=new HashMap<String,String>();
		IDMap=cd.SelectOldIDAndID(selectsql);
		
       Iterator<Entry<String, String>> mapIter1 = IDMap.entrySet().iterator();
		
		
		while(mapIter1.hasNext()){
			
			Entry<String, String> entry = mapIter1.next();
			String oldID=entry.getKey();
		    String ID=entry.getValue();
		
			String sql1="SELECT * FROM  "+recordreftable+" where ID="+ID+" limit 0,1" ;
		    String	  firstref=cd.SelectSql3(sql1);
			 int intfirstref=Integer.parseInt(firstref);
			
	      
			String sql2="SELECT * FROM "+table+" where MatchID="+oldID;
	        int intextractNum=cd.SelectSqlSum(sql2);
	        if(intfirstref==intextractNum)
	        	newExtractType=2;
	        if(intextractNum==1)
	        	newExtractType=3;
	        if((intextractNum<intfirstref)&&(intextractNum>1))
	        	newExtractType=4;
	        
       String updatesql1="update "+table+" set ExtractType="+newExtractType+" where ID="+oldID;
       String updatesql2="update "+extracttypetable+" set ExtractType="+newExtractType+" where ID="+ID;
	    cd.UpdateSql(updatesql1);
	     cd.UpdateSql(updatesql2);
		}
		
		cd.CutConnection(cd.conn);
	}
	
		
	}
	


		
	//	String TimeString1 = time.format(new java.util.Date());
		//System.out.println(TimeString1);*
	


