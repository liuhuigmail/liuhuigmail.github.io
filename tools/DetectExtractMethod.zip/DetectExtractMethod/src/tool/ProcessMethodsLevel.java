package tool;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;







import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.MethodDeclaration;






import edu.washington.cs.extractors.ExtractMethods;
import edu.washington.cs.extractors.ProgramSnapshot;
import edu.washington.cs.extractors.ReadDirectories;
import edu.washington.cs.extractors.SeedMatchGenerator;
import edu.washington.cs.rules.JavaMethod;
import edu.washington.cs.util.ListOfPairs;
import edu.washington.cs.util.Pair;

public class ProcessMethodsLevel {
	

	public  ArrayList<JavaMethod> getnewmethods(String dirList, String project)
	{
		ArrayList<JavaMethod> newmethods=new ArrayList<JavaMethod>();
		
       File[] dirs = ReadDirectories.getDirectories(dirList);
		
		ProgramSnapshot oldP = null ;
		ProgramSnapshot newP = null;
		for (int i = 0; i < dirs.length-1; i++) {
			oldP = new ProgramSnapshot(project,dirs[i]);
			newP = new ProgramSnapshot(project,dirs[i+1]);
		}
		
		newmethods=newP.getMethods();
		return newmethods;
		
		
	}
	public  Map <JavaMethod,JavaMethod> getMatchMethodsExtractlyByNames(String dirList, String project)
	{
		ArrayList<JavaMethod> oldmethods=new ArrayList<JavaMethod>();
		ArrayList<JavaMethod> newmethods=new ArrayList<JavaMethod>();
		Map <JavaMethod,JavaMethod> matchmethods=new LinkedHashMap<JavaMethod,JavaMethod>();
       File[] dirs = ReadDirectories.getDirectories(dirList);
		
		ProgramSnapshot oldP = null ;
		ProgramSnapshot newP = null;
		for (int i = 0; i < dirs.length-1; i++) {
			oldP = new ProgramSnapshot(project,dirs[i]);
			newP = new ProgramSnapshot(project,dirs[i+1]);
		}
		oldmethods=oldP.getMethods();
		newmethods=newP.getMethods();
		
			for(JavaMethod newMethod : newmethods){
				for(JavaMethod oldMethod : oldmethods){
				if(oldMethod.equals(newMethod)){
					matchmethods.put(oldMethod, newMethod);
					break;
					
				}}
			}
		return matchmethods;
		
		}
	
		public  Map<JavaMethod ,JavaMethod> getMatchMethodsByTool(String dirList, String project,String matchfilename) 
		{
			
			Map <JavaMethod,JavaMethod> MatchMethods=new LinkedHashMap<JavaMethod,JavaMethod>();
			MatchMethods=getMatchMethodsExtractlyByNames(dirList,project);
			ListOfPairs listpair = null;
			try {
				listpair = ListOfPairs.newreadXMLFile(matchfilename);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//	System.out.println(listpair.size());
			for(int i=0;i<listpair.size();i++)
			{
				Pair p=listpair.get(i);
				p.getLeft();
				JavaMethod leftm = null;
				JavaMethod rightm = null;
				if(p.getLeft() instanceof JavaMethod){
					 leftm=(JavaMethod) p.getLeft();
					
					//System.out.println(leftm.getPackageName()+"  "+leftm.getClassName()+"  "+leftm.getProcedureName());
					}
				p.getRight();
				if(p.getRight() instanceof JavaMethod){
					 rightm=(JavaMethod) p.getRight();
					//System.out.println(rightm.getPackageName()+"  "+rightm.getClassName()+"  "+rightm.getProcedureName());
					}
				if((!containskey(MatchMethods,leftm))&&(!containsvalue(MatchMethods,rightm)))
				{MatchMethods.put(leftm, rightm);
			//	System.out.println(i);
				}
				
			}
			System.out.println("Matchsize"+MatchMethods.size());
			return MatchMethods;
			
		}
	
		/*public static void getMatchMethodsByTool2() throws IOException, Exception
		{
			String filename="F:\\LikelyChangeRule\\LCR-Data-CameraReadySubmit\\matching\\ant\\1.8.3-1.9.00.7_0.34matching.xml";
			
			
			ListOfPairs listpair=	ListOfPairs.newreadXMLFile(filename);
		//	System.out.println(listpair.size());
			for(int i=0;i<listpair.size();i++)
			{
				Pair p=listpair.get(i);
				p.getLeft();
				JavaMethod leftm = null;
				JavaMethod rightm = null;
				if(p.getLeft() instanceof JavaMethod){
					 leftm=(JavaMethod) p.getLeft();
					
					//System.out.println(leftm.getPackageName()+"  "+leftm.getClassName()+"  "+leftm.getProcedureName());
					}
				p.getRight();
				if(p.getRight() instanceof JavaMethod){
					 rightm=(JavaMethod) p.getRight();
					//System.out.println(rightm.getPackageName()+"  "+rightm.getClassName()+"  "+rightm.getProcedureName());
					}
				if(!(leftm.getProcedureName().equals(rightm.getProcedureName()))){
				System.out.println(leftm);
				System.out.println(rightm);
				
				}
				
			}
			
			
		}
		*/
	public  boolean containskey(Map<JavaMethod,JavaMethod> matchmap,JavaMethod method)
	{
		boolean yy=false;
		java.util.Iterator<Entry<JavaMethod, JavaMethod>> iter= matchmap.entrySet().iterator();
    	
    	while(iter.hasNext()){
    		
    		 Map.Entry<JavaMethod,JavaMethod> entry=iter.next();
	         JavaMethod amethod=entry.getKey();
	         if(amethod.equals(method))
	         {
	        	 yy=true;
	        	 break;
	         }
	      
		
		
	}
    	return yy;
	}
	public  boolean containsvalue(Map<JavaMethod,JavaMethod> matchmap,JavaMethod method)
	{
		boolean yy=false;
		java.util.Iterator<Entry<JavaMethod, JavaMethod>> iter= matchmap.entrySet().iterator();
    	
    	while(iter.hasNext()){
    		
    		 Map.Entry<JavaMethod,JavaMethod> entry=iter.next();
	         JavaMethod amethod=entry.getValue();
	         if(amethod.equals(method))
	         {
	        	 yy=true;
	        	 break;
	         }
	      
		
		
	}
    	return yy;
	}
	
	public  ArrayList<JavaMethod> getaddmethods(String dirList, String project,Map <JavaMethod,JavaMethod> MatchMethods)
	{
		ArrayList<JavaMethod> addmethods=new ArrayList<JavaMethod>();
		ArrayList<JavaMethod> newmethods=new ArrayList<JavaMethod>();
		
		newmethods=getnewmethods(dirList, project);
for(JavaMethod method : newmethods){
	boolean yy=true;
	java.util.Iterator<Entry<JavaMethod, JavaMethod>> iter= MatchMethods.entrySet().iterator();
    	while(iter.hasNext()){
    		
    		 Map.Entry<JavaMethod,JavaMethod> entry=iter.next();
	         JavaMethod amethod=entry.getValue();
	         if(amethod.equals(method))
	         {
	        	yy=false;
	        	break;
	        	
	         }
    	}
    	if(yy){
    		if(addmethods.size()==0)
    		addmethods.add(method);
    	if(addmethods.size()!=0)
    	{
    		if(!contains(addmethods,method))
    			addmethods.add(method);
    	}
    	}
    	
}

		return addmethods;
	
	
	

	}
	public  boolean contains(ArrayList<JavaMethod> methods,JavaMethod method)
	{
		boolean yy=false;
		
    	for(int i=0;i<methods.size();i++){
    		JavaMethod amethod=methods.get(i);
    		 
	         if(amethod.equals(method))
	         {
	        	 yy=true;
	        	 break;
	         }
	      
		
		
	}
    	return yy;
	}
	
	
}