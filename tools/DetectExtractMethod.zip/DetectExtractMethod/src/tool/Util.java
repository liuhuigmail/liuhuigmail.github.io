package tool;

import java.io.*;
import java.util.*;
import java.util.Map.Entry;



import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.ITypeHierarchy;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.search.IJavaSearchConstants;
import org.eclipse.jdt.core.search.IJavaSearchScope;
import org.eclipse.jdt.core.search.SearchEngine;
import org.eclipse.jdt.core.search.SearchMatch;
import org.eclipse.jdt.core.search.SearchParticipant;
import org.eclipse.jdt.core.search.SearchPattern;
import org.eclipse.jdt.core.search.SearchRequestor;
import org.eclipse.jface.action.IAction;

import difflib.Delta;
import difflib.DiffUtils;
import difflib.Patch;
import edu.washington.cs.rules.JavaMethod;

public class Util {
	
	//���������ռ䣬����������Ŀ
	public static IProject[] getIProjects(){
	
		
		return ResourcesPlugin.getWorkspace().getRoot().getProjects();
	}
	
	
	//���빤�������������Ӧ��JAVA��Ŀ
	public static IJavaProject getIJavaProject(String projectName){
		IJavaProject javaProject = null;
		IProject[] projects = getIProjects();
		for (IProject project : projects){
			if(project.getName().equals(projectName)){
				javaProject = JavaCore.create(project);
			}
		}
		return javaProject;
	}
	
	
	//���빤����������Դ�����ļ���Ŀ¼
	public static IPackageFragmentRoot getSourceCodeFolder(String projectName){
		IPackageFragmentRoot root = null;
		IJavaProject javaProject = getIJavaProject(projectName);
		if (javaProject.exists() && javaProject != null){
			try {
				for(IPackageFragmentRoot pr : javaProject.getPackageFragmentRoots()){
					if(pr.getKind()==IPackageFragmentRoot.K_SOURCE){
						root=pr;
						
					}
				}
			} catch (JavaModelException e) {
				e.printStackTrace();
			}
		}
		return root;
	}
	
	
	//Parsing ICompilationUnit, ���� CompilationUnit
	public static CompilationUnit parse(ICompilationUnit cu) {
		ASTParser parser = ASTParser.newParser(AST.JLS4);
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setSource(cu);
		parser.setResolveBindings(true); 
		return (CompilationUnit) parser.createAST(null); 
	}
	
	
	//����IMethod,������Ӧ��MethodDeclaration
	public static MethodDeclaration getMethodDeclarationFromIMethod(IMethod iMethod){
		MethodDeclaration methodDec = null;
		if(iMethod!=null){
		ICompilationUnit icu = iMethod.getCompilationUnit();
		if(icu != null && icu.getElementName().equals(iMethod.getCompilationUnit().getElementName())){
			CompilationUnit cu = parse(icu);
			ArrayList<MethodDeclaration> methods = getMethods(cu);
			if(methods != null && methods.size() != 0){
				Iterator<MethodDeclaration> iter = methods.iterator();
				while(iter.hasNext()){
					MethodDeclaration method = iter.next();
					IMethodBinding binding = method.resolveBinding();
					if(binding==null){
						System.out.println(iMethod);
					}
						
					if(binding!=null){
					if(method.getName().toString().equals(iMethod.getElementName()) && 
							equals(((IMethod)binding.getJavaElement()).getParameterTypes(),iMethod.getParameterTypes())){
						methodDec = method;
						break;}
					}
				}
			}
		}}
		return methodDec;
	}
		

	//����CompilationUnit�е����з���
	public static ArrayList<MethodDeclaration> getMethods(CompilationUnit cu){
		final ArrayList<MethodDeclaration> methods = new ArrayList<MethodDeclaration>();
		cu.accept(new ASTVisitor(){
			public boolean visit(MethodDeclaration node){
				methods.add(node);
				
				return false;
			}
		});
		return methods;
	}
	
	
	
	
		
	
	//�Ƚ��ַ��������Ƿ���ͬ������boolean
	public static boolean equals(String[] string1, String[] string2){
		if(string1 == null && string2 == null)return true;
		if(string1==null && string2!=null) return false;
		if(string1!=null && string2==null) return false;
		if(string1!=null && string2!=null){
		if(string1.length != string2.length)return false;
		if(string1.length == 0 && string2.length == 0)return true;
		for(int i = 0; i < string1.length; i++){
			if(!(string1[i].equals(string2[i]))){
				return false;
			}
		}}
		return true;
	}
	
	
	//���빤������QualifiedMethodName����������IMethod����
	public static ArrayList<IMethod> getIMethods(String projectName, ArrayList<JavaMethod> qualifiedMethodNames) throws JavaModelException{
		ArrayList<IMethod> iMethods = new ArrayList<IMethod>();
		try{
		for(JavaMethod qualifiedMethodName : qualifiedMethodNames){
			IMethod iMethod = getIMethod(projectName, qualifiedMethodName);
			if(iMethod != null){
				iMethods.add(iMethod);
			}
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return iMethods;
	}
	
	
	// ���빤�������������еİ�
		public static ArrayList<IPackageFragment> getIPackages(String projectName){
			ArrayList<IPackageFragment> iPackages = new ArrayList<IPackageFragment>();
			IPackageFragmentRoot root = Util.getSourceCodeFolder(projectName);
			try {
				for(IJavaElement iPack : root.getChildren()){
					if(iPack instanceof IPackageFragment){
						iPackages.add((IPackageFragment) iPack);
					}
				}
			} catch (JavaModelException e){
				e.printStackTrace();
			}
			return iPackages;
		}
		

		// ����������ذ��µ���������
		public static ArrayList<IType> getClasses(IPackageFragment iPackage){
			ArrayList<IType> classNames = new ArrayList<IType>();
			try {
				for(ICompilationUnit icu : iPackage.getCompilationUnits()){
					if(icu != null){
						IType[] iTypes = icu.getAllTypes();
						for(IType iType : iTypes){
							if(iType != null && iType.getElementType() == IJavaElement.TYPE){
								classNames.add(iType);
							}
						}
					}
				}
			} catch (JavaModelException e){
				e.printStackTrace();
			}
			return classNames;
		}
		

	
	//���빤������QualifiedMethodName������IMethod
	public static IMethod getIMethod(String projectName, JavaMethod qualifiedMethodName) throws JavaModelException{
		IType iType = null;
		IPackageFragment ipackage=null;
		IMethod iMethod = null;
		IJavaProject javaProject = getIJavaProject(projectName);
		IMethod[] allmethods;
		if(!qualifiedMethodName.getPackageName().isEmpty() && 
				!qualifiedMethodName.getClassName().isEmpty() && 
				!qualifiedMethodName.getProcedureName().isEmpty()){
			ArrayList<IPackageFragment> packages=new ArrayList<IPackageFragment>();
					packages=getIPackages(projectName);
			for(int k=0;k<packages.size();k++)
			{
				if(packages.get(k).getElementName().equals(qualifiedMethodName.getPackageName()))
				{ ipackage=packages.get(k);
				if(ipackage!=null){
					ArrayList<IType> classNames = new ArrayList<IType>();
					classNames=getClasses(ipackage);
					for(int j=0;j<classNames.size();j++)
					{
						String cn=qualifiedMethodName.getClassName();
						String rc=null;
						if(cn.contains("$")) {
							String cc[]=new String[2];
							 cc=cn.split("\\$");
							
						rc=cc[1];
						//System.out.println(rc);
						}
						if(rc==null) rc=cn;
						if(classNames.get(j).getElementName().equals(rc))
						{ iType=classNames.get(j);
						if(iType != null){
						String methodname=qualifiedMethodName.getProcedureName();
						ArrayList<String> para=qualifiedMethodName.getParameters();
						allmethods=iType.getMethods();
						for(int i=0;i<allmethods.length;i++){
							ArrayList<String> pa=getparatype(allmethods[i].toString());
							
							//boolean yy=equal(pa,para);
							//boolean yy2=allmethods[j].getElementName().equals(methodname);
						if(allmethods[i].getElementName().equals(methodname)&&equal(pa,para)){
							
							//for(int p=0;p<pa.size();p++)
							//	System.out.println(pa.get(p));
							//for(int p=0;p<para.size();p++)
								//System.out.println(para.get(p));
							iMethod = allmethods[i];
							break;
						}
					}}
				
			}
			
		}}
			if(iMethod!=null)	break;}}}
	return iMethod;
	}
	
	public static boolean equal(ArrayList<String> pa,ArrayList<String> p2)
	{
		int n,m;
		n=pa.size();
		m=p2.size();
		if(n!=m)return false;
		for (int i = 0; i <pa.size(); i++) {
			String thisPar = pa.get(i).trim();
			String otherPar = p2.get(i).trim();
			if (!thisPar.equals(otherPar))
				return false;
		}
		return true;
	}
	//���ض�IMethod�����˷������õĵ��÷���
	public static ArrayList<IMethod> getInvocationMethods(String projectName, IMethod iMethod){
		final ArrayList<IMethod> invocationMethods = new ArrayList<IMethod>();
		IPackageFragmentRoot sourceCodeFolder = getSourceCodeFolder(projectName);
		SearchPattern pattern = SearchPattern.createPattern(iMethod, IJavaSearchConstants.REFERENCES);
		IJavaSearchScope scope = SearchEngine.createJavaSearchScope(new IJavaElement[] {sourceCodeFolder});
		SearchRequestor requestor = new SearchRequestor() {
			public void acceptSearchMatch(SearchMatch match){
				Object obj=match.getElement();
				if(obj != null && obj instanceof IMethod ){
					invocationMethods.add((IMethod)obj);
				}
			}
		};
		SearchParticipant[] participants = new SearchParticipant[] {SearchEngine.getDefaultSearchParticipant()};
		SearchEngine searchEngine = new SearchEngine();
		try {
			searchEngine.search(pattern, participants, scope, requestor, null);
		} catch (CoreException e) {
			e.printStackTrace();
		}
		return invocationMethods;
	}
	
	
	//����IMethod�����ض�Ӧ��QualifiedMethodName
	public static JavaMethod getQualifiedMethodName(IMethod iMethod) throws JavaModelException{

		ArrayList<String> parameters=new ArrayList<String>();
		JavaMethod qualifiedMethodName=null;
		if(iMethod!=null){
		parameters=getparatype(iMethod.toString());
		String tyname=iMethod.getDeclaringType().getElementName();
		//System.out.println(tyname);
		if(iMethod.getDeclaringType().getParent().getElementType()==IJavaElement.TYPE){
			tyname=iMethod.getDeclaringType().getParent().getElementName()+"$"+tyname;
		
		}
		 qualifiedMethodName = new JavaMethod(iMethod.getDeclaringType().getPackageFragment().getElementName(),tyname,iMethod.getElementName(),parameters,getreturntype(iMethod.toString()));
		
		}
		return qualifiedMethodName;
	}

	public static String getreturntype(String s) throws JavaModelException
	{
		String returntype = null;
		int n=s.indexOf("(");
		s=s.substring(0, n);
		String ss[]=s.split(" ");
		if(ss.length==1)
			returntype="void";
		else if(ss.length==2)
			returntype=ss[0];
		else if(ss.length==3)
			returntype=ss[1];
		
		return returntype;
		
	}
	
	
	
public static ArrayList<String> getparatype(String sig)
{
	ArrayList<String> parameters=new ArrayList<String>();
	
	if(sig!=null)
	{
		if(sig.contains("(")&&sig.contains(")"))
		{
			int begin=sig.indexOf("(");
			int end=sig.indexOf(")");
			String s=sig.substring(begin+1,end);
			
			int itemcount = 1;

			if (s.length() > 0) {

				ArrayList<Integer> jiankuohao1=new ArrayList<Integer>();
				ArrayList<Integer> jiankuohao2=new ArrayList<Integer>();
				int n=0;
				
				for (int i = 0; i < s.length(); i++) {
					
					
					if (s.charAt(i) == '<') {
						jiankuohao1.add(i);
					}
					if(s.charAt(i)=='>')
					{
						jiankuohao2.add(i);
					}	}
				
				n=jiankuohao1.size();
				for (int i = 0; i < s.length(); i++){
				
					if (s.charAt(i) == ',') {
						boolean yy=true;
						for(int j=0;j<n;j++)
						{
							if(i<jiankuohao2.get(j)&&i>jiankuohao1.get(j)) 
							{
								yy=false;
								break;}
						
					}
						if(yy)
						itemcount++;}
				
				}}
			
				for (int i = 0; i < itemcount; i++) {
					String arg = null;
					
					boolean yy1=false;
					ArrayList<Integer> jiankuohao1=new ArrayList<Integer>();
					ArrayList<Integer> jiankuohao2=new ArrayList<Integer>();
					int n=0;
					if(s.length()>0){
					for (int k = 0; k < s.length(); k++) {

						
						if (s.charAt(k) == '<') {
							jiankuohao1.add(k);
						}
						if(s.charAt(k)=='>')
						{
							jiankuohao2.add(k);
						}
					}
					n=jiankuohao1.size();
					for (int k = 0; k < s.length(); k++) {
						if (s.charAt(k) == ',') {
							boolean yy=true;
							for(int j=0;j<n;j++)
							{
								if(j<jiankuohao2.size()){
								if(k<jiankuohao2.get(j)&&k>jiankuohao1.get(j)) 
								{
									yy=false;
									break;}}
							
						}
							if(yy)
							{
								yy1=true;
								arg = s.substring(0, k);
								s = s
										.substring(k + 2);
								parameters.add(arg);
								//System.out.println(arg);
								break;
							}
							
					}
				
					
					}	
					 if(!yy1){
						 arg = s;	
						// System.out.println(arg);
					 parameters.add(arg);}
			
				
		}
			
		
	}	}}
	
	return parameters;

}
	
	


public static ArrayList<String> getparatype2(String s)
{
	ArrayList<String> parameters=new ArrayList<String>();
	
	
			
			int itemcount = 1;

			if (s.length() > 0) {

				ArrayList<Integer> jiankuohao1=new ArrayList<Integer>();
				ArrayList<Integer> jiankuohao2=new ArrayList<Integer>();
				int n=0;
				
				for (int i = 0; i < s.length(); i++) {
					
					
					if (s.charAt(i) == '<') {
						jiankuohao1.add(i);
					}
					if(s.charAt(i)=='>')
					{
						jiankuohao2.add(i);
					}	}
				
				n=jiankuohao1.size();
				for (int i = 0; i < s.length(); i++){
				
					if (s.charAt(i) == ',') {
						boolean yy=true;
						for(int j=0;j<n;j++)
						{
							if(i<jiankuohao2.get(j)&&i>jiankuohao1.get(j)) 
							{
								yy=false;
								break;}
						
					}
						if(yy)
						itemcount++;}
				
				}}
			
				for (int i = 0; i < itemcount; i++) {
					String arg = null;
					
					boolean yy1=false;
					ArrayList<Integer> jiankuohao1=new ArrayList<Integer>();
					ArrayList<Integer> jiankuohao2=new ArrayList<Integer>();
					int n=0;
					if(s.length()>0){
					for (int k = 0; k < s.length(); k++) {

						
						if (s.charAt(k) == '<') {
							jiankuohao1.add(k);
						}
						if(s.charAt(k)=='>')
						{
							jiankuohao2.add(k);
						}
					}
					n=jiankuohao1.size();
					for (int k = 0; k < s.length(); k++) {
						if (s.charAt(k) == ',') {
							boolean yy=true;
							for(int j=0;j<n;j++)
							{
								if(j<jiankuohao2.size()){
								if(k<jiankuohao2.get(j)&&k>jiankuohao1.get(j)) 
								{
									yy=false;
									break;}}
							
						}
							if(yy)
							{
								yy1=true;
								arg = s.substring(0, k);
								s = s
										.substring(k + 1);
								parameters.add(arg);
								//System.out.println(arg);
								break;
							}
							
					}
				
					
					}	
					 if(!yy1){
						 arg = s;	
						// System.out.println(arg);
					 parameters.add(arg);}
			
				
		}
			
		
	}	
	
	return parameters;

}
	
	//���ַ���ת��Ϊ�Իس�Ϊ�ָ������ַ�������
	public static ArrayList<String> getFileToLines(String content){
		ArrayList<String> lines = new ArrayList<String>();
		
		if(content == null || content.trim().isEmpty()) {
			//lines.add("");
			return lines;
		}
		String[] line = content.split("\n");
		for(String str : line){
			str = str.trim();
			str=str.replace("{", "");
			str=str.replace("}", "");
			
			if(!str .equals(""))
				lines.add(str);
		}
		return lines; 
	}
	
	
	//�������°汾����ƥ��ľɰ汾����
	public static JavaMethod searchMatchMethod(JavaMethod qualifiedMethodName, 
			Map<JavaMethod, JavaMethod> matchmethods){
		JavaMethod oldQualifiedMethodName = null;
		Iterator<Entry<JavaMethod, JavaMethod>> mapIter = matchmethods.entrySet().iterator();
		while(mapIter.hasNext()){
			Entry<JavaMethod, JavaMethod> entry = mapIter.next();
			JavaMethod newQualifiedMethodName = entry.getValue();
			if(newQualifiedMethodName.equals(qualifiedMethodName)){
				oldQualifiedMethodName = entry.getKey();
				break;
			}
		}
		return oldQualifiedMethodName;
	}
	
	//������ɰ汾����ƥ����°汾����
	public static JavaMethod searchMatchMethod2(JavaMethod qualifiedMethodName, 
			Map<JavaMethod, JavaMethod> matchmethods){
		JavaMethod newQualifiedMethodName = null;
		Iterator<Entry<JavaMethod, JavaMethod>> mapIter = matchmethods.entrySet().iterator();
		while(mapIter.hasNext()){
			Entry<JavaMethod, JavaMethod> entry = mapIter.next();
			JavaMethod oldQualifiedMethodName = entry.getKey();
			if(oldQualifiedMethodName.equals(qualifiedMethodName)){
				newQualifiedMethodName = entry.getValue();
				break;
			}
		}
		return newQualifiedMethodName;
	}
	
	
}		