package tool;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;

public class CalculateMetrics {
	static String projectsrcpath="F:\\antsource";
	//static String projectsrcpath="F:\\findbugsSource";
	//static String projectsrcpath="F:\\jeditSource";
	//static String projectsrcpath="F:\\jfreechartsource";
	//static String projectsrcpath="F:\\wekaSource";
	//static String projectsrcpath="E:\\hibernate";
	static String projectname="ant"; 
	
	 public static void calculateMetrics() throws IOException, InterruptedException, SQLException
     //use javancss to calculate the ncss and ccn
     {
		 int n=505;
		 
	     final String table="duiyingtable";
	     for(int i=1;i<n;i++)
	    {
	    	final ArrayList<Integer> MLOC=new ArrayList<Integer>();
	    	final ArrayList<Integer>CCN=new ArrayList<Integer>();
	     String sql="Select * FROM "+ table+" where ID="+i;
	
	     String version="";
		 String packagename="";
		 String classname="";
		 String methodname="";
		 String para="";
		 String Pathpackagename="";
		 String Pathclassname="";
		 final String commethod;
		 ArrayList<String> parameter=new ArrayList<String>();
		 String absolupath=projectsrcpath+"\\";
		 String comclassname="";
		 String compara="";
		 MySqlConnection cd=new MySqlConnection();
		 cd.ConnectMysql();
		 packagename=cd.SelectSql5(sql);
	     classname=cd.SelectSql6(sql);
	     version=cd.SelectSqlVersion(sql);
	    para=cd.SelectSqlPAR(sql);
	   methodname=cd.SelectSqlMethodname(sql);
		/* packagename="org.apache.tools.zip";
         classname="ZipLong";
     	 version="1.6.5";
     	  para="byte[],int,";
		 methodname="ZipLong";*/
     	 if((para==null)||(para.length()==0)) compara="()";
     	 else
     	 {
     	
     	 para=para.substring(0, para.length()-1);
     	 //System.out.println(para);
     	 parameter=getparatype(para);
     	// System.out.println(parameter);
     	 compara="(";
     	 for(int j=0;j<(parameter.size()-1);j++)
     	 {compara=compara+parameter.get(j)+",";}
     	 compara=compara+parameter.get(parameter.size()-1);
     	 compara=compara+")";
     	 }
     	
    
     	 
     	
     	 
     	 Pathpackagename=packagename;
     	 Pathclassname=classname;
     	 Pathpackagename=Pathpackagename.replace(".","\\");
     	 comclassname=classname;
     	 if(Pathclassname.contains("$"))
     	 {
     		String [] ss=new String[2];
     		ss=Pathclassname.split("\\$") ;
     		Pathclassname=ss[0];
     		comclassname=comclassname.replace("$", ".");
     		 
     	 }
     	 
     	commethod=packagename+"."+comclassname+"."+methodname+compara;
     	absolupath=absolupath+projectname+"-"+version+"\\"+"src"+"\\"+Pathpackagename+"\\"+Pathclassname+".java";
        System.out.println(absolupath);
     //  System.out.println(commethod);
       if(!Pathclassname.equals("BasicEntityPersister")
        		&&(!Pathclassname.equals("AbstractCollectionPersister"))
    	  &&(!Pathclassname.equals("AbstractEntityPersister"))
        		&&(!Pathclassname.equals("SessionImpl"))
        		&&(!Pathclassname.equals("Dialect"))
        		&&(!Pathclassname.equals("SessionFactoryImpl"))
        		&&(!Pathclassname.equals("Configuration"))
    		   ){
     	String [] cmd=new String[]{"cmd.exe","/c","F: && cd F:\\javancss-32.53\\bin && javancss.bat -function "+absolupath};
		Process process =Runtime.getRuntime().exec(cmd);
		final InputStream is1 = process.getInputStream();
    	new Thread(new Runnable() {
    		    public void run() {
    		    
    		    	int ncss=0;
		        	int ccn=0;
    		    	String line=null;
    		        BufferedReader br = new BufferedReader(new InputStreamReader(is1));
    		       
    		        try {
    		        
    		        	
						while((line=br.readLine()) != null) 
						{//line=line.replace("Java NCSS: ", "");
							String s[]=line.split(" +");
							
							
						    String	quamethodname=s[s.length-1];
						   // System.out.println(quamethodname);
				     	//boolean yy=quamethodname.equals(commethod);
				     	//System.out.println(yy);
						
							if(quamethodname.equals(commethod))
							{
								
								if(s.length==6)
								{
								ncss=Integer.parseInt(s[s.length-4]);
								ccn=Integer.parseInt(s[s.length-3]);
							    }
				     		if(s.length==5)
				     		{
				     			ncss=Integer.parseInt(s[s.length-4]);
				     			ccn=Integer.parseInt(s[s.length-3]);
				     			
				     		}
							
		  				break;
		  				}
						
						//System.out.println(line+" "+s.length);
					}
						
						
					
						//System.out.println("ncss "+ncss+" ccn "+ccn);
    		        } catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    		        MLOC.add(ncss);
					CCN.add(ccn);
    		    }
    		}).start(); // �����������߳������process.getInputStream()�Ļ�����
    		InputStream is2 = process.getErrorStream();
    		BufferedReader br2 = new BufferedReader(new InputStreamReader(is2));
    		String line=null;
    		while((line = br2.readLine()) != null) 
    			
    		;
    			process.getOutputStream().close();}
    			//System.out.println(MLOC.get(0));
    			//System.out.println(CCN.get(0));
    		int update1=0;
    		int update2=0;
    		if(MLOC.size()!=0)
    			update1=MLOC.get(0);	
    		if(CCN.size()!=0)
    			update2=CCN.get(0);
			
     String updatesql1="update "+ table+" set MLOC=" +update1+" where ID="+i;
     String updatesql2="update "+ table+" set CCN=" +update2+" where ID="+i;
     cd.UpdateSql(updatesql2);
     cd.UpdateSql(updatesql1);
    	cd.CutConnection(cd.conn);		  		
	   			
			
	     }
			 
}  
	 
	 public static void calculateRemainedMetrics() throws IOException, InterruptedException, SQLException
     //use jcsc to calculate the ncss and ccn
     {
		 
		 
	     final String table="duiyingtable";
	     ArrayList<Integer> IDList=new ArrayList<Integer>();
		 MySqlConnection cd=new MySqlConnection();
		 cd.ConnectMysql();
		 String sqlID="SELECT * FROM "+ table +" where MLOC=0 ";
		 IDList=cd.SelectSqlIDList(sqlID);
		 cd.CutConnection(cd.conn);
	   for(int i=0;i<IDList.size();i++)
	    {
		   System.out.println(i);
	    	final ArrayList<Integer> MLOC=new ArrayList<Integer>();
	    	final ArrayList<Integer>CCN=new ArrayList<Integer>();
	    String sql="Select * FROM "+ table+" where ID="+IDList.get(i);
	final int id=IDList.get(i);
	System.out.println(id);
	     String version="";
		 String packagename="";
		 String classname="";
		 String methodname="";
		 String para="";
		 String Pathpackagename="";
		 String Pathclassname="";
		 final String commethod;
		 ArrayList<String> parameter=new ArrayList<String>();
		 String absolupath=projectsrcpath+"\\";
		 String comclassname="";
		 String compara="";
		  MySqlConnection cd1=new MySqlConnection();
		 cd1.ConnectMysql();
		packagename=cd1.SelectSql5(sql);
	    classname=cd1.SelectSql6(sql);
	    version=cd1.SelectSqlVersion(sql);
	   para=cd1.SelectSqlPAR(sql);
	   methodname=cd1.SelectSqlMethodname(sql);
	 	cd1.CutConnection(cd1.conn);
		// packagename="org.gjt.sp.jedit.textarea";
       //  classname="JEditTextArea";
     	 ////version="4.1.0";
     	//  para="";
		// methodname="goToPrevWord";
     	 if((para==null)||(para.length()==0)) compara="()";
     	 else
     	 {
     	
     	 para=para.substring(0, para.length()-1);
     	 //System.out.println(para);
     	 parameter=getparatype(para);
     	// System.out.println(parameter);
     	 compara="(";
     	 for(int j=0;j<(parameter.size()-1);j++)
     	 {compara=compara+parameter.get(j)+",";}
     	 compara=compara+parameter.get(parameter.size()-1);
     	 compara=compara+")";
     	 }
     	
    
     	 
     	
     	 
     	 Pathpackagename=packagename;
     	 Pathclassname=classname;
     	 Pathpackagename=Pathpackagename.replace(".","\\");
     	 comclassname=classname;
     	 if(Pathclassname.contains("$"))
     	 {
     		String [] ss=new String[2];
     		ss=Pathclassname.split("\\$") ;
     		Pathclassname=ss[0];
     		comclassname=comclassname.replace("$", ".");
     		 
     	 }
     	 if(Pathclassname.equals(methodname))
     	 {methodname="constructor";}
     	commethod=comclassname+"."+methodname+"()";
     	absolupath=absolupath+projectname+"-"+version+"\\"+"src"+"\\"+Pathpackagename+"\\"+Pathclassname+".java";
        System.out.println(absolupath);
     //  System.out.println(commethod);
     	String [] cmd=new String[]{"cmd.exe","/c","F: && cd F:\\jcsc\\bin && jcsc "+absolupath};
		Process process =Runtime.getRuntime().exec(cmd);
		final InputStream is1 = process.getInputStream();
    	new Thread(new Runnable() {
    		    public void run() {
    		    
    		    	int ncss=0;
		        	int ccn=0;
    		    	String line=null;
    		        BufferedReader br = new BufferedReader(new InputStreamReader(is1));
    		       
    		        try {
    		        
    		        	
						while((line=br.readLine()) != null) 
						{//line=line.replace("Java NCSS: ", "");
							
							
							String s[]=line.split(":");
							
							
						 
						   // System.out.println(quamethodname);
				     	//boolean yy=quamethodname.equals(commethod);
				     	//System.out.println(yy);
						
							
								
				     		if(s.length==5)
				     		{   String	quamethodname=s[2];
				     			if(quamethodname.equals(commethod))
								{
				     				String stringncss=s[3];
				     				stringncss=stringncss.replace("NCSS-", "");
				     			ncss=Integer.parseInt(stringncss);
				     			String stringccn=s[4];
				     			stringccn=stringccn.replace("CCN-", "");
				     			ccn=Integer.parseInt(stringccn);
				     			
				     		    break;
				     		}
							
		  				
		  				}
						
						//System.out.println(line+" "+s.length);
					}
						
						 MySqlConnection cd2=new MySqlConnection();
						 cd2.ConnectMysql();
						// System.out.println("cd2"+cd2.conn);
		     			 String updatesql1="update "+ table+" set MLOC=" +ncss+" where ID="+id;
		     		     String updatesql2="update "+ table+" set CCN=" +ccn+" where ID="+id;
		     		     cd2.UpdateSql(updatesql2);
		     		     cd2.UpdateSql(updatesql1);
		     		     cd2.CutConnection(cd2.conn);
					
						System.out.println("ncss "+ncss+" ccn "+ccn);
    		        } catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    		        MLOC.add(ncss);
					CCN.add(ccn);
    		    }
    		}).start(); // �����������߳������process.getInputStream()�Ļ�����
    		InputStream is2 = process.getErrorStream();
    		BufferedReader br2 = new BufferedReader(new InputStreamReader(is2));
    		String line=null;
    		while((line = br2.readLine()) != null) 
    			
    		;
    			process.getOutputStream().close();
    			//System.out.println(MLOC.get(0));
    			//System.out.println(CCN.get(0));
    		
	/*	
     String updatesql1="update "+ table+" set MLOC=" +update1+" where ID="+IDList.get(i);
     String updatesql2="update "+ table+" set CCN=" +update2+" where ID="+IDList.get(i);
     cd1.UpdateSql(updatesql2);
     cd1.UpdateSql(updatesql1);*/
   	  		
	    }		
			
	     
			 
}  
	 
	
	 		

	     
			
     	
	 public static ArrayList<String> getparatype(String s)
	 {
	 	ArrayList<String> parameters=new ArrayList<String>();
	 	
	 	if(s!=null)
	 	{
	 		
	 		
	 			
	 			int itemcount = 1;

	 			if (s.length() > 0) {

	 				ArrayList<Integer> jiankuohao1=new ArrayList<Integer>();
	 				ArrayList<Integer> jiankuohao2=new ArrayList<Integer>();
	 				int n=0;
	 				
	 				for (int i = 0; i < s.length(); i++) {
	 					
	 					
	 					if (s.charAt(i) == '<') {
	 						jiankuohao1.add(i);
	 					}
	 					if(s.charAt(i)=='>')
	 					{
	 						jiankuohao2.add(i);
	 					}	}
	 				
	 				n=jiankuohao1.size();
	 				for (int i = 0; i < s.length(); i++){
	 				
	 					if (s.charAt(i) == ',') {
	 						boolean yy=true;
	 						for(int j=0;j<n;j++)
	 						{
	 							if(i<jiankuohao2.get(j)&&i>jiankuohao1.get(j)) 
	 							{
	 								yy=false;
	 								break;}
	 						
	 					}
	 						if(yy)
	 						itemcount++;}
	 				
	 				}}
	 			
	 				for (int i = 0; i < itemcount; i++) {
	 					String arg = null;
	 					
	 					boolean yy1=false;
	 					ArrayList<Integer> jiankuohao1=new ArrayList<Integer>();
	 					ArrayList<Integer> jiankuohao2=new ArrayList<Integer>();
	 					int n=0;
	 					if(s.length()>0){
	 					for (int k = 0; k < s.length(); k++) {

	 						
	 						if (s.charAt(k) == '<') {
	 							jiankuohao1.add(k);
	 						}
	 						if(s.charAt(k)=='>')
	 						{
	 							jiankuohao2.add(k);
	 						}
	 					}
	 					n=jiankuohao1.size();
	 					for (int k = 0; k < s.length(); k++) {
	 						if (s.charAt(k) == ',') {
	 							boolean yy=true;
	 							for(int j=0;j<n;j++)
	 							{
	 								if(j<jiankuohao2.size()){
	 								if(k<jiankuohao2.get(j)&&k>jiankuohao1.get(j)) 
	 								{
	 									yy=false;
	 									break;}}
	 							
	 						}
	 							if(yy)
	 							{
	 								yy1=true;
	 								arg = s.substring(0, k);
	 								//System.out.println(arg);
	 								s = s.substring(k + 1);
	 								//System.out.println(s);
	 								parameters.add(arg);
	 								//System.out.println(arg);
	 								break;
	 							}
	 							
	 					}
	 				
	 					
	 					}	
	 					 if(!yy1){
	 						 arg = s;	
	 						// System.out.println(arg);
	 					 parameters.add(arg);}
	 			
	 				
	 		}
	 			
	 		
	 	}	}
	 	
	 	return parameters;

	 }
}
