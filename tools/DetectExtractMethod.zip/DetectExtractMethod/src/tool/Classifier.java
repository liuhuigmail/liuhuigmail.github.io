package tool;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.JavaModelException;

import edu.washington.cs.rules.JavaMethod;

public class Classifier {

	public static final String LINE_DELIMITER = System.getProperty("line.separator");
	private static String filePath = "D:/Analyses.txt";
    
	
	//ͳ�Ʒ����ȡ�ķ���
	public void statisticsExtractMethods(String oldProjectName, String newProjectName, 
			ArrayList<IMethod> extractMethods, Map<JavaMethod, JavaMethod> matchmethods) throws JavaModelException{
		int oneToOneNum = 0; // ֻ��һ�����õ�����
		int multiToAllNum = 0; // �������ȫ���ܶ�Ӧ�ɰ汾������
		int multiToOneNum = 0; // �������ֻ��һ����Ӧ�ɰ������
		int multiToMultiNum = 0; // ������ò��ֶ�Ӧ�ɰ汾������
		if(extractMethods == null || extractMethods.size() == 0) return;
		for (IMethod extractMethod : extractMethods){
			HashMap<IMethod, IMethod> matchInvocationMethods = getMatchInvocationMethods(oldProjectName, 
					newProjectName, extractMethod, matchmethods);
			if(!isReuse(newProjectName, extractMethod)){
				oneToOneNum++;
			}else if(getNullNumberOfMatchInvocationMethods(matchInvocationMethods) == 0){
				multiToAllNum++;
			}else if(getNullNumberOfMatchInvocationMethods(matchInvocationMethods) == (matchInvocationMethods.size() - 1)){
				multiToOneNum++;
			}else{
				multiToMultiNum++;
			}
		}
		FileWriter fw = null;
		try {
			fw = new FileWriter(filePath, true);
			fw.write(LINE_DELIMITER);
			fw.write("��ȡ��������Ϊ�� " + extractMethods.size() + LINE_DELIMITER);
			fw.write("���У� " + LINE_DELIMITER);
			fw.write("	ֻ��һ�����õ�������" + oneToOneNum + LINE_DELIMITER);
			fw.write("	�������ȫ���ܶ�Ӧ�ɰ汾��������" + multiToAllNum + LINE_DELIMITER);
			fw.write("	�������ֻ��һ����Ӧ�ɰ��������" + multiToOneNum + LINE_DELIMITER);
			fw.write("	������ò��ֶ�Ӧ�ɰ汾��������" + multiToMultiNum + LINE_DELIMITER);
			fw.write(LINE_DELIMITER);
			fw.write(LINE_DELIMITER);
			fw.close();
		} catch (IOException e){
			e.printStackTrace();
		} finally{
			try {
				fw.close();
			} catch (IOException e){
				e.printStackTrace();
			}
		}
	}
	
	
	//��������ĳ�ȡ����
	public Map<JavaMethod,Integer> analysesExtractMethods(String oldProjectName, String newProjectName, ArrayList<IMethod> extractMethods, 
			Map<JavaMethod, JavaMethod> matchmethods) throws JavaModelException{
		Map<JavaMethod,Integer> extracttypemap=new LinkedHashMap<JavaMethod,Integer>();
		if(extractMethods == null || extractMethods.size() == 0) return null;
		for(IMethod extractIMethod : extractMethods){
			 extracttypemap.putAll(analysesExtractMethod(oldProjectName, newProjectName, extractIMethod, matchmethods));
		}
		return extracttypemap;
	}
	
	
	//����һ����ȡ����
	public Map<JavaMethod,Integer> analysesExtractMethod(String oldProjectName, String newProjectName, 
			IMethod extractMethod, Map<JavaMethod, JavaMethod> matchmethods) throws JavaModelException{
		HashMap<IMethod, IMethod> matchInvocationMethods = getMatchInvocationMethods(oldProjectName, 
				newProjectName, extractMethod, matchmethods);
		JavaMethod methodofwrite;
		Map<JavaMethod,Integer> extracttypemap=new LinkedHashMap<JavaMethod,Integer>();
		methodofwrite=Util.getQualifiedMethodName(extractMethod);
		ArrayList<IMethod> notMatchInvocationMethods = new ArrayList<IMethod>();
		FileWriter fw = null;
		try {
			fw = new FileWriter(filePath, true);
			fw.write("��ȡ������ " + extractMethod + LINE_DELIMITER);
			fw.write(LINE_DELIMITER);
			if(!isReuse(newProjectName, extractMethod)){
				extracttypemap.put(methodofwrite, 1);
				fw.write("	ֻ��һ������" + LINE_DELIMITER);
				fw.write("	��Ӧ��ϵΪ��" + LINE_DELIMITER);
				Iterator<Entry<IMethod, IMethod>> mapIter = matchInvocationMethods.entrySet().iterator();
				while (mapIter.hasNext()){
					Entry<IMethod, IMethod> entry = mapIter.next();
					fw.write("		" + entry.getKey().toString() + LINE_DELIMITER);
					fw.write("		" + entry.getValue().toString() + LINE_DELIMITER);
				}
				fw.write(LINE_DELIMITER);
				fw.write(LINE_DELIMITER);
				fw.write(LINE_DELIMITER);
				fw.close();
			}else if (getNullNumberOfMatchInvocationMethods(matchInvocationMethods) == 0){
				extracttypemap.put(methodofwrite, 2);
				
				fw.write("	�������ȫ���ܶ�Ӧ�ɰ汾" + LINE_DELIMITER);
				fw.write("	��Ӧ��ϵΪ��" + LINE_DELIMITER);
				Iterator<Entry<IMethod, IMethod>> mapIter = matchInvocationMethods.entrySet().iterator();
				while(mapIter.hasNext()){
					Entry<IMethod, IMethod> entry = mapIter.next();
					fw.write("		" + entry.getKey().toString() + LINE_DELIMITER);
					fw.write("		" + entry.getValue().toString() + LINE_DELIMITER);
					fw.write("	----------------------------------------------" + LINE_DELIMITER);
				}
				fw.write(LINE_DELIMITER);
				fw.write(LINE_DELIMITER);
				fw.write(LINE_DELIMITER);
				fw.close();
			} else if(getNullNumberOfMatchInvocationMethods(matchInvocationMethods) == (matchInvocationMethods.size() - 1)){
				extracttypemap.put(methodofwrite, 3);
				fw.write("	�������ֻ��һ����Ӧ�ɰ�" + LINE_DELIMITER);
				fw.write("	��Ӧ��ϵΪ��" + LINE_DELIMITER);
				Iterator<Entry<IMethod, IMethod>> mapIter = matchInvocationMethods.entrySet().iterator();
				while (mapIter.hasNext()){
					Entry<IMethod, IMethod> entry = mapIter.next();
					if(entry.getValue() == null){
						notMatchInvocationMethods.add(entry.getKey());
						continue;
					}
					fw.write("		" + entry.getKey().toString() + LINE_DELIMITER);
					fw.write("		" + entry.getValue().toString() + LINE_DELIMITER);
				}
				fw.write(LINE_DELIMITER);
				if(notMatchInvocationMethods != null && notMatchInvocationMethods.size() != 0){
					fw.write("	��������Ϊ��" + LINE_DELIMITER);
					Iterator<IMethod> listIter = notMatchInvocationMethods.iterator();
					while(listIter.hasNext()){
						IMethod notMatchIMethod = listIter.next();
						if(notMatchIMethod != null){
							fw.write("		" + notMatchIMethod.toString() + LINE_DELIMITER);
						}
					}
				} else{
					fw.write("	����������" + LINE_DELIMITER);
				}
				fw.write(LINE_DELIMITER);
				fw.write(LINE_DELIMITER);
				fw.write(LINE_DELIMITER);
				fw.close();
			} else{
				extracttypemap.put(methodofwrite, 4);
				fw.write("	������ò��ֶ�Ӧ�ɰ汾" + LINE_DELIMITER);
				fw.write("	��Ӧ��ϵΪ��" + LINE_DELIMITER);
				Iterator<Entry<IMethod, IMethod>> mapIter = matchInvocationMethods.entrySet().iterator();
				while (mapIter.hasNext()) {
					Entry<IMethod, IMethod> entry = mapIter.next();
					if (entry.getValue() == null) {
						notMatchInvocationMethods.add(entry.getKey());
						continue;
					}
					fw.write("		" + entry.getKey().toString() + LINE_DELIMITER);
					fw.write("		" + entry.getValue().toString() + LINE_DELIMITER);
					fw.write("	----------------------------------------------" + LINE_DELIMITER);
				}
				fw.write(LINE_DELIMITER);
				if (notMatchInvocationMethods != null && notMatchInvocationMethods.size() != 0){
					fw.write("��������Ϊ��" + LINE_DELIMITER);
					Iterator<IMethod> listIter = notMatchInvocationMethods.iterator();
					while (listIter.hasNext()){
						IMethod notMatchIMethod = listIter.next();
						if(notMatchIMethod != null){
							fw.write("		" + notMatchIMethod.toString() + LINE_DELIMITER);
						}
					}
				} else {
					fw.write("	����������" + LINE_DELIMITER);
				}
				fw.write(LINE_DELIMITER);
				fw.write(LINE_DELIMITER);
				fw.write(LINE_DELIMITER);
				fw.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fw.close();
			} catch (Exception e){
				e.printStackTrace();
			}
		}
		return extracttypemap;
	}

	
	// ����HashMap������ֵ��Ϊnull�ĸ���
	public int getNullNumberOfMatchInvocationMethods(Map<IMethod, IMethod> matchInvocationMethods){
		int nullNumberOfMatchInvocationMethods = 0;
		Iterator<Entry<IMethod, IMethod>> mapIter = matchInvocationMethods.entrySet().iterator();
		while(mapIter.hasNext()){
			Entry<IMethod, IMethod> entry = mapIter.next();
			if(entry.getValue() == null){
				nullNumberOfMatchInvocationMethods++;
			}
		}
		return nullNumberOfMatchInvocationMethods;
	}
	
	
	// ����IMethod�������ڹ����б����õĴ���
	public int getInvocationMethodNum(String projectName, IMethod iMethod){
		ArrayList<IMethod> invocationMethods = Util.getInvocationMethods(projectName, iMethod);
		if(invocationMethods == null || invocationMethods.size() == 0){
			return 0;
		}
		return invocationMethods.size();
	}
	

	// �ж�IMethod�ڹ������Ƿ񱻸��ã������÷���true��û���򷵻�false
	public boolean isReuse(String projectName, IMethod iMethod){
		if(getInvocationMethodNum(projectName, iMethod) > 1) return true;
		return false;
	}
	

	// �����ȡ�ķ��������ص��ó�ȡ�����ķ�����Map(�°汾�ĵ��÷���g--->�ɰ汾��g~,û����Ϊnull)
	public HashMap<IMethod, IMethod> getMatchInvocationMethods(String oldProjectName, String newProjectName, 
			IMethod extractMethod, Map<JavaMethod, JavaMethod> matchmethods) throws JavaModelException{
		HashMap<IMethod, IMethod> matchInvocationMethods = new HashMap<IMethod, IMethod>();
		ArrayList<IMethod> invocationMethods = Util.getInvocationMethods(newProjectName, extractMethod);
		for(IMethod invocationMethod : invocationMethods){
			JavaMethod qualifiedMethodName = Util.getQualifiedMethodName(invocationMethod);
			JavaMethod oldQualifiedMethodName = Util.searchMatchMethod(qualifiedMethodName, matchmethods);
			if(oldQualifiedMethodName == null){
				matchInvocationMethods.put(invocationMethod, null);
				continue;
			}
			IMethod oldIMethod = Util.getIMethod(oldProjectName, oldQualifiedMethodName);
			matchInvocationMethods.put(invocationMethod, oldIMethod);
		}
		return matchInvocationMethods;
	}
	/*public static JavaMethod getmethodofwrite(IMethod method)
	
	{
		JavaMethod awrite = new JavaMethod();
		String com;
		if(method!=null)
		{
			if(method.getCompilationUnit()!=null){
				
			
			com=method.getCompilationUnit().getElementName();
			if(com!=null){
			awrite.packagename=method.getDeclaringType().getPackageFragment().getElementName();
			awrite.compiname=com;
			awrite.methodname=method.getElementName();
			awrite.paranum=method.getNumberOfParameters();
			
		}
			}}
		return awrite;
	}
*/
}
