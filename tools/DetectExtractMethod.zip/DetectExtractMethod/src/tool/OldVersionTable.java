package tool;

public class OldVersionTable {
	private int ID;
	private String packagemame;
	private String sourcename;
	private String methodname;
	private int mlocvalue;
	private int nbdvalue;
	private int vgvalue;
	private int parvalue;
	private int IsExtractMethod;
	private int ExtractMethodID;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getPackagemame() {
		return packagemame;
	}
	public void setPackagemame(String packagemame) {
		this.packagemame = packagemame;
	}
	public String getSourcename() {
		return sourcename;
	}
	public void setSourcename(String sourcename) {
		this.sourcename = sourcename;
	}
	public String getMethodname() {
		return methodname;
	}
	public void setMethodname(String methodname) {
		this.methodname = methodname;
	}
	public int getMlocvalue() {
		return mlocvalue;
	}
	public void setMlocvalue(int mlocvalue) {
		this.mlocvalue = mlocvalue;
	}
	public int getNbdvalue() {
		return nbdvalue;
	}
	public void setNbdvalue(int nbdvalue) {
		this.nbdvalue = nbdvalue;
	}
	public int getVgvalue() {
		return vgvalue;
	}
	public void setVgvalue(int vgvalue) {
		this.vgvalue = vgvalue;
	}
	public int getParvalue() {
		return parvalue;
	}
	public void setParvalue(int parvalue) {
		this.parvalue = parvalue;
	}
	public int getIsExtractMethod() {
		return IsExtractMethod;
	}
	public void setIsExtractMethod(int isExtractMethod) {
		IsExtractMethod = isExtractMethod;
	}
	public int getExtractMethodID() {
		return ExtractMethodID;
	}
	public void setExtractMethodID(int extractMethodID) {
		ExtractMethodID = extractMethodID;
	}
	
	

}
