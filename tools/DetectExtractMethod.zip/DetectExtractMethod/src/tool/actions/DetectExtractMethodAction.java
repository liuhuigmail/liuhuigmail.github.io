package tool.actions;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.jface.dialogs.MessageDialog;
import org.xml.sax.SAXException;

import tool.CalculateMetrics;
import tool.CalculateMloc;
import tool.Main;
import tool.ProcessMethodsLevel;
import tool.Util;
import edu.washington.cs.extractors.ProgramSnapshot;
import edu.washington.cs.extractors.ReadDirectories;
import edu.washington.cs.induction.OnePipeLineScript;
import edu.washington.cs.induction.RulebasedMatching;
import edu.washington.cs.others.ComparisonAnalysisViewer;
import edu.washington.cs.rules.JavaMethod;
import edu.washington.cs.util.ListOfPairs;
import edu.washington.cs.util.Pair;

/**
 * Our sample action implements workbench action delegate.
 * The action proxy will be created by the workbench and
 * shown in the UI. When the user tries to use the action,
 * this delegate will be created and execution will be 
 * delegated to it.
 * @see IWorkbenchWindowActionDelegate
 */
public class DetectExtractMethodAction implements IWorkbenchWindowActionDelegate {
	private IWorkbenchWindow window;
	/**
	 * The constructor.
	 */
	public DetectExtractMethodAction() {
	}

	/**
	 * The action has been activated. The argument of the
	 * method represents the 'real' action sitting
	 * in the workbench UI.
	 * @see IWorkbenchWindowActionDelegate#run
	 */
	public void run(IAction action) {
		
			try {
				Main.DiaoyongRecord();
			} catch (JavaModelException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
		///try {
			//Main.detectMethodExtract();
	//} catch (JavaModelException | IOException | SAXException | SQLException e1) {
			//TODO Auto-generated catch block
			//e1.printStackTrace();
		//}
		//try {
			//Main.analysis();
		

		
		//	Main.analysis2();
		
		//Main.analysis2Type1();
	//	Main.analysis2Type2();
		//Main.analysis2Type3();
		//Main.analysis2Type4();

		//Main.analysis4();
		//Main.analysisType1();
		//Main.analysisType2();
		//Main.analysisType3();
		//Main.analysisType4();
		
    // Main.analysismove();} 
			//catch (SQLException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		//}
	
			//CalculateMloc.calculatemloc();
		
			//try {
			//	Main.NewClassify();
			//} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			//}
		
		//String ss=Main.getNextSymmetricNumber("");
		System.out.println("ok");
		//System.out.println(matchingresult);
		
	
		
	//System.out.println(	matchingresult.getMatches(true));
	
		
		
	}

	/**
	 * Selection in the workbench has been changed. We 
	 * can change the state of the 'real' action here
	 * if we want, but this can only happen after 
	 * the delegate has been created.
	 * @see IWorkbenchWindowActionDelegate#selectionChanged
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}

	/**
	 * We can use this method to dispose of any system
	 * resources we previously allocated.
	 * @see IWorkbenchWindowActionDelegate#dispose
	 */
	public void dispose() {
	}

	/**
	 * We will cache window object in order to
	 * be able to provide parent shell for the message dialog.
	 * @see IWorkbenchWindowActionDelegate#init
	 */
	public void init(IWorkbenchWindow window) {
		this.window = window;
	}
}