package tool;


import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.sql.Statement;  
import java.util.ArrayList;  
import java.util.HashMap;
import java.util.List;  
  
import java.util.Map;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
 
 
public class MySqlConnection {
 
    String drivename="com.mysql.jdbc.Driver";
    String url="jdbc:mysql://localhost:3306/vuze";
    String user="root";
    String password="111111";
    PreparedStatement ps ;
    Connection conn;
    ResultSet rs;
 
    public Connection ConnectMysql(){
                try{
            Class.forName(drivename);
            conn = (Connection) DriverManager.getConnection(url, user, password);
            if (!conn.isClosed()) {
               System.out.println("Succeeded connecting to the Database!");
            } else {
                System.out.println("Falled connecting to the Database!");
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
         return conn;
    }
 
         public void CutConnection(Connection conn) throws SQLException{
             try{
                if(rs!=null);
                if(conn!=null);
             }catch(Exception e){
             e.printStackTrace();
             }finally{
          // rs.close();
            conn.close();
             }
    }
 
 
         
         //���롢ɾ�������µķ�����һ���ģ���һ���������ݿ����
         public boolean InsertSql(String insql){
             try{
 
                  //insql="insert into bug(ID,CommitID,LineNum) values(?,?,?)";
                  //����ķ���������ķ��������ƣ�һ�����ǰ�ȫ�ԣ���һ�����������ˡ���
                 //insql="insert into user(userid,username,password,email) values(user.getId,user.getName,user.getPassword,user.getEmail)";
                 PreparedStatement ps=conn.prepareStatement(insql);
                 //.preparedStatement(insql);
                 //PreparedStatement  ps=(PreparedStatement) conn.prepareStatement(insql);
                 //ps.setInt(1, bug.getID());
            //     ps.setString(2, bug.getCommitID());
              //   ps.setInt(3, bug.getLineNum());
                
                 int result=ps.executeUpdate();
                 //ps.executeUpdate();�޷��ж��Ƿ��Ѿ�����
                 if(result>0)
                     return true;
             }catch(Exception e){
                 e.printStackTrace();
             }
             return false;
         }
 
 
         //������������Ƚϣ���ѯ����ڲ�ѯ����Ҫһ����ѯ�������ResultSet���������ѯ���
         public String SelectSql(String sql){
        	String ID = null;
             try{
              // Statement statement=conn.createStatement();
                 ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                         ResultSet.CONCUR_READ_ONLY);
                   
             ps.setFetchSize(Integer.MIN_VALUE);
             
             ps.setFetchDirection(ResultSet.FETCH_REVERSE);

              // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
               //  rs=statement.executeQuery(sql);
                 rs = ps.executeQuery();

                 while(rs.next()){
                	 ID=rs.getString("ID");
                	// System.out.println(rs.getString("ID"));
                   //  name=rs.getString("username");
                    // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                
                 }
                 rs.close();
             }
           
             catch(Exception e){
                 e.printStackTrace();
             }
			return ID ;
 
         }
         public ArrayList<Integer> SelectSqlIDList(String sql){
         	ArrayList<Integer> ID = new ArrayList<Integer>();
              try{
                  Statement statement=conn.createStatement();
                
                  rs=statement.executeQuery(sql);
                  while(rs.next()){
                	  
                 	 ID.add(rs.getInt("ID"));
                 	// System.out.println(rs.getString("ID"));
                    //  name=rs.getString("username");
                     // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                   }
              }catch(Exception e){
                  e.printStackTrace();
              }
 			return ID ;
  
          }
         public int SelectSqlSum(String sql){
        	 int n=0;
          	ArrayList<Integer> ID = new ArrayList<Integer>();
               try{
            	   ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                           ResultSet.CONCUR_READ_ONLY);
                     
               ps.setFetchSize(Integer.MIN_VALUE);
               
               ps.setFetchDirection(ResultSet.FETCH_REVERSE);
                  // Statement statement=conn.createStatement();
                 
                  // rs=statement.executeQuery(sql);
               rs = ps.executeQuery();
                   while(rs.next()){
                 	  
                  	 ID.add(rs.getInt("ID"));
                  	// System.out.println(rs.getString("ID"));
                     //  name=rs.getString("username");
                      // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                  
                   }
                   rs.close();
               }catch(Exception e){
                   e.printStackTrace();
               }
               n=ID.size();
  			return n ;
   
           }
         public String SelectSql2(String sql){
         	String javamethod = null;
              try{
                  //Statement statement=conn.createStatement();
                  //((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                 // rs=statement.executeQuery(sql);
            	  ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                          ResultSet.CONCUR_READ_ONLY);
                    
              ps.setFetchSize(Integer.MIN_VALUE);
              
              ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                 // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                 // rs=statement.executeQuery(sql);
                  rs = ps.executeQuery();
                  while(rs.next()){
                 	 javamethod=rs.getString("package")+"*"+rs.getString("source")+"*"+rs.getString("method")+"*"+rs.getString("par");
                 	// System.out.println(rs.getString("ID"));
                    //  name=rs.getString("username");
                     // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                 
                  }
                  rs.close();
              }catch(Exception e){
                  e.printStackTrace();
              }
 			return javamethod;
  
          }
         public String SelectSql3(String sql){
          	String Number= null;
               try{
                  // Statement statement=conn.createStatement();
                  // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                 //  rs=statement.executeQuery(sql);
            	   ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                           ResultSet.CONCUR_READ_ONLY);
                     
               ps.setFetchSize(Integer.MIN_VALUE);
               
               ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                  // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                  // rs=statement.executeQuery(sql);
                   rs = ps.executeQuery();
                   while(rs.next()){
                  Number=rs.getString("Num");
                 
                  	// System.out.println(rs.getString("ID"));
                     //  name=rs.getString("username");
                      // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                    }
                   rs.close();
               }catch(Exception e){
                   e.printStackTrace();
               }
  			return Number;
   
           }
         public String SelectSql4(String sql){
           	String Extract= null;
                try{
                   // Statement statement=conn.createStatement();
                    //((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                   // rs=statement.executeQuery(sql);
                	 ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                             ResultSet.CONCUR_READ_ONLY);
                       
                 ps.setFetchSize(Integer.MIN_VALUE);
                 
                 ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                    // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                    // rs=statement.executeQuery(sql);
                     rs = ps.executeQuery();
                    while(rs.next()){
                  Extract=rs.getString("ExtractType");
                 
                   	// System.out.println(rs.getString("ID"));
                      //  name=rs.getString("username");
                       // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                     }
                    rs.close();
                }catch(Exception e){
                    e.printStackTrace();
                }
   			return Extract;
    
            }
         public String SelectSql5(String sql){
            	String Extract= null;
                 try{
                     //Statement statement=conn.createStatement();
                    // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                    // rs=statement.executeQuery(sql);
                	 ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                             ResultSet.CONCUR_READ_ONLY);
                       
                 ps.setFetchSize(Integer.MIN_VALUE);
                 
                 ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                    // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                    // rs=statement.executeQuery(sql);
                     rs = ps.executeQuery();
                     while(rs.next()){
                   Extract=rs.getString("package");
                 
                    	// System.out.println(rs.getString("ID"));
                       //  name=rs.getString("username");
                        // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                      }
                     rs.close();
                 }catch(Exception e){
                     e.printStackTrace();
                 }
    			return Extract;
     
             }
         public ArrayList<String> SelectSql55(String sql){
         	ArrayList<String> Extract= new ArrayList<String>();
              try{
                  Statement statement=conn.createStatement();
                
                  rs=statement.executeQuery(sql);
                  while(rs.next()){
                Extract.add(rs.getString("package"));
                 	// System.out.println(rs.getString("ID"));
                    //  name=rs.getString("username");
                     // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                   }
              }catch(Exception e){
                  e.printStackTrace();
              }
 			return Extract;
  
          }
         public String SelectSql6(String sql){
         	String Extract= null;
              try{
                 // Statement statement=conn.createStatement();
                 // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                  //rs=statement.executeQuery(sql);
            	  ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                          ResultSet.CONCUR_READ_ONLY);
                    
              ps.setFetchSize(Integer.MIN_VALUE);
              
              ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                 // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                 // rs=statement.executeQuery(sql);
                  rs = ps.executeQuery();
                  while(rs.next()){
                Extract=rs.getString("source");
              
                 	// System.out.println(rs.getString("ID"));
                    //  name=rs.getString("username");
                     // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                   }
                  rs.close();
              }catch(Exception e){
                  e.printStackTrace();
              }
 			return Extract;
  
          }
         public ArrayList<String> SelectSql66(String sql){
          ArrayList<String> Extract= new ArrayList<String>();
               try{
                   Statement statement=conn.createStatement();
                 
                   rs=statement.executeQuery(sql);
                   while(rs.next()){
                 Extract.add(rs.getString("source"));
                  	// System.out.println(rs.getString("ID"));
                     //  name=rs.getString("username");
                      // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                    }
               }catch(Exception e){
                   e.printStackTrace();
               }
  			return Extract;
   
           }
         public String SelectSql7(String sql){
          	String Extract= null;
               try{
                  // Statement statement=conn.createStatement();
                   //((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                  // rs=statement.executeQuery(sql);
            	   ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                           ResultSet.CONCUR_READ_ONLY);
                     
               ps.setFetchSize(Integer.MIN_VALUE);
               
               ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                  // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                  // rs=statement.executeQuery(sql);
                   rs = ps.executeQuery();
                   while(rs.next()){
                 Extract=rs.getString("oldID");
                
                  	// System.out.println(rs.getString("ID"));
                     //  name=rs.getString("username");
                      // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                    }
                   rs.close();
               }catch(Exception e){
                   e.printStackTrace();
               }
  			return Extract;
   
           }
         public String SelectSql8(String sql){
           	String Extract= null;
                try{
                   // Statement statement=conn.createStatement();
                   // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                   // rs=statement.executeQuery(sql);
                	 ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                             ResultSet.CONCUR_READ_ONLY);
                       
                 ps.setFetchSize(Integer.MIN_VALUE);
                 
                 ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                    // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                    // rs=statement.executeQuery(sql);
                     rs = ps.executeQuery();
                    while(rs.next()){
                  Extract=rs.getString("Sub");
                 
                   	// System.out.println(rs.getString("ID"));
                      //  name=rs.getString("username");
                       // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                     }
                    rs.close();
                }catch(Exception e){
                    e.printStackTrace();
                }
   			return Extract;
    
            }
         
         public String SelectSql9(String sql){
            	String Extract= null;
                 try{
                    // Statement statement=conn.createStatement();
                    // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                     //rs=statement.executeQuery(sql);
                	 ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                             ResultSet.CONCUR_READ_ONLY);
                       
                 ps.setFetchSize(Integer.MIN_VALUE);
                 
                 ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                    // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                    // rs=statement.executeQuery(sql);
                     rs = ps.executeQuery();
                     while(rs.next()){
                   Extract=rs.getString("Num1");
                 
                    	// System.out.println(rs.getString("ID"));
                       //  name=rs.getString("username");
                        // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                      }
                     rs.close();
                 }catch(Exception e){
                     e.printStackTrace();
                 }
    			return Extract;
     
             }
         
         public ArrayList<String> SelectSql10(String sql){
         	ArrayList<String> version= new ArrayList<String>();
              try{
                  Statement statement=conn.createStatement();
                
                  rs=statement.executeQuery(sql);
                  while(rs.next()){
                
                version.add(rs.getString("Version"));
                	  
                 	// System.out.println(rs.getString("ID"));
                    //  name=rs.getString("username");
                     // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                   }
              }catch(Exception e){
                  e.printStackTrace();
              }
 			return version;
  
          }
         public ArrayList<String> SelectSql11(String sql){
           	ArrayList<String> Number= new ArrayList<String>();
                try{
                    Statement statement=conn.createStatement();
                  
                    rs=statement.executeQuery(sql);
                    while(rs.next()){
                   Number.add(rs.getString("ID")+","+rs.getString("Num"));
                   	// System.out.println(rs.getString("ID"));
                      //  name=rs.getString("username");
                       // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                     }
                }catch(Exception e){
                    e.printStackTrace();
                }
   			return Number;
    
            }
         public String SelectSql12(String sql){
          String version=null;
               try{
                  /// Statement statement=conn.createStatement();
                  // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                  // rs=statement.executeQuery(sql);
            	   ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                           ResultSet.CONCUR_READ_ONLY);
                     
               ps.setFetchSize(Integer.MIN_VALUE);
               
               ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                  // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                  // rs=statement.executeQuery(sql);
                   rs = ps.executeQuery();
                   while(rs.next()){
                 
                 version=rs.getString("Version");
              
                 	  
                  	// System.out.println(rs.getString("ID"));
                     //  name=rs.getString("username");
                      // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                    }
                   rs.close();
               }catch(Exception e){
                   e.printStackTrace();
               }
  			return version;
   
           }
         public String SelectSqlVersion(String sql){
             String version=null;
                  try{
                    //  Statement statement=conn.createStatement();
                    //  ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                    //  rs=statement.executeQuery(sql);
                	  ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                              ResultSet.CONCUR_READ_ONLY);
                        
                  ps.setFetchSize(Integer.MIN_VALUE);
                  
                  ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                     // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                     // rs=statement.executeQuery(sql);
                      rs = ps.executeQuery();
                      while(rs.next()){
                    
                    version=rs.getString("VersionID");
                   
                    	  
                     	// System.out.println(rs.getString("ID"));
                        //  name=rs.getString("username");
                         // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                       }
                      rs.close();
                  }catch(Exception e){
                      e.printStackTrace();
                  }
     			return version;
      
              }
         
         public String SelectSqlPAR(String sql){
             String par=null;
                  try{
                     // Statement statement=conn.createStatement();
                     // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                     // rs=statement.executeQuery(sql);
                	  ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                              ResultSet.CONCUR_READ_ONLY);
                        
                  ps.setFetchSize(Integer.MIN_VALUE);
                  
                  ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                     // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                     // rs=statement.executeQuery(sql);
                      rs = ps.executeQuery();
                      while(rs.next()){
                    
                    par=rs.getString("par");
                 
                    	  
                     	// System.out.println(rs.getString("ID"));
                        //  name=rs.getString("username");
                         // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                       }
                      rs.close();
                  }catch(Exception e){
                      e.printStackTrace();
                  }
     			return par;
      
              }
         public String SelectSqlMethodname(String sql){
             String par=null;
                  try{
                     // Statement statement=conn.createStatement();
                 // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                    //  rs=statement.executeQuery(sql);
                	  ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                              ResultSet.CONCUR_READ_ONLY);
                        
                  ps.setFetchSize(Integer.MIN_VALUE);
                  
                  ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                     // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                     // rs=statement.executeQuery(sql);
                      rs = ps.executeQuery();
                      while(rs.next()){
                    
                    par=rs.getString("method");
                  
                    	  
                     	// System.out.println(rs.getString("ID"));
                        //  name=rs.getString("username");
                         // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                       }
                      rs.close();
                  }catch(Exception e){
                      e.printStackTrace();
                  }
     			return par;
      
              }
         
         public String SelectSqlMatchid(String sql){
             String par=null;
                  try{
                     // Statement statement=conn.createStatement();
                     // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                     // rs=statement.executeQuery(sql);
                	  ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                              ResultSet.CONCUR_READ_ONLY);
                        
                  ps.setFetchSize(Integer.MIN_VALUE);
                  
                  ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                     // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                     // rs=statement.executeQuery(sql);
                      rs = ps.executeQuery();
                      while(rs.next()){
                    
                    par=rs.getString("MatchID");
                   
                    	  
                     	// System.out.println(rs.getString("ID"));
                        //  name=rs.getString("username");
                         // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                       }
                      
                      rs.close();
                  }catch(Exception e){
                      e.printStackTrace();
                  }
     			return par;
      
              }
         
         public Map<String,String> SelectOldIDAndID(String sql){
            Map <String,String> IDMap=new HashMap<String,String>();
                  try{
                     // Statement statement=conn.createStatement();
                     // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                     // rs=statement.executeQuery(sql);
                	  ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,
                              ResultSet.CONCUR_READ_ONLY);
                        
                  ps.setFetchSize(Integer.MIN_VALUE);
                  
                  ps.setFetchDirection(ResultSet.FETCH_REVERSE);

                     // ((com.mysql.jdbc.Statement)statement).enableStreamingResults();
                     // rs=statement.executeQuery(sql);
                      rs = ps.executeQuery();
                      while(rs.next()){
                    
                    IDMap.put(rs.getString("oldID"),rs.getString("ID"));
                   
                    	  
                     	// System.out.println(rs.getString("ID"));
                        //  name=rs.getString("username");
                         // System.out.println(rs.getString("userid")+name+rs.getString("email"));
                       }
                      
                      rs.close();
                  }catch(Exception e){
                      e.printStackTrace();
                  }
     			return IDMap;
      
              }
         public boolean UpdateSql(String upsql){
        try {
           PreparedStatement ps = conn.prepareStatement(upsql);
            int result=ps.executeUpdate();//������������
            
           
            if(result>0)
        	
                return true;
        } catch (SQLException ex) {
            Logger.getLogger(MySqlConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
         }
 
         public boolean DeletSql(String delsql){
 
        try {
            PreparedStatement ps = conn.prepareStatement(delsql);
            int result=ps.executeUpdate(delsql);
            if(result>0)
                return true;
        } catch (SQLException ex) {
            Logger.getLogger(MySqlConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
         }
 
 
  }
 

 
 
 class test {
 
   
         public static void main(String args[]) throws SQLException{
         MySqlConnection cd=new MySqlConnection();
         OldVersionTable bug=new OldVersionTable();
         cd.ConnectMysql();
         bug.setID(14);//ÿ�β������ж�Ҫ�ı������
        // bug.setCommitID("zhangsan");
        // bug.setLineNum(23);
         
         
         cd.CutConnection(cd.conn);
         }
}  
  