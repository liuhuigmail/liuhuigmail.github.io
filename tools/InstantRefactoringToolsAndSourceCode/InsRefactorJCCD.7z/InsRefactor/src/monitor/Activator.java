package monitor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;

import monitor.views.SmellComparator;
import monitor.views.SmellView;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

import Smells.Commonmethod;
import Smells.DataClass;
import Smells.Duplicatedcode;
import Smells.LargeClass;
import Smells.LongMethod;
import Smells.LongParameter;
import Smells.Smell;

import Analysis.Recover;
import Analysis.ResListener;
import Analysis.ResourceVistor;

import Analysis.printer;
import Detectors.THRESHOLDS;

/**
 * The activator class controls the plug-in life cycle
 */
public class Activator extends AbstractUIPlugin {
	public ArrayList<String> list=new ArrayList<String>();
	
	// The plug-in ID
	public static final String PLUGIN_ID = "Monitor"; 
	//�����ַ���//$NON-NLS-1$

	// The shared instance
	private static Activator plugin;//����˽�ж���plugin
	
	/**
	 * The constructor
	 */
	public Activator() {
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
		//printer.println("Plugin to be started");
		Job job = new Job("test") {
			@Override
			protected IStatus run(IProgressMonitor monitor) {

				Recover Rec=new Recover();
				Rec.readThreshold();
		        Rec.read();
               // Rec.comparation();
		        Display.getDefault().asyncExec(new Runnable() {
					public void run() {
						//SmellView.smellview.set
						if(SmellView.smellview==null) return;
						SmellView.smellview.setInput(Recover.thesmelllist);
						SmellView.smellview.refresh();
						return;

					}

				});

				return org.eclipse.core.runtime.Status.OK_STATUS;
			}

		};
		job.setUser(false);
		job.schedule();

	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
		//printer.println("Plugin to be stoped");
		
		File f=new File(THRESHOLDS.fileOfSavedSmells);
		File y=new File(THRESHOLDS.fileOfSavedSmells2);
    BufferedWriter bw = new BufferedWriter(new FileWriter(f));
    BufferedWriter aw = new BufferedWriter(new FileWriter(y));
                 //	ListenerManager.listener.SmellList;
    aw.append("COMMONMETHODTIME:"+String.valueOf(THRESHOLDS.getCOMMONMETHODTIME()));
    aw.append(THRESHOLDS.tab2);
    aw.append("DATACLASS_TIMES:"+String.valueOf(THRESHOLDS.getDATACLASS_TIMES()));
    aw.append(THRESHOLDS.tab2);
    aw.append("Duplicatedline:"+String.valueOf(THRESHOLDS.Duplicatedline));
    aw.append(THRESHOLDS.tab2);
    aw.append("LARGECLASS_LINES:"+String.valueOf(THRESHOLDS.getLARGECLASS_LINES()));
    aw.append(THRESHOLDS.tab2);
    aw.append("LONGMETHOD_LINES:"+String.valueOf(THRESHOLDS.getLONGMETHOD_LINES()));
    aw.append(THRESHOLDS.tab2);
    aw.append("LONGPARAMETER:"+String.valueOf(THRESHOLDS.getLONGPARAMETER()));
    aw.append(THRESHOLDS.tab2);
    aw.append("HighestRatio:"+String.valueOf(THRESHOLDS.HighestRatio));
    aw.append(THRESHOLDS.tab2);
    aw.append("lowestRatio:"+String.valueOf(THRESHOLDS.lowestRatio));
    aw.append(THRESHOLDS.tab2);
    aw.append("bool:"+String.valueOf(THRESHOLDS.bool));
    aw.append(THRESHOLDS.tab2);
    aw.append("NoShowAgain:"+String.valueOf(THRESHOLDS.NoShowAgain));
    aw.newLine();
    aw.close();
     for(int i=0;i<ResListener.SmellList.size();i++){
      
       Smell s=ResListener.SmellList.get(i);
            
//            s.save(bw);
//            bw.newLine();
           
            s.save(bw);
     }
            bw.close();
	}
      

private Object list(int j) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static Activator getDefault() {
		return plugin;
	}

	/**
	 * Returns an image descriptor for the image file at the given
	 * plug-in relative path
	 *
	 * @param path the path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return imageDescriptorFromPlugin(PLUGIN_ID, path);
	}
}
