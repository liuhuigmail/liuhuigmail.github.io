package monitor.views;

import java.util.Comparator;



import Smells.Smell;

public class SmellComparator implements Comparator<Smell>   {

	public int compare(Smell o1, Smell o2) {
		 
		  if (o1.appearTime > o2.appearTime)
		   return -1;
		  else {if(o1.appearTime ==o2.appearTime)return 0;
		        else return 1;}
		 }

		
		
	}


