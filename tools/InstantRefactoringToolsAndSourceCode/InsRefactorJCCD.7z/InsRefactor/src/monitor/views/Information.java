package monitor.views;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JTextArea;

import Detectors.THRESHOLDS;

public class Information extends Frame implements  ActionListener ,WindowListener{
	
	
	Panel p1=new Panel();
	Panel p2=new Panel();
	Button b1=new Button("             OK             ");
	Button b2=new Button("  ");
	Button b3=new Button("  ");
	Label label1;
	Label label2;
	
	FlowLayout cl=new FlowLayout();
	 

	 public Information()
	{   
	    label1 = new Label("   You can keep coding while smell detection is running in background!");
		label2= new Label(      "NOTE: This diagram will not appear anymore.");
		this.setTitle("Monitor Runs In Background");
		this.setLayout(null);
		this.setLayout(new BorderLayout());
		this.addWindowListener(this);
	    Font f=new Font("Times",Font.BOLD,12);
	    label1.setFont(f);
	    label2.setFont(f);
	    p2.add(label1);
	    p2.add(label2);
		this.add(p2,BorderLayout.CENTER);
		b2.setVisible(false);
		b3.setVisible(false);
		p1.setLayout(cl);
		p1.add(b2);
		p1.add(b1);
		p1.add(b3);
		this.add(p1,BorderLayout.SOUTH);
		b1.addActionListener( this);
		this.setBounds(200,200,420,200);
		this.setBackground(Color.white);
		this.setAlwaysOnTop(true);
		if(THRESHOLDS.bool==false)
		{
			THRESHOLDS.bool=true;
			this.setVisible(true);
		}

		}
		
	


	
      public void actionPerformed(ActionEvent e)
      {
    	  if(e.getSource()==b1)
    	  { 
    		  dispose();
    		
    	  }
    	  
    	  
    }


	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowClosed(WindowEvent arg0) {
	
	}


	@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub
		this.dispose();
	}


	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

   
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

