package monitor.views;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.event.*;

import javax.swing.JTextArea;

import Detectors.THRESHOLDS;


public class TheDetail extends Frame implements  ActionListener ,WindowListener{
	
	Panel p2=new Panel();
	Button b1=new Button("           OK             ");
	Button b2=new Button("Never Shown Again");

	String theExplaination=SmellView.EX;
	JTextArea ta;
	//JTextArea tb=new JTextArea("Suggestion:"+SmellView.SG);

	FlowLayout cl=new FlowLayout();
	 

	TheDetail()
	{   
		this.setTitle("Detail Information & Suggestions");
		this.setLayout(null);
		String newline=System.getProperties().getProperty("line.separator");
		ta=new JTextArea("EXPLAINATION:   "+newline+"    "+theExplaination+newline+newline+newline+"SUGGESTIONS:   "+newline+"    "+SmellView.SG);
		this.setLayout(new BorderLayout());
		this.addWindowListener(this);
		
		ta.setLineWrap(true);
	    Font f=new Font("Times",Font.BOLD,12);
	    ta.setFont(f);
        ta.setSize(150, 200);
		
		
		this.add(ta,BorderLayout.CENTER);
		
		this.add(p2,BorderLayout.SOUTH);
		p2.setLayout(cl);
		p2.add(b1);
		p2.add(b2);
		b1.addActionListener( this);
		b2.addActionListener( this);
		
		
		this.setBounds(200,200,500,300);
		this.setBackground(Color.white);
		this.setAlwaysOnTop(true);

		if(THRESHOLDS.NoShowAgain==false)
		{
			this.setVisible(true);}
	    		
	}

	
      public void actionPerformed(ActionEvent e)
      {
    	  if(e.getSource()==b1)
    	  { 
    		  dispose();
    		
    	  }
    	  else{ 
			
    		  THRESHOLDS.NoShowAgain=true; 
    		 dispose();
    		 

    		 }
	  
    			  
    			  
    	
    		  
    	  }
    	  
    	  
    


	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowClosed(WindowEvent arg0) {
	
	}


	@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub
		this.dispose();
	}


	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

   
  	}

	
	
	
	
	


