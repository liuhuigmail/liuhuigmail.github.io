package Detectors;

import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import Smells.PublicField;
import Smells.SMELLTYPE;
import Smells.Smell;

public class PublicFielDector extends Detector {
	public static ArrayList<String> comparatedlist=new ArrayList<String>();
	public PublicFielDector(IResource iresource, CompilationUnit Punit) {
		super(iresource, Punit);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Smell> DetectSmells() {
		List types = unit.types();
		smells = new ArrayList<Smell>();
		for (Object obj : types) {
			if (!(obj instanceof TypeDeclaration))
				continue;
			TypeDeclaration typeDec = (TypeDeclaration) obj;
			FieldDeclaration[] fields = typeDec.getFields();
			for (FieldDeclaration aField : fields) {
               
				if((aField.getModifiers()&Modifier.PUBLIC)==0)
				{
					continue;
				}
				
				Smell asmell = new PublicField();
				
				asmell.resource = resource;
				asmell.unit = this.unit;
				asmell.associatedNode=aField;
				asmell.setStartPoint(aField.getStartPosition());
				int lines = unit.getLineNumber(asmell.getStartPoint());
				int length=unit.getPosition(lines+1, 1)-asmell.getStartPoint()-1;
				asmell.length = length;
				asmell.explaination="Filed "+aField.fragments().toString()+ " is public ";
				
				smells.add(asmell);
				
				
				String typename=asmell.getType().toString();
				String location=asmell.resource.getLocation().toString();
			
				  if ((asmell.associatedNode instanceof FieldDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
				 		
				  { FieldDeclaration File = (FieldDeclaration) asmell.associatedNode;
				  String file=File.toString();
				
				  comparatedlist.add(typename);
				  comparatedlist.add(location);
				  comparatedlist.add(file);
				  }
			
			
			}
		}
		return smells;

	}

}
