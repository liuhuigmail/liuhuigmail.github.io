package Detectors;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eposoft.jccd.data.ASourceUnit;
import org.eposoft.jccd.data.SimilarityGroup;
import org.eposoft.jccd.data.SimilarityGroupManager;
import org.eposoft.jccd.data.SourceUnitManager;
import org.eposoft.jccd.data.SourceUnitPosition;
import org.eposoft.jccd.data.ast.ANode;
import org.eposoft.jccd.data.ast.NodeTypes;
import org.eposoft.jccd.detectors.APipeline;
import org.eposoft.jccd.detectors.ASTDetector;
import org.eposoft.jccd.preprocessors.java.GeneralizeMethodDeclarationNames;
import org.eposoft.jccd.preprocessors.java.GeneralizeVariableNames;
import Smells.Duplicatedcode;
import Analysis.printer;
import Smells.DuplicatedInfo;
import Smells.Smell;

public class DuplicatedCodeDector extends Detector {

	public DuplicatedCodeDector(IResource iresource, CompilationUnit Punit) {
		super(iresource, Punit);
		// TODO Auto-generated constructor stub
	}
	

	@Override
	public List<Smell> DetectSmells() { 
		List types = unit.types();
		smells = new ArrayList<Smell>();
		for (Object obj : types) {
			if (!(obj instanceof TypeDeclaration))
				continue;
			TypeDeclaration typeDec = (TypeDeclaration) obj;
			// IProject s=iresource.getProject();

			DetectDuplicatedCode(typeDec);
		} // �����Ŀ���ļ�typeDec// TODO Auto-generated method stub
		removeDuplicatedSmells(smells);
		return smells;
	}

	private void removeDuplicatedSmells(List<Smell> smells) {
       	Duplicatedcode asmell = new Duplicatedcode();
		Duplicatedcode asmell2 = new Duplicatedcode();
		for (int i = 0; i < smells.size(); i++) {
			asmell = (Duplicatedcode) smells.get(i);
			for (int j = i+1; j < smells.size(); j++) {
				asmell2 = (Duplicatedcode) smells.get(j);

			if (asmell.editingnode.Starth== asmell2.editingnode.Starth&&asmell.editingnode.Endh==asmell2.editingnode.Endh
						&&asmell.editingnode.Startl==asmell2.editingnode.Startl&&asmell.editingnode.Endl==asmell2.editingnode.Endl) {
			        asmell.addNode(asmell2.get());

					smells.remove(asmell2);
					j--;

				}
        
				 
			}

		}
		
		
		// TODO Auto-generated method stub
		
	}


	public void DetectDuplicatedCode(TypeDeclaration aType) {
		OtherType n = new OtherType(resource, unit);
		n.find(aType);
	}

	class OtherType {
		IResource Iresource;
		CompilationUnit punit;

		OtherType(IResource iresource, CompilationUnit Punit) {
            Iresource = iresource;
			punit = Punit;
		}	
		
		

		void find(TypeDeclaration type) {
		
			
			String filename;
			String fname;
			String path;
			URI uri=resource.getLocationURI();
			
			 path=uri.getPath();
			SourceUnitManager unit1=UnitMap.upDate(path);
			
	         if(path.startsWith("/"))
	         { path=path.substring(1);};
	     
	

			IJavaElement javaElement = JavaCore.create(Iresource);
		
						 
			try {
				IJavaProject A = javaElement.getJavaProject();
				
				IPackageFragment[] JS=A.getPackageFragments();	
			
				
				for (IPackageFragment J : JS) {
                     
					if(J.getKind()!=IPackageFragmentRoot.K_SOURCE)
                        	  continue;

				 	ICompilationUnit[] r = J.getCompilationUnits();

					for (ICompilationUnit m : r) {
						URI mr=m.getResource().getLocationURI();
						
						String comparepath=mr.getPath();
						if(comparepath.startsWith("/"))
				         { comparepath=comparepath.substring(1);};
				  
						
		
						if (comparepath.equalsIgnoreCase(
								path))
							continue;// ��ȥ����
						
									
						          String s1 = path;
								  String s2 = comparepath;
								
									
									 SourceUnitManager unit2= UnitMap.getUnit(s2) ;
									APipeline detector = new ASTDetector();
									
									detector.addOperator(new GeneralizeMethodDeclarationNames());
								     detector.addOperator(new GeneralizeVariableNames()); 
								  
								     
									SimilarityGroupManager sgroup = detector
											.Myprocess(unit1,unit2);
									
//									
									SimilarityGroup[] simigroup = sgroup
											.getSimilarityGroups();
									int count = simigroup.length;
									
							//		System.out.println("NUMBER OF CLONE PAIRS: "+ count);
									int index = 0;
									SimilarityGroup cur = null;

									 while (index < count) {
										cur = simigroup[index++];
										final ASourceUnit[] nodes = cur
												.getNodes();
										Duplicatedcode asmell = new Duplicatedcode();
										boolean hasFindEditingNode=false;
										for (int j = 0; j < nodes.length; j++) {
											final SourceUnitPosition minPos = APipeline
													.getFirstNodePosition((ANode) nodes[j]);
											final SourceUnitPosition maxPos = APipeline
													.getLastNodePosition((ANode) nodes[j]);
											//System.out.println("��������========"+(maxPos.getLine()-minPos.getLine()+1));
									if((maxPos.getLine()-minPos.getLine()+1)<THRESHOLDS.Duplicatedline)continue;
								
											ANode fileNode1 = (ANode) nodes[j];
											while (fileNode1.getType() != NodeTypes.FILE
													.getType()) {
												fileNode1 = fileNode1.getParent();
											}
											filename = fileNode1
													.getText().toString();
											
											fname=filename.replace('\\','/');
											s1.replace('/', '\\');
									
											//System.out.println(filename+"......COMAPRING................");
										
											
										if (fname
												.compareToIgnoreCase(s1) == 0 && hasFindEditingNode==false) {// ��ǰ�޸ĵ��ļ�

											hasFindEditingNode=true;
											asmell.filenode=fileNode1;
											asmell.resource = Iresource;
											asmell.unit = this.punit;
											asmell.associatedNode = type;
											asmell.length=1  ;   //nodes[j].toString().length();//(maxPos.getLine()- minPos.getLine() + 1);
											
												DuplicatedInfo node = new DuplicatedInfo(
														minPos.getLine(),
														minPos.getCharacter(),
														maxPos.getLine(),
														maxPos.getCharacter(),
														filename);
												  asmell.editingnode=node;
											} else

											{
												DuplicatedInfo node = new DuplicatedInfo(
														minPos.getLine(),
														minPos.getCharacter(),
														maxPos.getLine(),
														maxPos.getCharacter(),
														filename);
												asmell.append(node);
											}

										}// END OF FOR (�������һ��sim group)
										
										if(asmell.editingnode!=null) 
										{
										  
										   asmell.GenExplainnation();
										   if(!asmell.explaination.contains("<===>"))continue;
										   
										   smells.add(asmell);
										}
										else 
										{printer.print("Failed Clone Pair");}
										

									}
								}

							
           
            	 
            	 
		

				}
			}

			catch (JavaModelException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}
}
