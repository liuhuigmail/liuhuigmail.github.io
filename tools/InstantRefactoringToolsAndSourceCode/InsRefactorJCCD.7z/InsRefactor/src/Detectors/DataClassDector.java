package Detectors;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import Smells.DataClass;
import Smells.SMELLTYPE;
import Smells.Smell;

public class DataClassDector extends Detector {

	public DataClassDector(IResource iresource, CompilationUnit Punit) {
		super(iresource, Punit);
		// TODO Auto-generated constructor stub
	}

	public List<Smell> DetectSmells() {
		List types = unit.types();
		smells = new ArrayList<Smell>();
		for (Object obj : types) {
			if (!(obj instanceof TypeDeclaration))
				continue;
			TypeDeclaration typeDec = (TypeDeclaration) obj;

			int methodLength=getLengthOfMethods(typeDec);
			int AttributeNumber=typeDec.getFields().length;
			if(methodLength>AttributeNumber*THRESHOLDS.getDATACLASS_TIMES())
			 continue;
			Smell asmell = new DataClass();
			//asmell.setType(SMELLTYPE.DATACLASS);
			asmell.resource = resource;
			asmell.unit = this.unit;
			asmell.associatedNode=typeDec;
			asmell.setStartPoint(typeDec.getStartPosition());
			asmell.length = typeDec.getLength();
			asmell.explaination="Class "+typeDec.getName()+ " contains too much fileds compared to its simple computation";
			smells.add(asmell);
		}
		return smells;
	}

	private int getLengthOfMethods(TypeDeclaration type) {
		int TolLength = 0;
        MethodDeclaration[] methods=type.getMethods();
        for(MethodDeclaration del:methods)
        {
        	int length = del.getLength();
			int startPoint = del.getStartPosition();
			int lines = unit.getLineNumber(startPoint);
			lines = unit.getLineNumber(startPoint + length - 1) - lines;
			TolLength+=lines;
        }
		return TolLength;
	}

}
