package Detectors;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import Smells.LargeClass;
import Smells.SMELLTYPE;
import Smells.Smell;

public class LargeClassDector extends Detector {

	public LargeClassDector(IResource resource, CompilationUnit Punit) {
		super(resource, Punit);
		// TODO Auto-generated constructor stub
	}
	
	String[] m=new String[10];
	int i=0;
	
	public List<Smell> DetectSmells()  {
		List types = unit.types();                      
		smells = new ArrayList<Smell>();
		for (Object obj : types) {
			if (!(obj instanceof TypeDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
				continue;
			TypeDeclaration typeDec = (TypeDeclaration) obj;
			
			
			int length = typeDec.getLength();               //Ŀ���ļ�typeDec����
			int startPoint = typeDec.getStartPosition();    //Ŀ���ļ���ʼλ��
			int lines = unit.getLineNumber(startPoint);     //��ʼλ���ǵڼ���
			lines=unit.getLineNumber(startPoint+length-1)-lines;  //����
			if(lines<THRESHOLDS.getLARGECLASS_LINES()) continue;
			Smell asmell = new LargeClass();                // LargeClass��Smell������
		//	asmell.setType(SMELLTYPE.LARGECLASS);
			asmell.resource = resource;
			asmell.unit = this.unit;
			asmell.associatedNode=typeDec;
			asmell.setStartPoint(startPoint);
			asmell.length=length;
			
		
			asmell.explaination="Class "+typeDec.getName()+ " contains " + lines +" lines of source code.";

		
			smells.add(asmell);
			//asmell�������Ϊ �б�smell�е�һ��
			// test  --- to remore
			
	}
		return smells;
	}
	
	 


	
	 }
