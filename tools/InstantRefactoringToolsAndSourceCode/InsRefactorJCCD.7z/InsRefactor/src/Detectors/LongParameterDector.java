/**
 * 
 */
package Detectors;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import Smells.LongParameter;
import Smells.SMELLTYPE;
import Smells.Smell;

/**
 * @author LH
 * 
 */
public class LongParameterDector extends Detector {

	/**
	 * @param iresource
	 * @param Punit
	 */
	public LongParameterDector(IResource iresource, CompilationUnit Punit) {
		super(iresource, Punit);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Smell> DetectSmells() {
		List types = unit.types();
		smells = new ArrayList<Smell>();
		for (Object obj : types) {
			if (!(obj instanceof TypeDeclaration))
				continue;
			TypeDeclaration typeDec = (TypeDeclaration) obj;
			DetectLongParameters(typeDec);			
		}
		return smells;
	}

	private void DetectLongParameters(TypeDeclaration aType) {
		MethodDeclaration methods[] = aType.getMethods();
		for (MethodDeclaration method : methods) {

			int numOfPars=method.parameters().size();
			if(numOfPars<THRESHOLDS.getLONGPARAMETER()) continue;
			int startPoint = method.getStartPosition();
			int lines = unit.getLineNumber(startPoint);
			int length=unit.getPosition(lines+1, 1)-startPoint-1;
//			printer.println(startPoint);
//			printer.println(length);
			Smell asmell = new LongParameter();
			//asmell.setType(SMELLTYPE.LONGPARAMETER);
			asmell.resource = resource;
			asmell.unit = this.unit;
			asmell.associatedNode=method;
			asmell.setStartPoint(startPoint);
			asmell.length = length;
			asmell.explaination="Method "+method.getName()+ " contains " + numOfPars +" parameters.";
			
			smells.add(asmell);
		}

	}
}
