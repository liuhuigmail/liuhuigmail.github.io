package Detectors;

import java.io.File;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.CompilationUnit;

import Analysis.printer;
import Smells.Smell;

public abstract class Detector {
	protected CompilationUnit unit ;
	protected IResource resource;
    protected List<Smell> smells;
	public String path;
	//public static String also;
    public Detector(IResource iresource, CompilationUnit Punit) {
		this.unit = Punit;
		this.resource=iresource;
		//get object which represents the workspace   
		//IWorkspace workspace = ResourcesPlugin.getWorkspace();   
		  
		//get location of workspace (java.io.File)   
		//File workspaceDirectory = workspace.getRoot().getLocation().toFile();  
		
       
          
          
          
       //   printer.println("Root: "+workspaceDirectory.getAbsolutePath());
          
	}
	public abstract List<Smell> DetectSmells();
	
}
