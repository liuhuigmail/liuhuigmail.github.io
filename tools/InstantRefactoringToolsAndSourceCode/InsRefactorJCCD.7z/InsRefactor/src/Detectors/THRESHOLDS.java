package Detectors;

import Analysis.printer;
import Smells.SMELLTYPE;

public final class THRESHOLDS {
	private static int LARGECLASS_LINES = 100;
	private static int LONGMETHOD_LINES = 50;
	private static int DATACLASS_TIMES = 5;
	private static int LONGPARAMETER = 5;
	public static long HOWLONGISNEW = 60000;// 10*1000*6 �������ڷ��ֵ�smell���µ�smell
	public static double lowestRatio = 0.8;
	public static double HighestRatio = 0.9;
	private static int  COMMONMETHODTIME = 15;
	public static int Duplicatedline = 5;
	public static double RATIO=0.2;
	public static String tab=";"; //����smellʱ����ÿ���ֶ�
	public static String tab2 ="//";
	public static String fileOfSavedSmells= " Information.txt";
	public static String fileOfSavedSmells2="Information of THRESHOLDS.txt";
	public static boolean bool=false;
	public static  boolean NoShowAgain=false;
	public static boolean IsOurOfRange(double ratio) {
		if (ratio <= HighestRatio && ratio >= lowestRatio) {
			return false;
		}
		return true;
	}
	public static int AdjustThreshold(int oldThreshold, double ratio)
	{
		    ratio=lowestRatio+HighestRatio-2*ratio;
		 //   printer.println("Ratio:="+ratio);
		    oldThreshold=(int)(oldThreshold*(1+ratio*0.05));	// ��������	
		    return oldThreshold;
	}
	public static int getLONGPARAMETER() {
		return LONGPARAMETER;
	}
	public static void setLONGPARAMETER(int lONGPARAMETER) {
		if(lONGPARAMETER<2) return ;
		if(lONGPARAMETER>10) return ;
		LONGPARAMETER = lONGPARAMETER;
	}
	public static int getDATACLASS_TIMES() {
		return DATACLASS_TIMES;
	}
	public static void setDATACLASS_TIMES(int dATACLASS_TIMES) {
		if(dATACLASS_TIMES<3) return ;
		if(dATACLASS_TIMES>20) return ;
		DATACLASS_TIMES = dATACLASS_TIMES;
	}
	public static int getLARGECLASS_LINES() {
		return LARGECLASS_LINES;
	}
	public static void setLARGECLASS_LINES(int lARGECLASS_LINES) {
		if(lARGECLASS_LINES<30) return ;
		if(lARGECLASS_LINES>500) return ;
		LARGECLASS_LINES = lARGECLASS_LINES;
	}
	public static int getLONGMETHOD_LINES() {
		return LONGMETHOD_LINES;
	}
	public static void setLONGMETHOD_LINES(int lONGMETHOD_LINES) {
		if(lONGMETHOD_LINES<10) return ;
		if(lONGMETHOD_LINES>300) return ;
		LONGMETHOD_LINES = lONGMETHOD_LINES;
	}
	public static int getCOMMONMETHODTIME() {
		return COMMONMETHODTIME;
	}
	public static void setCOMMONMETHODTIME(int cOMMONMETHODTIME) {
		if(cOMMONMETHODTIME<10) return ;
		if(cOMMONMETHODTIME>80) return ;
		COMMONMETHODTIME = cOMMONMETHODTIME;
	}
}
