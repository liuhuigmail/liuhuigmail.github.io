package Detectors;

import java.text.DateFormat.Field;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import Smells.BadFiledName;
import Smells.BadMethodName;
import Smells.BadTypeName;
import Smells.PublicField;
import Smells.Smell;

public class BadNameDector extends Detector{
	public BadNameDector(IResource iresource, CompilationUnit Punit) {
	super(iresource, Punit);
	// TODO Auto-generated constructor stub
}

public List<Smell> DetectSmells() {
	List types = unit.types();
	smells = new ArrayList<Smell>();
	for (Object obj : types) {
		if (!(obj instanceof TypeDeclaration))
			continue;
		TypeDeclaration typeDec = (TypeDeclaration) obj;
		// IProject s=iresource.getProject();

		DetectBadName(typeDec);
	} // �����Ŀ���ļ�typeDec
	return smells;
}

private void DetectBadName(TypeDeclaration typeDec) {

	MethodDeclaration[] Methods = typeDec.getMethods();
	for(int i=0;i<Methods.length;i++)
	{
		String methodName=Methods[i].getName().toString();
		if(methodName.trim().length()==1)
		{int body=Methods[i].getBody().getStartPosition();
            Smell asmell = new BadMethodName();
			asmell.resource = resource;
			asmell.unit = this.unit;
			asmell.associatedNode=Methods[i];
			asmell.setStartPoint(Methods[i].getName().getStartPosition());
			int length=1;
			asmell.length = length;
			asmell.explaination="Method name "+" ' "+methodName+" ' "+ " is not meaningful";
			smells.add(asmell);
			
			
			
		}	
					
			
	}	
		
		
	       List types=this.unit.types();
	    	for (Object obj : types) {
			if (!(obj instanceof TypeDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
				continue;
			    TypeDeclaration typeDec1 = (TypeDeclaration) obj;
			    String typeName=typeDec1.getName().toString();
			    if(typeName.trim().length()==1)
			    {			    	
		            Smell asmell = new BadTypeName();
					asmell.resource = resource;
					asmell.unit = this.unit;
					asmell.associatedNode=typeDec1;
					asmell.setStartPoint(typeDec1.getStartPosition());
					int lines = unit.getLineNumber(asmell.getStartPoint());
					int length=unit.getPosition(lines+1, 1)-asmell.getStartPoint()-1;
					asmell.length = length;
					asmell.explaination="Type's name "+" ' "+typeName+" ' "+ " is a bad name ";
					smells.add(asmell);
			    	
			    	
			     }	
			    	
			    	
			    }	
			    	
			    	
						}
					
					
				}
	       
	    	   
	    	   
	    	   
	    	   
	    	   
	    	   
	    	   
	    	   
	    	   
	    	   
	    	   
	    	   
	    	   
	    	   
	    	   
	       
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// TODO Auto-generated method stub
	






