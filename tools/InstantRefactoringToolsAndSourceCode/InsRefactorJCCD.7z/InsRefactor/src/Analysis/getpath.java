package Analysis;

public class getpath {

}
