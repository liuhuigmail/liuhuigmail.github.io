package Analysis;

import java.util.List;

import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.viewers.TableViewer;

import Smells.Smell;


public class ListenerManager {
	
	public static ResListener listener;

	public List<Smell> Regid(TableViewer viewer)
	{
		IWorkspace workspace = ResourcesPlugin.getWorkspace();
		    listener = new ResListener(viewer);
		  workspace.addResourceChangeListener(listener);
	     	return null;

		   //... some time later one ...
		 //  workspace.removeResourceChangeListener(listener);
		  

	}

}
