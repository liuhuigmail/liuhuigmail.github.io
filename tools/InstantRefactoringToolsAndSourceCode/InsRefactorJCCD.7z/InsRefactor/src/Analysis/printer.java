package Analysis;

public class printer {
	public static boolean debugmodel=false;
	public static void print(String s)
	{if(debugmodel) System.out.print(s);}
	public static void println(String s)
	{if(debugmodel)System.out.print(s);}
	public static void println(int s)
	{if(debugmodel)System.out.print(s);}
	public static void print(int s)
	{if(debugmodel)System.out.print(s);}
	public static void println(Exception e)
	{if(debugmodel)System.out.print(e);}
	public static void print(Exception e)
	{if(debugmodel)System.out.print(e);}
	public static void println(Object e)
	{if(debugmodel)System.out.print(e);}
	
	
		
	
	
	
}
