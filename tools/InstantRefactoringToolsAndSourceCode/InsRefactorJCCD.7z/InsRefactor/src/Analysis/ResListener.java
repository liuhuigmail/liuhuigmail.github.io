package Analysis;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import monitor.views.SmellComparator;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.TableViewer;
import Smells.Smell;

public class ResListener implements IResourceChangeListener {
	public static List<Smell> SmellList;
    public  static TableViewer viewer;
	public ResListener(TableViewer pviewer) {
		viewer=pviewer;
		if(SmellList!=null && SmellList.size()>0)
		{  
			ResListener.SmellList=SmellList;
			Collections.sort(ResListener.SmellList, new SmellComparator());	
			ResListener.viewer.setInput(ResListener.SmellList);

			// printer.println("List Size= " +ResListener.SmellList.size());
			ResourceVistor.ChangeColor(ResListener.viewer.getTable());
			ResListener.viewer.refresh();
			
		}
		//printer.println("ResListener!!");
		
		// TODO Auto-generated constructor stub
	}

	@Override
	public void resourceChanged(IResourceChangeEvent event) {
		//printer.println("...................change type"+event.getType());
	  Date t1=new Date();
		if (event.getType() != IResourceChangeEvent.POST_CHANGE)
   		            return;

		
		IResourceDelta rootDelta = event.getDelta();

		final ArrayList changed = new ArrayList();

		ResourceVistor visitor = new ResourceVistor(SmellList,viewer) ;
		try {
			rootDelta.accept(visitor);
			this.SmellList=visitor.SmellList;
			 Date t2=new Date();
			// printer.println("Time Consumed: "+ (t2.getTime()-t1.getTime())); 
		} catch (CoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}

}
