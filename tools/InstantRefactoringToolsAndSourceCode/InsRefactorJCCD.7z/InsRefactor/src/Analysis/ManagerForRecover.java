package Analysis;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;

import org.eclipse.jdt.core.JavaCore;

import Detectors.CommonMethodsDector;
import Detectors.DataClassDector;
//import Detectors.DuplicatedCodeDector;
//import Detectors.DuplicatedCodeDector;
//import Detectors.DuplicatedDector;
import Detectors.BadNameDector;
import Detectors.DuplicatedCodeDector;
import Detectors.LargeClassDector;
import Detectors.LongMethodDector;
import Detectors.LongParameterDector;
import Detectors.PublicFielDector;
import Detectors.VisitorOfAST;
import Smells.Smell;

public class ManagerForRecover {
	public static List<Smell> SmellList = new ArrayList<Smell>();
	public static CompilationUnit unit;
	public static IResource resource;
	public boolean recover;

	public ManagerForRecover() {
		SmellList = new ArrayList<Smell>();
	}

	public List<Smell> DetectSmells(IResource m_resource) {
		resource = m_resource;

		// the resource is a java file recently changed.
		// 1. ����һ��AST�ȡ�
		try {

			IJavaElement javaElement = JavaCore.create(resource);
			ASTParser parser = ASTParser.newParser(AST.JLS3);
			ICompilationUnit Iunit = (ICompilationUnit) javaElement;
			if (Iunit == null) {

				return null;
			}
			parser.setSource(Iunit);
			unit = (CompilationUnit) parser.createAST(null);
			LargeClassDector largeClass = new LargeClassDector(resource, unit);// ���LargeClass��
			SmellList.addAll(0, largeClass.DetectSmells()); // �б�������

			LongMethodDector longmethod = new LongMethodDector(resource, unit);
			SmellList.addAll(0, longmethod.DetectSmells());

			DataClassDector dataClass = new DataClassDector(resource, unit);
			SmellList.addAll(0, dataClass.DetectSmells());

			LongParameterDector longPar = new LongParameterDector(resource,
					unit);
			SmellList.addAll(0, longPar.DetectSmells());

			PublicFielDector pubField = new PublicFielDector(resource, unit);
			SmellList.addAll(0, pubField.DetectSmells());

			VisitorOfAST BadName = new VisitorOfAST();
			unit.accept(BadName);
			SmellList.addAll(0, BadName.getBadName(resource, unit));

			VisitorOfAST BadParameterName = new VisitorOfAST();
			unit.accept(BadParameterName);
			SmellList.addAll(0, BadParameterName.getBadName2(resource, unit));

			BadNameDector badName = new BadNameDector(resource, unit);
			SmellList.addAll(0, badName.DetectSmells());

			CommonMethodsDector commonmethod = new CommonMethodsDector(
					resource, unit);
			SmellList.addAll(0, commonmethod.DetectSmells());

			VisitorOfAST smellVisitor = new VisitorOfAST();
			unit.accept(smellVisitor);
			SmellList.addAll(0, smellVisitor.getSwitchSmells(resource, unit));

			DuplicatedCodeDector duplicatedCode = new DuplicatedCodeDector(
					resource, unit);
			SmellList.addAll(0, duplicatedCode.DetectSmells());

		}

		catch (Exception e) {
			printer.println(e);
		}
		if (ResListener.SmellList == null) {
			ResListener.SmellList = new ArrayList<Smell>();

		}
		SmellList = ResListener.SmellList = Smell.removeDuplicated(
				ResListener.SmellList, SmellList);

		return SmellList;

	}

}
