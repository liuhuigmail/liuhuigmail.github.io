package Analysis;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URI;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jdt.core.IJavaModel;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.ICompilationUnit;
import Detectors.THRESHOLDS;
import Smells.SMELLTYPE;
import Smells.Smell;
import java.util.ArrayList;
import java.util.List;

public class Recover {

	private static final char[] Exception = null;
	ArrayList<String> newlist = new ArrayList<String>();
	ArrayList<ArrayList<String>> listlist = new ArrayList<ArrayList<String>>();
	public static List<Smell> thesmelllist = new ArrayList<Smell>();

	public Recover() {
		thesmelllist = new ArrayList<Smell>();
	}

	// String M;
	public void readThreshold()
	{
		try{
		FileReader fre = new FileReader(THRESHOLDS.fileOfSavedSmells2);
		BufferedReader bre = new BufferedReader(fre);
		String m;
		
		while((m=bre.readLine())!=null)
		{        
		   if(m.trim().length()==0)continue;
		   int newCOMMONMETHODTIME=Integer.parseInt(m.split(THRESHOLDS.tab2)[0].split(":")[1]);
		   if(newCOMMONMETHODTIME>0) {THRESHOLDS.setCOMMONMETHODTIME(newCOMMONMETHODTIME);};
		   
		  int newDATACLASS_TIMES=Integer.parseInt(m.split(THRESHOLDS.tab2)[1].split(":")[1]);
		  if(newDATACLASS_TIMES>0){THRESHOLDS.setDATACLASS_TIMES(newDATACLASS_TIMES);}
		  
		 int newDuplicatedline=Integer.parseInt(m.split(THRESHOLDS.tab2)[2].split(":")[1]);
		  if(newDuplicatedline>0){THRESHOLDS.Duplicatedline=newDuplicatedline;}
		   
		  int newLARGECLASS_LINES=Integer.parseInt(m.split(THRESHOLDS.tab2)[3].split(":")[1]);
		  if(newLARGECLASS_LINES>0){THRESHOLDS.setLARGECLASS_LINES(newLARGECLASS_LINES);}
		   
		  int newLONGMETHOD_LINES=Integer.parseInt(m.split(THRESHOLDS.tab2)[4].split(":")[1]);
		 if(newLONGMETHOD_LINES>0) {THRESHOLDS.setLONGMETHOD_LINES(newLONGMETHOD_LINES);}
		    
		 
		 int newLONGPARAMETER=Integer.parseInt(m.split(THRESHOLDS.tab2)[5].split(":")[1]);
		if(newLONGPARAMETER>0){ THRESHOLDS.setLONGPARAMETER(newLONGPARAMETER);}
		    
		 double newHighestRatio=Double.parseDouble(m.split(THRESHOLDS.tab2)[6].split(":")[1]);
		   if(newHighestRatio>0) {THRESHOLDS.HighestRatio=newHighestRatio;}
		  
		   double newlowestRatio=Double.parseDouble(m.split(THRESHOLDS.tab2)[7].split(":")[1]);  
		  if(newlowestRatio>0) {THRESHOLDS.lowestRatio=newlowestRatio;}
		    
		 boolean  newbool=Boolean.parseBoolean(m.split(THRESHOLDS.tab2)[8].split(":")[1]);
		 THRESHOLDS.bool=newbool;
		 
		 boolean  newNoShowAgain=Boolean.parseBoolean(m.split(THRESHOLDS.tab2)[9].split(":")[1]);
		 THRESHOLDS.NoShowAgain=newNoShowAgain;
		 
		  
		}}
		catch (Exception e1)
		{System.out.println("Have not found Information of THRESHOLDS.txt");}
		
		
		
		
		
	}
	public void read() {
		List<Smell> SmellList = new ArrayList<Smell>();
		try {

			FileReader fre = new FileReader(THRESHOLDS.fileOfSavedSmells);
			BufferedReader bre = new BufferedReader(fre);

			String m;
			int k = 0;
			while ((m = bre.readLine()) != null) {
				if (m.trim().length() == 0)
					continue;
				ArrayList<String> list = new ArrayList<String>();
				list.add(m.split(THRESHOLDS.tab)[0]);
				list.add(m.split(THRESHOLDS.tab)[1]);
				list.add(m.split(THRESHOLDS.tab)[3]);
				list.add(m.split(THRESHOLDS.tab)[2]); // ʱ��η���list�����
				listlist.add(list);
				k++;
			

				String filename = m.split(THRESHOLDS.tab)[1];
				String time = m.split(THRESHOLDS.tab)[2];
				if (newlist.contains(filename))
					continue;
				newlist.add(filename);

			}

			for (int i = 0; i < newlist.size(); i++) {
				String path = newlist.get(i);
				//System.out.println("��List��ȡ����·����" + path);
				File file = new File(newlist.get(i));
				if (file.exists() && file.isFile()) {
					try {

						IWorkspace workspace = ResourcesPlugin.getWorkspace();
						if (workspace == null) {
							
							return;

						}

						IWorkspaceRoot root = ResourcesPlugin.getWorkspace()
								.getRoot();
						IJavaModel jmodel = JavaCore.create(root);
						if (jmodel == null) {
						
							return;

						}
						try {
							IJavaProject[] projects = jmodel.getJavaProjects();
							for (int j = 0; j < projects.length; j++) {
								//System.out.println(projects[j].getPath()
								//		.toString());

								//System.out.println(projects[0].getPath()
								//		.toString());

								IPackageFragment[] packageFragments = projects[j]
										.getPackageFragments();

								//System.out.println(packageFragments[0]
								//		.getPath().toString());
								//System.out.println(packageFragments.length);
								for (IPackageFragment packageFragment : packageFragments) {
									if (packageFragment.getKind() != IPackageFragmentRoot.K_SOURCE)
										continue;

									org.eclipse.jdt.core.ICompilationUnit[] compilationUnits = packageFragment
											.getCompilationUnits();

									for (ICompilationUnit unit : compilationUnits) {
										String en = unit.getPath().toString();

										IResource resource = unit.getResource();
										URI uri = resource.getLocationURI();

										String newpath = uri.getPath()
												.toString().substring(1);
									//	System.out
											//	.println("newpath=" + newpath);
										//System.out.println("path=" + path);
										if (path.equalsIgnoreCase(newpath)) {
											ManagerForRecover  manager = new ManagerForRecover ();
											thesmelllist = manager
													. DetectSmells(resource);

										//	System.out
												//	.println(ResListener.SmellList
													//		.size());

											comparation();

										} else
											continue;

									}

								}
							}

						}

						catch (Exception e1) {
							//System.out.println(e1);
						}

					} catch (Exception e1) {
						//System.out.println(e1);
					}

				}
			}

		} catch (Exception e1) {

		}

	}

	public void comparation() {

		//System.out.println("thesmelllist.size()��ֵ��" + thesmelllist.size());
		//System.out.println("listlist��ֵ��" + listlist.size());

		for (int j = 0; j < thesmelllist.size(); j++) {
			int signal = 0;
			Smell getsmell = thesmelllist.get(j);

			getsmell.forcomparation();

			for (int i = 0; i < listlist.size(); i++) {

				if (SMELLTYPE.getText(getsmell.getType()).equals(
						listlist.get(i).get(0).toString())
						&& getsmell.resource.getLocation().toString().equals(
								listlist.get(i).get(1))
						&& Smell.forcompareted.toString().equals(listlist.get(i).get(2)
								.toString())) {

				//	//System.out.println("ƥ��ɹ�");

					signal = 1;
					////System.out.println(listlist.get(i).get(3));
					getsmell.appearTime = Long
							.parseLong(listlist.get(i).get(3));

				} else
					continue;
			}

			if (signal == 0) {
			//	//System.out.println("$$$$");
				thesmelllist.remove(getsmell);
			}

		}
		
		/*  ResListener.SmellList=thesmelllist;
		  ResListener.viewer.setInput(ResListener.SmellList);
		  ResourceVistor.ChangeColor(ResListener.viewer.getTable());
		  ResListener.viewer.refresh();*/
		 
	}

}
