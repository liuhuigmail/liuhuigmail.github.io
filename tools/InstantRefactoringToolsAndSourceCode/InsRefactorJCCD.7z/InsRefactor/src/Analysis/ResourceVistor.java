package Analysis;


import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.internal.ui.javaeditor.CompilationUnitEditor;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;
import Smells.Smell;

public class ResourceVistor implements IResourceDeltaVisitor {

	public static List<Smell> SmellList=null;
	public static TableViewer viewer;

	public ResourceVistor(List<Smell> smellList2, TableViewer pviewer) {
		// TODO Auto-generated constructor stub
		viewer = pviewer;
		SmellList = smellList2;
		if (SmellList == null)
			SmellList = new ArrayList<Smell>();
	
	}
	class ViewContentProvider implements IStructuredContentProvider {
		public void inputChanged(Viewer v, Object oldInput, Object newInput) {
		}
		public void dispose() {
		}
		public Object[] getElements(Object parent) {
           	return  SmellList.toArray();
		}
	}
	class ViewLabelProvider extends LabelProvider implements ITableLabelProvider {
		public String getColumnText(Object obj, int index) {
			  Smell aSmell= (Smell) obj;
			  return aSmell.getText();
	
			}
		public Image getColumnImage(Object obj, int index) {
			 return getImage(obj);

		}
		public Image getImage(Object obj) {
			return PlatformUI.getWorkbench().
					getSharedImages().getImage(ISharedImages.IMG_OBJ_ELEMENT);
		}
	}
	@Override
	public boolean visit(IResourceDelta delta) throws CoreException {
		// TODO Auto-generated method stub
		// ����IResourceDelta.CHANGED�¼�

		if (delta.getKind() != IResourceDelta.CHANGED)

			return true;

		if ((delta.getFlags() & IResourceDelta.CONTENT) == 0)

			return true;

		IResource resource = delta.getResource();
		

		// ֻ������չ��Ϊtxt���ļ�

		if (resource.getType() == IResource.FILE
				&& "java".equalsIgnoreCase(resource.getFileExtension())) {

			// �Ѹı���������ӵ��б�
			ManagerOfDetectors manager=new ManagerOfDetectors();
		//	printer.println("ManagerOfDetectors manager=new ManagerOfDetectors();");
		
				manager.DetectSmellsOnResource(resource);
				ResourceVistor.ChangeColor(ResListener.viewer.getTable());
		    	viewer.refresh();
			
		}

		return true;
	}


	public static void ChangeColor(Table table) {
		
		TableItem[] items=table.getItems();
		for(TableItem tableItem:items)
		{
		    Object obj=tableItem.getData();	
		   
		    if(obj instanceof Smell)
		    {
			   Smell asmell=(Smell) obj;
			  Color color = Display.getDefault().getSystemColor(SWT.COLOR_BLACK);
		       if(asmell.IsNew())
		       {
			     color = Display.getDefault().getSystemColor(SWT.COLOR_RED);
		       }
		       
		          tableItem.setForeground(color); 
		    }
		    else
		    {
		    	 tableItem.setForeground(Display.getDefault().getSystemColor(SWT.COLOR_BLUE)); 
		    	
		    }
		}
		
	
		table.redraw();
		
	}


	public void hookDoubleClickAction() {
		viewer.addDoubleClickListener(new IDoubleClickListener() {
			public void doubleClick(DoubleClickEvent event) {
				if(event.getSelection().isEmpty()) return;
				ISelection selection = viewer.getSelection();
				Object obj = ((IStructuredSelection)selection).getFirstElement();
		       if (obj==null) return;
		       Smell asmell=(Smell) obj;
		       if(asmell==null) return;
		     
				IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
				IFile file=asmell.getIFile();
				IEditorPart _editor = null;
				try {
					_editor = IDE.openEditor(page, file);
				} catch (PartInitException e) {
					e.printStackTrace();
				}
				if(_editor==null) return;
				CompilationUnitEditor editor=(CompilationUnitEditor)_editor;
				//editor.
			org.eclipse.jface.text.source.ISourceViewer sourceViewer= editor.getViewer();
			//System.out.print("��ʼλ��"+asmell.getStartPoint()+"����"+asmell.length);
				sourceViewer.setSelectedRange(asmell.getStartPoint(), asmell.length);
	
				
			}
		});
	}

}
