/**
 * 
 */
package Smells;

/**
 * @author LH
 *
 */
public enum SMELLTYPE {
	  BADFILEDNAME,
	  BDAPARAMETERNAME,
	  BADMETHODNAME,
	  BADTYPENAME,
      LARGECLASS,
      LONGMETHOD,
      LONGPARAMETER,
      PUBLICFIELD,
      SWITCHSTATEMENTS,
      DATACLASS,
      COMMONMETHOD,
      DUPLICATEDCODE;
    public static  String getText(SMELLTYPE type)
      { if(type==BADFILEDNAME)
    	 return"Bad Filed Name";
      if(type==BDAPARAMETERNAME)
    	  return"Bad Parameter Name";
      if(type==BADMETHODNAME)
    	  return"Bad Method Name";
      if(type==BADTYPENAME)
    	  return"Bad Class Name";
    	if(type==COMMONMETHOD)
    	  return"Common Method";
    	if(type==LARGECLASS)
    		 return "Large Class";
    	if(type==LONGMETHOD)
   		 return "Long Method";
    	if(type==LONGPARAMETER)
     		 return "Long Parameter";
    	if(type==DATACLASS)
      		 return "Data Class";
    	if(type==PUBLICFIELD)
     		 return "Public Field";    	
    	if(type==SWITCHSTATEMENTS)
    		 return "Switch Statements";
    	if(type==DUPLICATEDCODE)
    		return "Duplicated Code";
    	return "Unknown";
      }
      
}
