package Smells;

public  class DuplicatedInfo {
	
	public  int Starth;
	public  int Startl;
	public  int Endh;
	public  int Endl;
	public  String filename;
	
	
	public DuplicatedInfo(int starth,int startl,int endh,int endl,String Filename)
	{ 
		
		Starth=starth;
		Startl=startl;
		Endh=endh;
		Endl=endl;
		filename=Filename;
	
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
