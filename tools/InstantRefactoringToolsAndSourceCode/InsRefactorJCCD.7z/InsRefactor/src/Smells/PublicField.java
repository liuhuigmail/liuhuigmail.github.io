package Smells;

import java.io.BufferedWriter;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import Analysis.printer;
import Detectors.THRESHOLDS;

public class PublicField extends Smell {
	public static int totalNoOfDetectorSmells=0;
	public static int totalNoOfDisparedSmells=0;
	String Suggestion="Encapsulate this field (Menu  Refactor-->Encapsulate Field) ";
	
	
	public String getSuggestion()
	{
		return Suggestion;
		
		
	}
	
	public PublicField() {
		setType(SMELLTYPE.PUBLICFIELD);
	}
	
	
	@Override
	public boolean Smellequal(Smell obj) {
	   	if(!(obj instanceof Smell)) return false;
	      Smell target= (Smell) obj;
	     if(target==null) return false;
	    // if(target.unit!=this.unit) return false;
	     if(target.getType()!=this.getType()) return false;
	   
	    
	    	FieldDeclaration targetField= (FieldDeclaration)target.associatedNode;
	    	FieldDeclaration thisField=(FieldDeclaration)associatedNode;
	    	String targetFieldName=targetField.fragments().toString().trim();
	       	String thisFieldName=thisField.fragments().toString().trim();
	    	if(targetFieldName.compareToIgnoreCase(thisFieldName)!=0)
	    		return false;
	    	return true;	
	}
	
	
	
	
	
	
	public void save(BufferedWriter bw)
	{   
	  
		
		String filelocation=this.resource.getLocation().toString();
	
		
		
		try{ 
			 bw.newLine();
			 bw.append(SMELLTYPE.getText(this.getType()));
			 bw.append(THRESHOLDS.tab);
			 bw.append(filelocation);
			 bw.append(THRESHOLDS.tab);
			 bw.append(Long.toString(this.appearTime));
			 bw.append(THRESHOLDS.tab);
		     if (!(this.associatedNode instanceof FieldDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
			 		return;// failed
			 FieldDeclaration File = (FieldDeclaration) this.associatedNode;
				
			
			 bw.append(File.getType().toString());
			
		}catch(Exception e) {
  	     printer.print(e); }
		
		
	}
	
	public void forcomparation()
	{
		 if (!(this.associatedNode instanceof FieldDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
		 		return;// failed
		 FieldDeclaration File = (FieldDeclaration) this.associatedNode;
		 forcompareted=File.getType().toString();
			
		}
	private static int totalSmellsWithCurrentThreshold=0;
	private static int totalRemovedSemllsWithCurrentThreshold=0;
	@Override
	
	public void toBeRmoved() {
		if(this.DetectedWithCurrentThreshold)
		{
			totalRemovedSemllsWithCurrentThreshold++;			
		}
	}

	@Override
	public void CountNewSmell() {
		if(this.DetectedWithCurrentThreshold)
		{
		    totalSmellsWithCurrentThreshold++;	
		}
	}

	
	

	
		
	
	
}
