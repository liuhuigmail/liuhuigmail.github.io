package Smells;

import java.io.BufferedWriter;

import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;

import Analysis.printer;
import Detectors.THRESHOLDS;

public class BadMethodName extends Smell{
	public static int totalNoOfDetectorSmells=0;
	public static int totalNoOfDisparedSmells=0;
	String Suggestion="Rename it  (Menu  Refactor-->Rename) ";
	public BadMethodName() {
	 	setType(SMELLTYPE.BADMETHODNAME);
			      }
		
		public String getSuggestion()
		{
			return Suggestion;
			
			
		}
		
		
		public boolean Smellequal(Smell obj) {
		   	if(!(obj instanceof Smell)) return false;
		      Smell target= (Smell) obj;
		     if(target==null) return false;
		    // if(target.unit!=this.unit) return false;
		     if(target.getType()!=this.getType()) return false;
		   String path1= target.unit.getJavaElement().getPath().toString();
		     String path2= this.unit.getJavaElement().getPath().toString();
		    if(!path1.equals(path2))
		    		return false;
		    	return true;	
		    	
		     
		     
			  
			     
		    
				
		}
	
	
		public void save(BufferedWriter bw)
		{   
		  
			
			String filelocation=this.resource.getLocation().toString();
		
			
			
			try{ 
				 bw.newLine();
				 bw.append(SMELLTYPE.getText(this.getType()));
				 bw.append(THRESHOLDS.tab);
				 bw.append(filelocation);
				 bw.append(THRESHOLDS.tab);
				 bw.append(Long.toString(this.appearTime));
				 bw.append(THRESHOLDS.tab);
				  if (!(this.associatedNode instanceof MethodDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
						return;// failed
			     MethodDeclaration Method = (MethodDeclaration) this.associatedNode;
				 bw.append(Method.getName().toString());
					
					
					
			}catch(Exception e) {
	  	     printer.print(e); }
			
			
		}
		
				
		public void forcomparation() {
			// TODO Auto-generated method stub
			 if (!(this.associatedNode instanceof MethodDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
					return;// failed
		     MethodDeclaration Method = (MethodDeclaration) this.associatedNode;
			 forcompareted= Method.getName().toString();
		     
				
             
		}
	
			
		
		private static int totalSmellsWithCurrentThreshold=0;
		private static int totalRemovedSemllsWithCurrentThreshold=0;
		@Override
		
		public void toBeRmoved() {
			if(this.DetectedWithCurrentThreshold)
			{
				totalRemovedSemllsWithCurrentThreshold++;			
			}
		}

		@Override
		public void CountNewSmell() {
			if(this.DetectedWithCurrentThreshold)
			{
			    totalSmellsWithCurrentThreshold++;	
			}
		}
		
		
		

	
}
