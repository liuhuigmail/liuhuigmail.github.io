package Smells;

import java.io.BufferedWriter;
import Analysis.printer;
import Detectors.THRESHOLDS;

public class SwitchStatements extends Smell {
	public static int totalNoOfDetectorSmells=0;
	public static int totalNoOfDisparedSmells=0;
	String  Suggestion="Replace the switch with multiple inheritance (Menu  no direct support)";
	public SwitchStatements() {
  setType(SMELLTYPE.SWITCHSTATEMENTS);
	}
	public String getSuggestion()
	{
		return Suggestion;
		
		
	}
	@Override
	public boolean Smellequal(Smell obj) {
		//TODO:��û��ʵ��ʵ���ԵıȽ�
	
   	if(!(obj instanceof Smell)) return false;
      Smell target= (Smell) obj;
     if(target==null) return false;
    // if(target.unit!=this.unit) return false;
     if(target.getType()!=this.getType()) return false;
     return true;
	}
	
	
	public void save(BufferedWriter bw)
	{   
	  
		
		String filelocation=this.resource.getLocation().toString();
		
		
		
		try{ 
			 bw.newLine();
			 bw.append(SMELLTYPE.getText(this.getType()));
			 bw.append(THRESHOLDS.tab);
			 bw.append(filelocation);
			 bw.append(THRESHOLDS.tab);
			 bw.append(Long.toString(this.appearTime));
			 bw.append(THRESHOLDS.tab);
			 
			 bw.append(this.SwitchState);
			}
			catch(Exception e) {
  	     printer.print(e); }
		
		
	}
	public void forcomparation()
	{
		 
			forcompareted=this.SwitchState;
		}
		
	private static int totalSmellsWithCurrentThreshold=0;
	private static int totalRemovedSemllsWithCurrentThreshold=0;
	
	
	public void toBeRmoved() {
		if(this.DetectedWithCurrentThreshold)
		{
			totalRemovedSemllsWithCurrentThreshold++;			
		}
	}

	@Override
	public void CountNewSmell() {
		if(this.DetectedWithCurrentThreshold)
		{
		    totalSmellsWithCurrentThreshold++;	
		}
	}

	
	
	

}
