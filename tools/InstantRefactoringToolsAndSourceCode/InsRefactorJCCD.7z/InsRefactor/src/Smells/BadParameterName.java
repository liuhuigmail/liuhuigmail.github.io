package Smells;

import java.io.BufferedWriter;

import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;

import Analysis.printer;
import Detectors.THRESHOLDS;

public class BadParameterName extends Smell{
	public static int totalNoOfDetectorSmells=0;
	public static int totalNoOfDisparedSmells=0;
	String Suggestion="Rename it  (Menu  Refactor-->Rename) ";
	public BadParameterName() {
	 	setType(SMELLTYPE.BDAPARAMETERNAME);
			      }
		public String getSuggestion()
		{
			return Suggestion;
			
			
		}
		
		
		public boolean Smellequal(Smell obj) {
		   	if(!(obj instanceof Smell)) return false;
		      Smell target= (Smell) obj;
		     if(target==null) return false;
		    // if(target.unit!=this.unit) return false;
		     if(target.getType()!=this.getType()) return false;
		   
		    
		     SingleVariableDeclaration targetField= (SingleVariableDeclaration)target.associatedNode;
		     SingleVariableDeclaration thisField=(SingleVariableDeclaration)associatedNode;
		    	
		     String path1= target.unit.getJavaElement().getPath().toString();
		     
			   String path2= this.unit.getJavaElement().getPath().toString();
			     
			     
			  
			    	
			       	if(!path1.equals(path2))
		    		return false;
		    	return true;	
		}
	
	
		public void save(BufferedWriter bw)
		{   
		  
			
			String filelocation=this.resource.getLocation().toString();
		
			
			
			try{ 
				 bw.newLine();
				 bw.append(SMELLTYPE.getText(this.getType()));
				 bw.append(THRESHOLDS.tab);
				 bw.append(filelocation);
				 bw.append(THRESHOLDS.tab);
				 bw.append(Long.toString(this.appearTime));
				 bw.append(THRESHOLDS.tab);
			     if (!(this.associatedNode instanceof SingleVariableDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
				 		return;// failed
			     SingleVariableDeclaration File = (SingleVariableDeclaration) this.associatedNode;
				 
				
				 bw.append(File.getName().toString());
				
			}catch(Exception e) {
	  	     printer.print(e); }
			
			
		}
		
				
		public void forcomparation() {
			// TODO Auto-generated method stub
			 if (!(this.associatedNode instanceof SingleVariableDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
			 		return;// failed
		     SingleVariableDeclaration File = (SingleVariableDeclaration) this.associatedNode;
			 
			
			
			forcompareted=File.getName().toString();
			
			
			 
		}
	
			
		
		private static int totalSmellsWithCurrentThreshold=0;
		private static int totalRemovedSemllsWithCurrentThreshold=0;
		@Override
		
		public void toBeRmoved() {
			if(this.DetectedWithCurrentThreshold)
			{
				totalRemovedSemllsWithCurrentThreshold++;			
			}
		}

		@Override
		public void CountNewSmell() {
			if(this.DetectedWithCurrentThreshold)
			{
			    totalSmellsWithCurrentThreshold++;	
			}
		}
		
		
		

}
