package Smells;

import java.io.BufferedWriter;
import java.util.List;

import org.eclipse.jdt.core.dom.TypeDeclaration;

import Analysis.printer;
import Detectors.THRESHOLDS;

public class DataClass extends Smell {
	public static int totalNoOfDetectorSmells=0;
	public static int totalNoOfDisparedSmells=0;
	String Suggestion="Move relevant methods into this class (Menu Refactor-->Move)";
	public String getSuggestion()
	{
		return Suggestion;
		
		
	}
	
	public DataClass() {
		setType(SMELLTYPE.DATACLASS);
		// TODO Auto-generated constructor stub
	}
	public static  void AdjustThresholdAfterStatistics()
	{
		double RATION;
		if(totalNoOfDetectorSmells<=10)return;
		
	 RATION=totalNoOfDisparedSmells/totalNoOfDetectorSmells;
		if(! THRESHOLDS.IsOurOfRange( RATION))
		{ THRESHOLDS.setDATACLASS_TIMES(THRESHOLDS.AdjustThreshold(THRESHOLDS.getDATACLASS_TIMES(),  RATION));}
		totalNoOfDetectorSmells=0;
		totalNoOfDisparedSmells=0;
		
	}
	@Override
	public boolean Smellequal(Smell obj) {
	   	if(!(obj instanceof Smell)) return false;
	      Smell target= (Smell) obj;
	     if(target==null) return false;
	    // if(target.unit!=this.unit) return false;
	     if(target.getType()!=this.getType()) return false;
	       TypeDeclaration targetType= (TypeDeclaration)target.associatedNode;
	       TypeDeclaration thisType=(TypeDeclaration)associatedNode;
	    	String targetTypeName=targetType.getName().getFullyQualifiedName().trim();
	       	String thisTypeName=thisType.getName().getFullyQualifiedName().trim();
	    	if(targetTypeName.compareToIgnoreCase(thisTypeName)!=0)
	    		return false;
	    	return true;	
	}
	public void save(BufferedWriter bw)
	{   
	  
		
		String filelocation=this.resource.getLocation().toString();
		
		
		
		try{ 
			 bw.newLine();
			 bw.append(SMELLTYPE.getText(this.getType()));
			 bw.append(THRESHOLDS.tab);
			 bw.append(filelocation);
			 bw.append(THRESHOLDS.tab);
			 bw.append(Long.toString(this.appearTime));
			 bw.append(THRESHOLDS.tab);
	     if (!(this.associatedNode instanceof TypeDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
				return;// failed
			TypeDeclaration typeDec = (TypeDeclaration) this.associatedNode;
			bw.append(typeDec.getName().toString());
			}
			catch(Exception e) {
  	      printer.print(e); }
		
		
	}
	public void forcomparation()
	{
	     if (!(this.associatedNode instanceof TypeDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
				return;// failed
			TypeDeclaration typeDec = (TypeDeclaration) this.associatedNode;
			forcompareted=typeDec.getName().toString();
		}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private static int totalSmellsWithCurrentThreshold=0;
	private static int totalRemovedSemllsWithCurrentThreshold=0;
	@Override
	public void toBeRmoved() {
		if(this.DetectedWithCurrentThreshold)
		{
			totalRemovedSemllsWithCurrentThreshold++;			
		}
	}

	@Override
	public void CountNewSmell() {
		if(this.DetectedWithCurrentThreshold)
		{
		    totalSmellsWithCurrentThreshold++;	
		}
	}
	public static boolean adjustThreshold(List<Smell> existing)
	{
	   printer.println("Total Semlls: " +totalSmellsWithCurrentThreshold);	
	   printer.println("Resovled Semlls: " +totalRemovedSemllsWithCurrentThreshold);
	   if(totalSmellsWithCurrentThreshold<5) return false;
     double ratio=totalRemovedSemllsWithCurrentThreshold/(double)totalSmellsWithCurrentThreshold;
         if(!THRESHOLDS.IsOurOfRange(ratio))
         {
        	return  false; //no need to adjust the threshold        	 
         }
         THRESHOLDS.setDATACLASS_TIMES(THRESHOLDS.AdjustThreshold(THRESHOLDS.getDATACLASS_TIMES(), ratio)); 
         
         //TODO ���¼��smell
         for(Smell asmell : existing)
         {
        	 if(asmell instanceof DataClass)
        	           asmell.DetectedWithCurrentThreshold=false;
         }
         totalSmellsWithCurrentThreshold=0;
         totalRemovedSemllsWithCurrentThreshold=0;
         return true;
	}
}
