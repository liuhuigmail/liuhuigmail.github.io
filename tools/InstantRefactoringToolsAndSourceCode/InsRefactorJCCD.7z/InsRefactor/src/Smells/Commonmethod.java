package Smells;
import java.io.BufferedWriter;
import java.util.List;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import Analysis.printer;
import Detectors.THRESHOLDS;
public class Commonmethod extends Smell {
	public static int totalNoOfDetectorSmells=0;
	public static int totalNoOfDisparedSmells=0;
	//public static String method;
	String Suggestion="Pull up this method to the supper class (Menu Refactor-->Pull up)";
	public Commonmethod() {
 	setType(SMELLTYPE.COMMONMETHOD);
		      }
	public String getSuggestion()
	{
		return Suggestion;
		
		
	}
	
	
	public static void AdjustThresholdAfterStatistics()
	{
		double RATION;
		if(totalNoOfDetectorSmells<=10)return;
		
	 RATION=totalNoOfDisparedSmells/totalNoOfDetectorSmells;
		if(! THRESHOLDS.IsOurOfRange( RATION))
		{ THRESHOLDS.setCOMMONMETHODTIME(THRESHOLDS.AdjustThreshold(THRESHOLDS.getCOMMONMETHODTIME(),  RATION));}
		  totalNoOfDetectorSmells=0;
		  totalNoOfDisparedSmells=0;
	}
	@Override
	public boolean Smellequal(Smell obj) {	
		if(!(obj instanceof Commonmethod)) return false;
		Commonmethod target= (Commonmethod) obj;
    if(target==null) return false;
   
   //  if(target.getType()!=this.getType()) return false;
//   try{
//     String ObjClassname=obj.explaination.split(".")[0];
//    String thisClassname=this.explaination.split(".")[0];
//    if(!ObjClassname.equalsIgnoreCase(thisClassname))
//    {
//    	 System.out.println(ObjClassname+"   "+thisClassname);
//    }
//   }catch(Exception e)
//   {
//	   System.out.println(e);
//	   
//   }
      	if(target.explaination.contains(method)) { return true;}
      	if(this.explaination.contains(target.method)){return true;}
 
   
////   	System.out.println("Location======"+obj.resource.getLocation().toString());
////   	System.out.println(this.resource.getLocation().toString());
//   	if(!obj.resource.getLocation().toString().equals(this.resource.getLocation().toString()))
//   		return false;
   	
   	return false;
		// TODO Auto-generated method stub
		
	   }

	public void save(BufferedWriter bw)
	{   
	  
		
		String filelocation=this.resource.getLocation().toString();
		
		try{ 
			 bw.newLine();
			 bw.append(SMELLTYPE.getText(this.getType()));
			 bw.append(THRESHOLDS.tab);
			 bw.append(filelocation);
			 bw.append(THRESHOLDS.tab);
			 bw.append(Long.toString(this.appearTime));
			 bw.append(THRESHOLDS.tab);
	     if (!(this.associatedNode instanceof MethodDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
				return;// failed
	     MethodDeclaration Method = (MethodDeclaration) this.associatedNode;
			bw.append(Method.getName().toString());
			
			
			}
		
			catch(Exception e) {
  	        printer.print(e); }
		
		
	}
	public void forcomparation()
	{
		  if (!(this.associatedNode instanceof MethodDeclaration))  // obj�Ƿ���TypeDeclaration��һ��ʵ��
				return;// failed
	     MethodDeclaration Method = (MethodDeclaration) this.associatedNode;
			forcompareted=Method.getName().toString();
		}
		
	private static int totalSmellsWithCurrentThreshold=0;
	private static int totalRemovedSemllsWithCurrentThreshold=0;
	
	public void toBeRmoved() {
		if(this.DetectedWithCurrentThreshold)
		{
			totalRemovedSemllsWithCurrentThreshold++;			
		}
	}
	

	@Override
	public void CountNewSmell() {
		if(this.DetectedWithCurrentThreshold)
		{
		    totalSmellsWithCurrentThreshold++;	
		}
	}
	
	public static boolean adjustThreshold(List<Smell> existing)
	{
	 printer.println("Total Semlls: " +totalSmellsWithCurrentThreshold);	
	 printer.println("Resovled Semlls: " +totalRemovedSemllsWithCurrentThreshold);
	 if(totalSmellsWithCurrentThreshold==0) return false;
     double ratio=totalRemovedSemllsWithCurrentThreshold/(double)totalSmellsWithCurrentThreshold;
         if(!THRESHOLDS.IsOurOfRange(ratio))
         {
        	return  false; //no need to adjust the threshold        	 
         }
         THRESHOLDS.setCOMMONMETHODTIME(THRESHOLDS.AdjustThreshold(THRESHOLDS.getCOMMONMETHODTIME(), ratio)); 
         
         //TODO ���¼��smell
         for(Smell asmell : existing)
         {
        	 if(asmell instanceof Commonmethod)
        	           asmell.DetectedWithCurrentThreshold=false;
         }
         totalSmellsWithCurrentThreshold=0;
         totalRemovedSemllsWithCurrentThreshold=0;
         return true;
	}
}
	
	
	
	
	
	
	
	
	
	
	
	






















